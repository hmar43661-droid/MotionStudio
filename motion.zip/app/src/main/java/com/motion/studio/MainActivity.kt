package com.motion.studio

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color as AColor
import android.graphics.Paint
import android.graphics.RectF
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.SurfaceView
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.effect.TextureOverlay
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.google.common.collect.ImmutableList
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

// ======================= النموذج: تركيبة (Comp) + طبقات + مفاتيح حركة =======================

enum class Kind { TEXT, RECT, ELLIPSE, IMAGE }

class Key(val t: Float, val v: Float)

/** خاصية قابلة للتحريك: قيمة ثابتة، أو مفاتيح حركة بينها تنعيم (Easy Ease) */
class Prop(initial: Float) {
    var base by mutableStateOf(initial)
    val keys = mutableStateListOf<Key>()

    fun setKey(t: Float, v: Float) {
        val i = keys.indexOfFirst { kotlin.math.abs(it.t - t) < 0.02f }
        if (i >= 0) keys.removeAt(i)
        keys.add(Key(t, v))
        keys.sortBy { it.t }
    }

    fun at(t: Float): Float {
        if (keys.isEmpty()) return base
        if (t <= keys.first().t) return keys.first().v
        if (t >= keys.last().t) return keys.last().v
        for (i in 0 until keys.size - 1) {
            val a = keys[i]
            val b = keys[i + 1]
            if (t >= a.t && t <= b.t) {
                val f = (t - a.t) / (b.t - a.t)
                val e = f * f * (3f - 2f * f)
                return a.v + (b.v - a.v) * e
            }
        }
        return keys.last().v
    }
}

class Layer(val id: Int, val kind: Kind, cw: Int, ch: Int, dur: Float) {
    var name by mutableStateOf("")
    var text by mutableStateOf("Motion")
    var color by mutableStateOf(AColor.WHITE)
    var w by mutableStateOf(400f)
    var h by mutableStateOf(240f)
    var inT by mutableStateOf(0f)
    var outT by mutableStateOf(dur)
    var bmp: Bitmap? = null
    val x = Prop(cw / 2f)
    val y = Prop(ch / 2f)
    val scale = Prop(1f)
    val rot = Prop(0f)
    val opacity = Prop(1f)
}

class Comp {
    var cw by mutableStateOf(1280)
    var ch by mutableStateOf(720)
    var dur by mutableStateOf(5f)
    var video by mutableStateOf<Uri?>(null)
    val layers = mutableStateListOf<Layer>()
    var nextId = 1
}

// ======================= المحرك: رسم الطبقات (نفس الكود للمعاينة والتصدير) =======================

fun drawLayers(c: android.graphics.Canvas, layers: List<Layer>, t: Float) {
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    for (l in layers) {
        if (t < l.inT || t > l.outT) continue
        val a = (l.opacity.at(t).coerceIn(0f, 1f) * 255).toInt()
        c.save()
        c.translate(l.x.at(t), l.y.at(t))
        c.rotate(l.rot.at(t))
        val s = l.scale.at(t)
        c.scale(s, s)
        p.color = l.color
        p.alpha = a
        when (l.kind) {
            Kind.TEXT -> {
                p.textAlign = Paint.Align.CENTER
                p.textSize = l.h
                p.isFakeBoldText = true
                val fm = p.fontMetrics
                c.drawText(l.text, 0f, -(fm.ascent + fm.descent) / 2f, p)
            }
            Kind.RECT -> c.drawRect(-l.w / 2f, -l.h / 2f, l.w / 2f, l.h / 2f, p)
            Kind.ELLIPSE -> c.drawOval(RectF(-l.w / 2f, -l.h / 2f, l.w / 2f, l.h / 2f), p)
            Kind.IMAGE -> l.bmp?.let { b -> c.drawBitmap(b, -b.width / 2f, -b.height / 2f, p) }
        }
        c.restore()
    }
}

// ======================= التصدير (Media3 Transformer + طبقة رسم لكل إطار) =======================

fun saveToMovies(ctx: Context, f: File, name: String): Uri {
    val resolver = ctx.contentResolver
    val values = ContentValues().apply {
        put(MediaStore.Video.Media.DISPLAY_NAME, "$name.mp4")
        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
        put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/MotionStudio")
        put(MediaStore.Video.Media.IS_PENDING, 1)
    }
    val out = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
        ?: throw IllegalStateException("تعذر إنشاء الملف")
    try {
        resolver.openOutputStream(out)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
        values.clear()
        values.put(MediaStore.Video.Media.IS_PENDING, 0)
        resolver.update(out, values, null, null)
    } catch (e: Exception) {
        resolver.delete(out, null, null)
        throw e
    } finally {
        f.delete()
    }
    return out
}

suspend fun exportComp(ctx: Context, comp: Comp, onProgress: (Float) -> Unit): Uri = withContext(Dispatchers.Main) {
    val cw = comp.cw
    val ch = comp.ch
    val overlay = object : BitmapOverlay() {
        override fun getBitmap(presentationTimeUs: Long): Bitmap {
            val b = Bitmap.createBitmap(cw, ch, Bitmap.Config.ARGB_8888)
            drawLayers(android.graphics.Canvas(b), comp.layers, presentationTimeUs / 1_000_000f)
            return b
        }
    }
    val fx = listOf<Effect>(
        Presentation.createForWidthAndHeight(cw, ch, Presentation.LAYOUT_SCALE_TO_FIT),
        OverlayEffect(ImmutableList.of<TextureOverlay>(overlay))
    )
    val vid = comp.video
    val item = if (vid != null) {
        EditedMediaItem.Builder(MediaItem.fromUri(vid)).setEffects(Effects(emptyList(), fx)).build()
    } else {
        val bg = File(ctx.cacheDir, "bg.png")
        val bb = Bitmap.createBitmap(cw, ch, Bitmap.Config.ARGB_8888)
        bb.eraseColor(AColor.BLACK)
        bg.outputStream().use { bb.compress(Bitmap.CompressFormat.PNG, 100, it) }
        EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(bg)))
            .setDurationUs((comp.dur * 1_000_000f).toLong())
            .setFrameRate(30)
            .setEffects(Effects(emptyList(), fx))
            .build()
    }
    val out = File(ctx.cacheDir, "out_${System.currentTimeMillis()}.mp4")
    suspendCancellableCoroutine<Unit> { cont ->
        val tr = Transformer.Builder(ctx)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    if (cont.isActive) cont.resume(Unit)
                }

                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    if (cont.isActive) cont.resumeWithException(exportException)
                }
            }).build()
        tr.start(item, out.absolutePath)
        val holder = ProgressHolder()
        val h = Handler(Looper.getMainLooper())
        h.post(object : Runnable {
            override fun run() {
                if (!cont.isActive) return
                if (tr.getProgress(holder) != Transformer.PROGRESS_STATE_NOT_STARTED) onProgress(holder.progress / 100f)
                h.postDelayed(this, 400)
            }
        })
        cont.invokeOnCancellation { tr.cancel() }
    }
    withContext(Dispatchers.IO) { saveToMovies(ctx, out, "Motion_${System.currentTimeMillis()}") }
}

// ======================= الواجهة =======================

val Purple = Color(0xFFA855F7)
val Panel = Color(0xFF15101F)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Purple, onPrimary = Color.White, background = Color.Black, onBackground = Color.White,
                    surface = Color(0xFF0D0716), onSurface = Color.White, surfaceVariant = Panel, outline = Color(0xFF6D3FB0)
                )
            ) {
                Surface(Modifier.fillMaxSize(), color = Color.Black) { Studio() }
            }
        }
    }
}

@Composable
fun PropRow(label: String, p: Prop, range: ClosedFloatingPointRange<Float>, t: Float, mult: Float = 1f) {
    val animated = p.keys.isNotEmpty()
    val v = p.at(t)
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.width(74.dp), fontSize = 12.sp, color = Color.White)
        Slider(
            value = v.coerceIn(range.start, range.endInclusive),
            onValueChange = { nv -> if (animated) p.setKey(t, nv) else p.base = nv },
            valueRange = range, modifier = Modifier.weight(1f),
            colors = SliderDefaults.colors(inactiveTrackColor = Color(0xFF2A1A44))
        )
        Text("%.0f".format(v * mult), Modifier.width(42.dp), fontSize = 12.sp, color = Purple)
        Text(
            if (animated) "⏱" else "◇",
            Modifier.clickable { if (animated) { p.base = v; p.keys.clear() } else p.setKey(t, v) }.padding(8.dp),
            color = if (animated) Purple else Color.Gray, fontSize = 18.sp
        )
    }
}

@Composable
fun LayerRow(l: Layer, dur: Float, t: Float, selected: Boolean, onClick: () -> Unit) {
    val d = maxOf(dur, 0.1f)
    Row(
        Modifier.fillMaxWidth().height(34.dp).background(if (selected) Color(0xFF2A1A44) else Panel).clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(l.name, Modifier.width(84.dp).padding(start = 6.dp), fontSize = 11.sp, color = Color.White, maxLines = 1)
        Canvas(Modifier.weight(1f).fillMaxHeight()) {
            val w = size.width
            drawRect(Purple.copy(alpha = 0.4f), Offset(w * l.inT / d, 6f), Size(w * (l.outT - l.inT) / d, size.height - 12f))
            listOf(l.x, l.y, l.scale, l.rot, l.opacity).flatMap { pr -> pr.keys.map { it.t } }.distinct().forEach { kt ->
                drawCircle(Color.White, 5f, Offset(w * kt / d, size.height / 2f))
            }
            drawLine(Color.Red, Offset(w * t / d, 0f), Offset(w * t / d, size.height), 2f)
        }
    }
}

@Composable
fun Studio() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val comp = remember { Comp() }
    val player = remember { ExoPlayer.Builder(ctx).build() }
    DisposableEffect(Unit) { onDispose { player.release() } }
    var t by remember { mutableStateOf(0f) }
    var playing by remember { mutableStateOf(false) }
    var selId by remember { mutableStateOf(-1) }
    var status by remember { mutableStateOf("أضف طبقات، حرّك الخصائص بالمفاتيح ⏱، ثم صدّر") }
    var exporting by remember { mutableStateOf(false) }
    var prog by remember { mutableStateOf(0f) }
    val sel = comp.layers.firstOrNull { it.id == selId }

    fun loadVideo(u: Uri) {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, u)
            var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 1280
            var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 720
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) { val tmp = w; w = h; h = tmp }
            val d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 5000L
            val sc = minOf(1f, 1280f / maxOf(w, h))
            comp.cw = maxOf(2, (w * sc).toInt() / 2 * 2)
            comp.ch = maxOf(2, (h * sc).toInt() / 2 * 2)
            comp.dur = d / 1000f
            comp.video = u
            comp.layers.forEach { it.outT = comp.dur }
            player.setMediaItem(MediaItem.fromUri(u))
            player.prepare()
            player.playWhenReady = false
            t = 0f
            playing = false
        } finally {
            r.release()
        }
    }

    fun addLayer(kind: Kind, bmp: Bitmap? = null) {
        val l = Layer(comp.nextId++, kind, comp.cw, comp.ch, comp.dur)
        l.name = when (kind) {
            Kind.TEXT -> "نص"
            Kind.RECT -> "مستطيل"
            Kind.ELLIPSE -> "دائرة"
            Kind.IMAGE -> "صورة"
        } + " ${l.id}"
        if (kind == Kind.RECT || kind == Kind.ELLIPSE) l.color = 0xFFA855F7.toInt()
        if (kind == Kind.ELLIPSE) { l.w = 300f; l.h = 300f }
        if (kind == Kind.TEXT) l.h = 110f
        l.bmp = bmp
        comp.layers.add(l)
        selId = l.id
    }

    val pickVideo = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            try { loadVideo(u) } catch (e: Exception) { status = "تعذر فتح الفيديو: ${e.message}" }
        }
    }
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            try {
                val raw = ctx.contentResolver.openInputStream(u)!!.use { BitmapFactory.decodeStream(it) }
                val sc = minOf(1f, 1024f / maxOf(raw.width, raw.height))
                val b = if (sc < 1f) Bitmap.createScaledBitmap(raw, (raw.width * sc).toInt(), (raw.height * sc).toInt(), true) else raw
                addLayer(Kind.IMAGE, b)
            } catch (e: Exception) {
                status = "تعذر فتح الصورة: ${e.message}"
            }
        }
    }

    LaunchedEffect(playing, comp.video) {
        if (!playing) {
            player.pause()
            return@LaunchedEffect
        }
        if (comp.video != null) {
            player.seekTo((t * 1000).toLong())
            player.play()
            while (true) {
                withFrameNanos { }
                t = minOf(player.currentPosition / 1000f, comp.dur)
                if (t >= comp.dur - 0.03f || player.playbackState == Player.STATE_ENDED) {
                    playing = false
                    break
                }
            }
        } else {
            var last = withFrameNanos { it }
            while (true) {
                val now = withFrameNanos { it }
                t += (now - last) / 1e9f
                last = now
                if (t >= comp.dur) {
                    t = comp.dur
                    playing = false
                    break
                }
            }
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(10.dp)) {
        // ---- المعاينة ----
        Box(Modifier.fillMaxWidth().aspectRatio(comp.cw.toFloat() / comp.ch).background(Color(0xFF111111))) {
            if (comp.video != null) {
                AndroidView(
                    factory = { c -> SurfaceView(c).also { player.setVideoSurfaceView(it) } },
                    modifier = Modifier.fillMaxSize()
                )
            }
            Canvas(Modifier.fillMaxSize()) {
                val sc = size.width / comp.cw
                drawIntoCanvas { cv ->
                    val c = cv.nativeCanvas
                    c.save()
                    c.scale(sc, sc)
                    drawLayers(c, comp.layers, t)
                    c.restore()
                }
            }
        }
        // ---- التشغيل والزمن ----
        Row(verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = {
                if (t >= comp.dur - 0.05f) t = 0f
                playing = !playing
            }) { Text(if (playing) "⏸" else "▶") }
            Slider(
                value = t.coerceIn(0f, maxOf(comp.dur, 0.1f)),
                onValueChange = { v ->
                    t = v
                    playing = false
                    if (comp.video != null) player.seekTo((v * 1000).toLong())
                },
                valueRange = 0f..maxOf(comp.dur, 0.1f), modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                colors = SliderDefaults.colors(inactiveTrackColor = Color(0xFF2A1A44))
            )
            Text("%.1f / %.1f".format(t, comp.dur), fontSize = 12.sp, color = Purple)
        }
        // ---- شريط الأدوات ----
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedButton(onClick = { pickVideo.launch(arrayOf("video/*")) }) { Text("🎬 فيديو") }
            OutlinedButton(onClick = { addLayer(Kind.TEXT) }) { Text("+ نص") }
            OutlinedButton(onClick = { addLayer(Kind.RECT) }) { Text("+ مستطيل") }
            OutlinedButton(onClick = { addLayer(Kind.ELLIPSE) }) { Text("+ دائرة") }
            OutlinedButton(onClick = { pickImage.launch(arrayOf("image/*")) }) { Text("+ صورة") }
            Button(enabled = !exporting, onClick = {
                exporting = true
                prog = 0f
                status = "جاري التصدير..."
                scope.launch {
                    try {
                        exportComp(ctx, comp) { prog = it }
                        status = "تم! الفيديو في Movies/MotionStudio"
                    } catch (e: Exception) {
                        status = "فشل التصدير: ${e.message}"
                    }
                    exporting = false
                }
            }) { Text("⬇ تصدير") }
        }
        if (comp.video == null) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("مدة التركيبة: %.0f ثانية".format(comp.dur), fontSize = 12.sp, color = Color.White)
                Slider(
                    value = comp.dur, onValueChange = { d -> comp.dur = d; comp.layers.forEach { it.outT = d } },
                    valueRange = 1f..30f, modifier = Modifier.weight(1f).padding(start = 8.dp),
                    colors = SliderDefaults.colors(inactiveTrackColor = Color(0xFF2A1A44))
                )
            }
        }
        Text(status, color = Purple, fontSize = 13.sp)
        if (exporting) {
            LinearProgressIndicator(progress = { prog.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth(), color = Purple, trackColor = Color(0xFF2A1A44))
        }
        // ---- الخط الزمني ----
        Spacer(Modifier.height(6.dp))
        Text("الطبقات والخط الزمني", color = Color.White, fontWeight = FontWeight.Bold)
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            comp.layers.reversed().forEach { l ->
                LayerRow(l, comp.dur, t, l.id == selId) { selId = l.id }
            }
        }
        // ---- خصائص الطبقة المحددة ----
        if (sel != null) {
            Spacer(Modifier.height(8.dp))
            Text("خصائص: ${sel.name}", color = Purple, fontWeight = FontWeight.Bold)
            if (sel.kind == Kind.TEXT) {
                OutlinedTextField(value = sel.text, onValueChange = { sel.text = it }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("حجم الخط", Modifier.width(74.dp), fontSize = 12.sp, color = Color.White)
                    Slider(value = sel.h, onValueChange = { sel.h = it }, valueRange = 20f..400f, modifier = Modifier.weight(1f))
                }
            } else if (sel.kind != Kind.IMAGE) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("العرض", Modifier.width(74.dp), fontSize = 12.sp, color = Color.White)
                    Slider(value = sel.w, onValueChange = { sel.w = it }, valueRange = 20f..1200f, modifier = Modifier.weight(1f))
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("الارتفاع", Modifier.width(74.dp), fontSize = 12.sp, color = Color.White)
                    Slider(value = sel.h, onValueChange = { sel.h = it }, valueRange = 20f..1200f, modifier = Modifier.weight(1f))
                }
            }
            if (sel.kind != Kind.IMAGE) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 4.dp)) {
                    listOf(AColor.WHITE, 0xFFA855F7.toInt(), 0xFFEF4444.toInt(), 0xFF22C55E.toInt(), 0xFF3B82F6.toInt(), 0xFFFACC15.toInt()).forEach { c ->
                        Box(Modifier.size(30.dp).background(Color(c)).clickable { sel.color = c })
                    }
                }
            }
            PropRow("الموضع X", sel.x, 0f..comp.cw.toFloat(), t)
            PropRow("الموضع Y", sel.y, 0f..comp.ch.toFloat(), t)
            PropRow("الحجم %", sel.scale, 0f..4f, t, 100f)
            PropRow("الدوران", sel.rot, -360f..360f, t)
            PropRow("الشفافية %", sel.opacity, 0f..1f, t, 100f)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("البداية", Modifier.width(74.dp), fontSize = 12.sp, color = Color.White)
                Slider(value = sel.inT, onValueChange = { sel.inT = minOf(it, sel.outT) }, valueRange = 0f..maxOf(comp.dur, 0.1f), modifier = Modifier.weight(1f))
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("النهاية", Modifier.width(74.dp), fontSize = 12.sp, color = Color.White)
                Slider(value = sel.outT, onValueChange = { sel.outT = maxOf(it, sel.inT) }, valueRange = 0f..maxOf(comp.dur, 0.1f), modifier = Modifier.weight(1f))
            }
            OutlinedButton(onClick = { comp.layers.remove(sel); selId = -1 }) { Text("🗑 حذف الطبقة") }
        }
        Spacer(Modifier.height(24.dp))
    }
}
