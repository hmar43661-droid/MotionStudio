# Motion Studio — حالة المشروع (آخر نقطة)

## المحتوى
- جذر الـ ZIP = مشروع Android كامل (settings.gradle.kts, build.gradle.kts, app/...). يُبنى كما هو عبر GitHub Actions.
- app/src/main/java/com/motion/studio/ : تطبيق Kotlin v0.2 (يعمل ومثبّت عندك): Model.kt, Ui.kt, Export.kt, MainActivity.kt.
- app/src/main/cpp/ : محرك C++ (engine.h, engine.cpp) — مكتمل ومُختبر على سطح المكتب، **غير مربوط بعد بـ Kotlin/Gradle**.
- engine_tests/ : اختبارات المحرك (engine_test.cpp) وقياس الأداء (bench.cpp).
- github_workflow/build.yml : ملف البناء المستخدم على GitHub.

## حالة المحرك
- الربط مع Kotlin: لا يوجد (لا JNI، لا CMake، لا externalNativeBuild، لا System.loadLibrary). التطبيق ما زال يرسم بكود Kotlin (drawLayers في Model.kt).
- المحرك يعمل على CPU (لا GLES/GLSL/Vulkan بعد، ولا Custom Shaders).
- اختبارات سطح المكتب (g++ 13, x86): 51/51 ناجحة، ونظيفة تحت AddressSanitizer + UBSan.
  الأمر من جذر المشروع:
  g++ -std=c++17 -O3 -Iapp/src/main/cpp engine_tests/engine_test.cpp app/src/main/cpp/engine.cpp -o t && ./t
- لم تُجرَّب: بناء NDK/CMake، ملفات Kotlin، الأداء على هاتف حقيقي.
- بعض الاختبارات "تشغيل بدون انهيار فقط" (Grain, Chromatic Aberration, Lens Distortion, Radial/Cross Blur, Emboss).

## المؤثرات في المحرك (id: المعاملات)
0 Brightness[amount] · 1 Contrast[k] · 2 Saturation[s] · 3 Hue[deg] · 4 Invert[a] · 5 Sepia[a]
6 ColorCorrection[exposure,gamma,temperature,tint] · 7 Curves[shadows,mids,highlights,contrast]
8 HSL[hue,sat,light] · 9 Tone[exposure,gamma,contrast,highlights,shadows,whites,blacks]
10 GaussianBlur[radius] · 11 DirectionalBlur[length,angle] · 12 RadialBlur[amount,cx,cy] · 13 CrossBlur[h,v]
14 Glow[intensity,radius,threshold] · 15 Vignette[amount,size,softness] · 16 Grain[amount,speed]
17 RGBSplit[amount,angle] · 18 ChromaticAberration[strength] · 19 Mosaic[size] · 20 Mirror[mode 0-4]
21 LensDistortion[k] · 22 FindEdges[strength,invert] · 23 Emboss[strength,angle]
24 ChromaKey[hue,tolerance,softness,spill] · 25 Mask[shape,cx,cy,w,h,feather,invert] · 26 Shake[amount,speed]
Blend modes: 0 Normal, 1 Add, 2 Multiply, 3 Screen, 4 Overlay.

## المتبقي لإكمال نسخة قابلة للبناء بالمحرك (بدون ميزات جديدة)
1. app/src/main/cpp/jni_bridge.cpp (تصميم الـ blob أدناه) + اختبار بـ JNI وهمي على سطح المكتب.
2. app/src/main/cpp/CMakeLists.txt + externalNativeBuild و abiFilters (arm64-v8a) في app/build.gradle.kts.
3. Engine.kt (loadLibrary + دوال external + Renderer يرمّز المشهد ويرسم النص/الأشكال إلى Bitmap كنسيج).
4. استبدال استدعاءات drawLayers الثلاثة: Ui.kt (المعاينة)، Export.kt (BitmapOverlay)، Model.kt (الصورة المصغرة).
5. Fx متعددة المعاملات في Model.kt مع ربط الـ ids أعلاه والحفاظ على توافق المشاريع القديمة؛ ثم قائمة المؤثرات ولوحة المعاملات في Ui.kt.
6. ربط Preview Resolution بحجم الرسم في المحرك.
7. بناء على GitHub Actions وإصلاح الأخطاء، ثم تجربة على الهاتف (المعاينة والتصدير).
بعدها فقط: إعادة تصميم الواجهة، GPU، الصوت، Custom Shaders.

## تصميم الـ blob المخطط لـ JNI (لم يُنفَّذ بعد)
blob := [nLayers] layer*
layer := [kind,visible,inT,outT,bw,bh,r,g,b,a,blend] + 9 props(px,py,sx,sy,pvx,pvy,rrev,rdeg,op) + [nFx] + fx*
fx := [type,nParams] + prop*      prop := [base,smooth,nKeys,(t,v)*nKeys]
render(handle, t, outBitmap, textures[], onlyIndex) — ملمس لكل طبقة (Bitmap) بنفس ترتيب الطبقات.

## ملاحظات صادقة
- الصوت (استيراد/تصدير) غير موجود في v0.2 ولا في المحرك بعد.
- التطبيق الحالي (v0.2) فيه مشاكل تصميم معروفة (لوحة مقطوعة، رموز نصية غريبة) — إعادة التصميم مؤجلة.
