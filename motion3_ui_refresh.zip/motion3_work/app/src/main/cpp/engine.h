// Motion Studio engine (C++17): keyframes, layer transforms, effects and compositing.
// Pure C++ (no Android dependencies) so it can be unit-tested on a desktop.
#pragma once
#include <cstdint>
#include <vector>

namespace mo {

struct Key { float t, v; };

struct Prop {
    float base = 0.f;
    bool smooth = true;
    std::vector<Key> keys;
    float at(float t) const;
};

enum FxType {
    FX_BRIGHTNESS = 0, FX_CONTRAST = 1, FX_SATURATION = 2, FX_HUE = 3, FX_INVERT = 4, FX_SEPIA = 5,
    FX_COLORCORRECT = 6, FX_CURVES = 7, FX_HSL = 8, FX_TONE = 9,
    FX_GAUSS = 10, FX_DIRBLUR = 11, FX_RADIALBLUR = 12, FX_CROSSBLUR = 13, FX_GLOW = 14,
    FX_VIGNETTE = 15, FX_GRAIN = 16, FX_RGBSPLIT = 17, FX_CHROMAAB = 18,
    FX_MOSAIC = 19, FX_MIRROR = 20, FX_LENSDIST = 21, FX_FINDEDGES = 22, FX_EMBOSS = 23,
    FX_CHROMAKEY = 24, FX_MASK = 25, FX_SHAKE = 26
};

enum Blend { BL_NORMAL = 0, BL_ADD = 1, BL_MULTIPLY = 2, BL_SCREEN = 3, BL_OVERLAY = 4 };

struct Effect {
    int type = 0;
    std::vector<Prop> p;
};

struct Layer {
    int kind = 1;               // 0 = skip (video), 1 = bitmap texture, 2 = solid fill
    bool visible = true;
    float inT = 0.f, outT = 10.f;
    float bw = 1.f, bh = 1.f;   // box size in composition units
    float color[4] = {1.f, 1.f, 1.f, 1.f};  // straight RGBA (fill layers)
    int blend = BL_NORMAL;
    Prop px, py, sx, sy, pvx, pvy, rrev, rdeg, op;
    std::vector<Effect> fx;
};

struct Scene {
    int cw = 1280, ch = 720;
    std::vector<Layer> layers;
};

// Premultiplied RGBA8888 texture (as provided by Android Bitmap ARGB_8888)
struct Tex {
    const uint8_t* px = nullptr;
    int w = 0, h = 0, stride = 0;
};

// Renders the scene at time t into `out` (premultiplied RGBA8888, outW x outH).
// onlyIndex >= 0 renders only that layer.
void render(const Scene& sc, float t, int outW, int outH, uint8_t* out, int outStride,
            const std::vector<Tex>& tex, int onlyIndex);

}  // namespace mo
