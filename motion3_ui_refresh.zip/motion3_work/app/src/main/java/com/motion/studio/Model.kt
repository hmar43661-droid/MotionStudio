package com.motion.studio

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color as AColor
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.DashPathEffect
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

enum class Kind { VIDEO, TEXT, RECT, ELLIPSE, FILL, IMAGE }

class Key(val t: Float, val v: Float)

/** خاصية قابلة للتحريك (Stopwatch): قيمة ثابتة أو مفاتيح حركة */
class Prop(val initial: Float) {
    var base by mutableStateOf(initial)
    var smooth by mutableStateOf(true)
    val keys = mutableStateListOf<Key>()

    fun setKey(t: Float, v: Float) {
        val i = keys.indexOfFirst { kotlin.math.abs(it.t - t) < 0.02f }
        if (i >= 0) keys.removeAt(i)
        keys.add(Key(t, v))
        keys.sortBy { it.t }
    }

    fun at(t: Float): Float {
        if (keys.isEmpty()) return base
        if (t <= keys.first().t) return keys.first().v
        if (t >= keys.last().t) return keys.last().v
        for (i in 0 until keys.size - 1) {
            val a = keys[i]
            val b = keys[i + 1]
            if (t >= a.t && t <= b.t) {
                val f = (t - a.t) / (b.t - a.t)
                val e = if (smooth) f * f * (3f - 2f * f) else f
                return a.v + (b.v - a.v) * e
            }
        }
        return keys.last().v
    }

    fun toJson(): JSONObject {
        val a = JSONArray()
        keys.forEach { a.put(JSONArray().put(it.t.toDouble()).put(it.v.toDouble())) }
        return JSONObject().put("b", base.toDouble()).put("s", smooth).put("k", a)
    }

    fun fromJson(o: JSONObject?) {
        if (o == null) return
        base = o.optDouble("b", initial.toDouble()).toFloat()
        smooth = o.optBoolean("s", true)
        keys.clear()
        val a = o.optJSONArray("k")
        if (a != null) for (i in 0 until a.length()) {
            val k = a.getJSONArray(i)
            keys.add(Key(k.getDouble(0).toFloat(), k.getDouble(1).toFloat()))
        }
    }
}

/** مؤثر على الطبقة: brightness / contrast / saturation */
class Fx(val type: String) {
    val amount = Prop(if (type == "brightness") 0f else 1f)
}

class Layer(val id: Int, val kind: Kind) {
    var name by mutableStateOf("")
    var text by mutableStateOf("Text")
    var color by mutableStateOf(AColor.WHITE)
    var w by mutableStateOf(400f)
    var h by mutableStateOf(240f)
    var inT by mutableStateOf(0f)
    var outT by mutableStateOf(10f)
    var visible by mutableStateOf(true)
    var linkScale by mutableStateOf(true)
    var uri: Uri? = null
    var bmp: Bitmap? = null
    var imgFile: String? = null
    val px = Prop(0.5f)
    val py = Prop(0.5f)
    val sx = Prop(1f)
    val sy = Prop(1f)
    val pvx = Prop(0.5f)
    val pvy = Prop(0.5f)
    val rrev = Prop(0f)
    val rdeg = Prop(0f)
    val op = Prop(1f)
    val effects = mutableStateListOf<Fx>()

    fun allProps(): List<Prop> = listOf(px, py, sx, sy, pvx, pvy, rrev, rdeg, op) + effects.map { it.amount }
}

class Comp {
    var name by mutableStateOf("Untitled")
    var cw by mutableStateOf(1280)
    var ch by mutableStateOf(720)
    var dur by mutableStateOf(10f)
    var fps by mutableStateOf(30)
    var ratio by mutableStateOf("16:9")
    var previewRes by mutableStateOf(50)
    var renderMode by mutableStateOf("Current Layer")
    var nextId = 1
    val layers = mutableStateListOf<Layer>()
    val markers = mutableStateListOf<Float>()
}

// ===================== الرسم (نفس الكود للمعاينة والتصدير) =====================

fun boxSize(l: Layer, cw: Int, ch: Int): Pair<Float, Float> = when (l.kind) {
    Kind.TEXT -> {
        val p = Paint()
        p.textSize = l.h
        p.isFakeBoldText = true
        val fm = p.fontMetrics
        p.measureText(l.text) to (fm.descent - fm.ascent)
    }
    Kind.RECT, Kind.ELLIPSE -> l.w to l.h
    Kind.IMAGE -> (l.bmp?.width ?: 1).toFloat() to (l.bmp?.height ?: 1).toFloat()
    else -> cw.toFloat() to ch.toFloat()
}

fun layerMatrix(l: Layer, t: Float, cw: Int, ch: Int): Matrix {
    val (bw, bh) = boxSize(l, cw, ch)
    val m = Matrix()
    m.postTranslate(-l.pvx.at(t) * bw, -l.pvy.at(t) * bh)
    m.postScale(l.sx.at(t), l.sy.at(t))
    m.postRotate(l.rrev.at(t) * 360f + l.rdeg.at(t))
    m.postTranslate(l.px.at(t) * cw, l.py.at(t) * ch)
    return m
}

fun fxFilter(l: Layer, t: Float): ColorMatrixColorFilter? {
    if (l.effects.isEmpty()) return null
    val cm = ColorMatrix()
    for (e in l.effects) {
        val v = e.amount.at(t)
        when (e.type) {
            "brightness" -> cm.postConcat(ColorMatrix(floatArrayOf(
                1f, 0f, 0f, 0f, v * 255f, 0f, 1f, 0f, 0f, v * 255f, 0f, 0f, 1f, 0f, v * 255f, 0f, 0f, 0f, 1f, 0f)))
            "contrast" -> {
                val tr = (1f - v) * 128f
                cm.postConcat(ColorMatrix(floatArrayOf(
                    v, 0f, 0f, 0f, tr, 0f, v, 0f, 0f, tr, 0f, 0f, v, 0f, tr, 0f, 0f, 0f, 1f, 0f)))
            }
            "saturation" -> {
                val s = ColorMatrix()
                s.setSaturation(v)
                cm.postConcat(s)
            }
        }
    }
    return ColorMatrixColorFilter(cm)
}

fun drawLayers(c: Canvas, comp: Comp, t: Float) {
    val p = Paint()
    for (l in comp.layers) {
        if (!l.visible || l.kind == Kind.VIDEO || t < l.inT || t > l.outT) continue
        c.save()
        c.concat(layerMatrix(l, t, comp.cw, comp.ch))
        p.reset()
        p.isAntiAlias = true
        p.color = l.color
        p.alpha = (l.op.at(t).coerceIn(0f, 1f) * 255f).toInt()
        p.colorFilter = fxFilter(l, t)
        when (l.kind) {
            Kind.TEXT -> {
                p.textSize = l.h
                p.isFakeBoldText = true
                c.drawText(l.text, 0f, -p.fontMetrics.ascent, p)
            }
            Kind.RECT -> c.drawRect(0f, 0f, l.w, l.h, p)
            Kind.ELLIPSE -> c.drawOval(RectF(0f, 0f, l.w, l.h), p)
            Kind.FILL -> c.drawRect(0f, 0f, comp.cw.toFloat(), comp.ch.toFloat(), p)
            Kind.IMAGE -> l.bmp?.let { b -> c.drawBitmap(b, 0f, 0f, p) }
            else -> {}
        }
        c.restore()
    }
}

fun drawSelection(c: Canvas, comp: Comp, l: Layer, t: Float) {
    val (bw, bh) = boxSize(l, comp.cw, comp.ch)
    val pts = floatArrayOf(0f, 0f, bw, 0f, bw, bh, 0f, bh, bw / 2f, 0f, bw, bh / 2f, bw / 2f, bh, 0f, bh / 2f)
    layerMatrix(l, t, comp.cw, comp.ch).mapPoints(pts)
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.style = Paint.Style.STROKE
    p.strokeWidth = 3f
    p.color = AColor.argb(210, 255, 255, 255)
    p.pathEffect = DashPathEffect(floatArrayOf(10f, 8f), 0f)
    val path = Path()
    path.moveTo(pts[0], pts[1])
    for (i in 1..3) path.lineTo(pts[i * 2], pts[i * 2 + 1])
    path.close()
    c.drawPath(path, p)
    p.style = Paint.Style.FILL
    p.pathEffect = null
    p.color = AColor.argb(210, 190, 190, 190)
    for (i in 4..7) c.drawRect(pts[i * 2] - 9f, pts[i * 2 + 1] - 9f, pts[i * 2] + 9f, pts[i * 2 + 1] + 9f, p)
}

// ===================== الفيديو =====================

fun addVideoLayer(ctx: Context, comp: Comp, u: Uri) {
    val r = MediaMetadataRetriever()
    try {
        r.setDataSource(ctx, u)
        var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 1280
        var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 720
        val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
        if (rot == 90 || rot == 270) { val tmp = w; w = h; h = tmp }
        val d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 5000L
        val sc = minOf(1f, 1280f / maxOf(w, h))
        comp.cw = maxOf(2, (w * sc).toInt() / 2 * 2)
        comp.ch = maxOf(2, (h * sc).toInt() / 2 * 2)
        comp.ratio = "Custom"
        comp.dur = d / 1000f
        comp.layers.removeAll { it.kind == Kind.VIDEO }
        val l = Layer(comp.nextId++, Kind.VIDEO)
        l.name = "Video"
        l.uri = u
        l.outT = comp.dur
        comp.layers.forEach { it.outT = comp.dur }
        comp.layers.add(0, l)
    } finally {
        r.release()
    }
}

// ===================== حفظ المشاريع =====================

class ProjInfo(val id: String, val name: String, val modified: Long, val size: Long, val thumb: Bitmap?)

object Store {
    fun dir(ctx: Context): File = File(ctx.filesDir, "projects").also { it.mkdirs() }

    fun layerToJson(l: Layer): JSONObject {
        val fx = JSONArray()
        l.effects.forEach { fx.put(JSONObject().put("t", it.type).put("a", it.amount.toJson())) }
        val pr = JSONObject()
            .put("px", l.px.toJson()).put("py", l.py.toJson()).put("sx", l.sx.toJson()).put("sy", l.sy.toJson())
            .put("pvx", l.pvx.toJson()).put("pvy", l.pvy.toJson()).put("rrev", l.rrev.toJson())
            .put("rdeg", l.rdeg.toJson()).put("op", l.op.toJson())
        return JSONObject().put("id", l.id).put("kind", l.kind.name).put("name", l.name).put("text", l.text)
            .put("color", l.color).put("w", l.w.toDouble()).put("h", l.h.toDouble())
            .put("in", l.inT.toDouble()).put("out", l.outT.toDouble()).put("vis", l.visible)
            .put("link", l.linkScale).put("uri", l.uri?.toString() ?: "").put("img", l.imgFile ?: "")
            .put("props", pr).put("fx", fx)
    }

    fun compToJson(c: Comp): JSONObject {
        val la = JSONArray()
        c.layers.forEach { la.put(layerToJson(it)) }
        val mk = JSONArray()
        c.markers.forEach { mk.put(it.toDouble()) }
        return JSONObject().put("name", c.name).put("cw", c.cw).put("ch", c.ch).put("dur", c.dur.toDouble())
            .put("fps", c.fps).put("ratio", c.ratio).put("pres", c.previewRes).put("mode", c.renderMode)
            .put("next", c.nextId).put("markers", mk).put("layers", la)
    }

    fun layerFromJson(o: JSONObject, cache: Map<Int, Bitmap>, d: File): Layer {
        val l = Layer(o.getInt("id"), Kind.valueOf(o.getString("kind")))
        l.name = o.optString("name")
        l.text = o.optString("text", "Text")
        l.color = o.optInt("color", AColor.WHITE)
        l.w = o.optDouble("w", 400.0).toFloat()
        l.h = o.optDouble("h", 240.0).toFloat()
        l.inT = o.optDouble("in", 0.0).toFloat()
        l.outT = o.optDouble("out", 10.0).toFloat()
        l.visible = o.optBoolean("vis", true)
        l.linkScale = o.optBoolean("link", true)
        val u = o.optString("uri")
        l.uri = if (u.isNotEmpty()) Uri.parse(u) else null
        l.imgFile = o.optString("img").ifEmpty { null }
        l.bmp = cache[l.id] ?: l.imgFile?.let { fn ->
            val f = File(d, fn)
            if (f.exists()) BitmapFactory.decodeFile(f.path) else null
        }
        val pr = o.optJSONObject("props")
        if (pr != null) {
            l.px.fromJson(pr.optJSONObject("px")); l.py.fromJson(pr.optJSONObject("py"))
            l.sx.fromJson(pr.optJSONObject("sx")); l.sy.fromJson(pr.optJSONObject("sy"))
            l.pvx.fromJson(pr.optJSONObject("pvx")); l.pvy.fromJson(pr.optJSONObject("pvy"))
            l.rrev.fromJson(pr.optJSONObject("rrev")); l.rdeg.fromJson(pr.optJSONObject("rdeg"))
            l.op.fromJson(pr.optJSONObject("op"))
        }
        val fx = o.optJSONArray("fx")
        if (fx != null) for (i in 0 until fx.length()) {
            val e = Fx(fx.getJSONObject(i).getString("t"))
            e.amount.fromJson(fx.getJSONObject(i).optJSONObject("a"))
            l.effects.add(e)
        }
        return l
    }

    fun applyJson(c: Comp, o: JSONObject, cache: Map<Int, Bitmap>, d: File) {
        c.name = o.optString("name", "Untitled")
        c.cw = o.optInt("cw", 1280)
        c.ch = o.optInt("ch", 720)
        c.dur = o.optDouble("dur", 10.0).toFloat()
        c.fps = o.optInt("fps", 30)
        c.ratio = o.optString("ratio", "16:9")
        c.previewRes = o.optInt("pres", 50)
        c.renderMode = o.optString("mode", "Current Layer")
        c.nextId = o.optInt("next", 1)
        c.layers.clear()
        val a = o.optJSONArray("layers")
        if (a != null) for (i in 0 until a.length()) c.layers.add(layerFromJson(a.getJSONObject(i), cache, d))
        c.markers.clear()
        val mk = o.optJSONArray("markers")
        if (mk != null) for (i in 0 until mk.length()) c.markers.add(mk.getDouble(i).toFloat())
    }

    fun save(ctx: Context, id: String, c: Comp, withThumb: Boolean) {
        val d = dir(ctx)
        c.layers.forEach { l ->
            val b = l.bmp
            if (l.kind == Kind.IMAGE && b != null) {
                val fn = "${id}_${l.id}.png"
                val f = File(d, fn)
                if (!f.exists()) f.outputStream().use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
                l.imgFile = fn
            }
        }
        File(d, "$id.json").writeText(compToJson(c).toString())
        if (withThumb) thumb(ctx, id, c)
    }

    private fun thumb(ctx: Context, id: String, c: Comp) {
        try {
            val tw = 320
            val th = (320f * c.ch / c.cw).toInt().coerceAtLeast(1)
            val bmp = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(AColor.BLACK)
            val cv = Canvas(bmp)
            val vu = c.layers.firstOrNull { it.kind == Kind.VIDEO }?.uri
            if (vu != null) {
                val r = MediaMetadataRetriever()
                try {
                    r.setDataSource(ctx, vu)
                    r.getFrameAtTime(0)?.let { cv.drawBitmap(Bitmap.createScaledBitmap(it, tw, th, true), 0f, 0f, null) }
                } finally {
                    r.release()
                }
            }
            cv.scale(tw.toFloat() / c.cw, th.toFloat() / c.ch)
            drawLayers(cv, c, 0f)
            File(dir(ctx), "$id.jpg").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 80, it) }
        } catch (e: Exception) {
        }
    }

    fun load(ctx: Context, id: String): Comp {
        val c = Comp()
        applyJson(c, JSONObject(File(dir(ctx), "$id.json").readText()), emptyMap(), dir(ctx))
        return c
    }

    fun list(ctx: Context): List<ProjInfo> {
        val d = dir(ctx)
        val files = d.listFiles { f -> f.extension == "json" } ?: return emptyList()
        return files.map { f ->
            val id = f.nameWithoutExtension
            val name = try { JSONObject(f.readText()).optString("name", "Untitled") } catch (e: Exception) { "Untitled" }
            val size = d.listFiles { x -> x.name.startsWith(id) }?.sumOf { it.length() } ?: f.length()
            val th = File(d, "$id.jpg").takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path) }
            ProjInfo(id, name, f.lastModified(), size, th)
        }.sortedByDescending { it.modified }
    }

    fun delete(ctx: Context, id: String) {
        dir(ctx).listFiles { x -> x.name.startsWith(id) }?.forEach { it.delete() }
    }
}
