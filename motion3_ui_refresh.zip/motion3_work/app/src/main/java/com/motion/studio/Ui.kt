package com.motion.studio

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Paint
import android.net.Uri
import android.view.SurfaceView
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

// ===================== الألوان (ثيم Node Video: داكن + وردي) =====================
// Motion Studio visual refresh: deep graphite with violet + electric-cyan accents.
val Pink = Color(0xFF8B7CFF)
val PinkText = Color(0xFFB7AEFF)
val BgDark = Color(0xFF0B0D14)
val RowBg = Color(0xFF111521)
val HeadBg = Color(0xFF1B2030)
val GreenBar = Color(0xFF786BFF)
val SurfaceCard = Color(0xFF151A27)
val SurfaceRaised = Color(0xFF20273A)
val AccentCyan = Color(0xFF62D9E8)

class MItem(val label: String, val sub: String? = null, val soon: Boolean = false, val act: () -> Unit = {})

fun tc(s: Float, fps: Int): String {
    val total = (s * fps).toInt()
    val f = total % fps
    val sec = total / fps
    return "%d:%02d:%02d:%02d".format(sec / 3600, (sec / 60) % 60, sec % 60, f)
}

// ===================== مكونات صغيرة =====================

@Composable
fun TIcon(kind: String, color: Color = Color.White) {
    Canvas(Modifier.size(28.dp)) {
        val w = size.width
        val h = size.height
        when (kind) {
            "play" -> drawPath(Path().apply {
                moveTo(w * 0.25f, h * 0.12f); lineTo(w * 0.88f, h * 0.5f); lineTo(w * 0.25f, h * 0.88f); close()
            }, color)
            "pause" -> {
                drawRect(color, Offset(w * 0.2f, h * 0.15f), Size(w * 0.2f, h * 0.7f))
                drawRect(color, Offset(w * 0.6f, h * 0.15f), Size(w * 0.2f, h * 0.7f))
            }
            "prev" -> {
                drawRect(color, Offset(w * 0.12f, h * 0.15f), Size(w * 0.12f, h * 0.7f))
                drawPath(Path().apply {
                    moveTo(w * 0.9f, h * 0.15f); lineTo(w * 0.3f, h * 0.5f); lineTo(w * 0.9f, h * 0.85f); close()
                }, color)
            }
            "next" -> {
                drawRect(color, Offset(w * 0.76f, h * 0.15f), Size(w * 0.12f, h * 0.7f))
                drawPath(Path().apply {
                    moveTo(w * 0.1f, h * 0.15f); lineTo(w * 0.7f, h * 0.5f); lineTo(w * 0.1f, h * 0.85f); close()
                }, color)
            }
            "watch" -> {
                val r = w * 0.36f
                val c = Offset(w / 2f, h * 0.58f)
                drawCircle(color, r, c, style = Stroke(3.5f))
                drawRect(color, Offset(w * 0.4f, h * 0.06f), Size(w * 0.2f, h * 0.1f))
                drawLine(color, c, Offset(c.x, c.y - r * 0.62f), 3.5f)
                drawLine(color, c, Offset(c.x + r * 0.4f, c.y), 3.5f)
            }
        }
    }
}

@Composable
fun ValueField(v: Float, fmt: String, step: Float, onStart: () -> Unit, onChange: (Float) -> Unit) {
    var edit by remember { mutableStateOf(false) }
    val cur by rememberUpdatedState(v)
    val onS by rememberUpdatedState(onStart)
    val onC by rememberUpdatedState(onChange)
    Text(
        fmt.format(v),
        Modifier
            .pointerInput(step) {
                var acc = 0f
                detectHorizontalDragGestures(onDragStart = { acc = cur; onS() }) { _, dx ->
                    acc += dx * step
                    onC(acc)
                }
            }
            .clickable { edit = true }
            .padding(horizontal = 10.dp, vertical = 12.dp),
        color = PinkText, fontSize = 18.sp
    )
    if (edit) {
        var txt by remember { mutableStateOf(fmt.format(v)) }
        AlertDialog(
            onDismissRequest = { edit = false },
            confirmButton = {
                TextButton(onClick = {
                    onStart()
                    txt.toFloatOrNull()?.let { onChange(it) }
                    edit = false
                }) { Text("OK", color = Pink) }
            },
            dismissButton = { TextButton(onClick = { edit = false }) { Text("Cancel", color = Color.Gray) } },
            text = {
                OutlinedTextField(
                    value = txt, onValueChange = { txt = it }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
            }
        )
    }
}

@Composable
fun TRow(
    label: String, vals: List<Float>, fmts: List<String>, steps: List<Float>, animated: Boolean,
    mid: (@Composable () -> Unit)?, onStart: () -> Unit, onChange: (Int, Float) -> Unit,
    onWatch: () -> Unit, onGear: () -> Unit, trailing: (@Composable () -> Unit)? = null
) {
    Row(Modifier.fillMaxWidth().height(50.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(52.dp).fillMaxHeight().clickable(onClick = onWatch), contentAlignment = Alignment.Center) {
            TIcon("watch", if (animated) PinkText else Color.White)
        }
        Text("⚙", Modifier.width(52.dp).clickable(onClick = onGear), color = Color.White, fontSize = 22.sp, textAlign = TextAlign.Center)
        Text(label, Modifier.weight(1f), color = Color.White, fontSize = 20.sp)
        vals.forEachIndexed { i, v ->
            if (i == 1 && mid != null) mid()
            ValueField(v, fmts[i], steps[i], onStart) { nv -> onChange(i, nv) }
        }
        trailing?.invoke()
    }
}

@Composable
fun PanelHeader(left: String, title: String, right: String = "", onRight: () -> Unit = {}) {
    Row(Modifier.fillMaxWidth().height(54.dp).background(HeadBg), verticalAlignment = Alignment.CenterVertically) {
        Text(left, Modifier.width(56.dp), color = Color.White, fontSize = 24.sp, textAlign = TextAlign.Center)
        Text(title, Modifier.weight(1f), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Text(right, Modifier.width(56.dp).clickable(onClick = onRight), color = Color.White, fontSize = 24.sp, textAlign = TextAlign.Center)
    }
}

@Composable
fun SettingRow(label: String, value: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().height(54.dp).clickable(onClick = onClick).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), color = Color.White, fontSize = 20.sp)
        Text(value, color = PinkText, fontSize = 20.sp, modifier = Modifier.padding(end = 40.dp))
    }
}

@Composable
fun Tile(label: String, selected: Boolean, bg: Color, bmp: Bitmap?, onClick: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Box(
        Modifier.size(62.dp).clip(shape).background(bg)
            .then(if (selected) Modifier.border(2.dp, Color.White, shape) else Modifier)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (bmp != null) Image(bmp.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Text(label, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
fun MenuPanel(title: String, list: List<MItem>, grid: Boolean, onBack: () -> Unit, onOpen: (String) -> Unit, onSoon: () -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().height(54.dp).background(HeadBg), verticalAlignment = Alignment.CenterVertically) {
            Text("‹", Modifier.width(48.dp).clickable(onClick = onBack), color = Color.White, fontSize = 32.sp, textAlign = TextAlign.Center)
            Text(title, Modifier.weight(1f), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Spacer(Modifier.width(48.dp))
        }
        val rows = if (grid) list.chunked(2) else list.map { listOf(it) }
        rows.forEach { row ->
            Row(Modifier.fillMaxWidth()) {
                row.forEach { m ->
                    Row(
                        Modifier.weight(1f).height(58.dp).padding(horizontal = 4.dp)
                            .clickable { if (m.soon) onSoon() else if (m.sub != null) onOpen(m.sub) else m.act() },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            m.label, Modifier.weight(1f), color = if (m.soon) Color(0xFF777777) else Color.White,
                            fontSize = 20.sp, textAlign = TextAlign.Center
                        )
                        if (m.sub != null || m.soon) Text("›", color = Color.White, fontSize = 28.sp, modifier = Modifier.padding(end = 12.dp))
                    }
                }
                if (row.size == 1 && grid) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
fun LayerRow(l: Layer, dur: Float, t: Float, selected: Boolean, onClick: () -> Unit) {
    val d = maxOf(dur, 0.1f)
    Row(
        Modifier.fillMaxWidth().height(36.dp).clip(RoundedCornerShape(7.dp)).background(if (selected) Color(0xFF302D50) else SurfaceCard).clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(l.name, Modifier.width(80.dp).padding(start = 6.dp), fontSize = 11.sp, color = Color.White, maxLines = 1)
        Canvas(Modifier.weight(1f).fillMaxHeight()) {
            val w = size.width
            drawRect(GreenBar, Offset(w * l.inT / d, 4f), Size(w * (l.outT - l.inT) / d, size.height - 8f))
            l.allProps().flatMap { pr -> pr.keys.map { it.t } }.distinct().forEach { kt ->
                drawCircle(Color.White, 4f, Offset(w * kt / d, size.height / 2f))
            }
            drawLine(Color(0xFF00E040), Offset(w * t / d, 0f), Offset(w * t / d, size.height), 2f)
        }
    }
}

// ===================== الشاشة الرئيسية (Projects) =====================

@Composable
fun Home(onOpen: (String, Comp) -> Unit) {
    val ctx = LocalContext.current
    var items by remember { mutableStateOf(Store.list(ctx)) }
    var tab by remember { mutableStateOf(0) }
    var menuFor by remember { mutableStateOf("") }
    var about by remember { mutableStateOf(false) }
    val fmtDate = remember { SimpleDateFormat("M/d/yyyy H:mm", Locale.US) }

    fun create(u: Uri?) {
        val c = Comp()
        if (u != null) {
            try { ctx.contentResolver.takePersistableUriPermission(u, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) {}
            try { addVideoLayer(ctx, c, u) } catch (e: Exception) {}
        }
        val id = UUID.randomUUID().toString().replace("-", "").take(12)
        Store.save(ctx, id, c, false)
        onOpen(id, c)
    }
    val importVideo = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) create(u) }

    Column(Modifier.fillMaxSize().background(BgDark)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Motion Studio", Modifier.weight(1f), color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text("⚙", Modifier.clickable { about = true }.padding(8.dp), color = Color.White, fontSize = 26.sp)
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 40.dp, vertical = 22.dp), horizontalArrangement = Arrangement.spacedBy(70.dp)) {
            Box(
                Modifier.weight(1f).height(58.dp).clip(RoundedCornerShape(14.dp))
                    .background(Brush.verticalGradient(listOf(Color(0xFFFF8CFA), Color(0xFFF54FD0))))
                    .clickable { create(null) },
                contentAlignment = Alignment.Center
            ) { Text("+   New", color = Color.White, fontSize = 22.sp) }
            Box(
                Modifier.weight(1f).height(58.dp).clip(RoundedCornerShape(14.dp))
                    .background(Brush.verticalGradient(listOf(Color(0xFF8A8A8A), Color(0xFF4C4C4C))))
                    .clickable { importVideo.launch(arrayOf("video/*")) },
                contentAlignment = Alignment.Center
            ) { Text("⇩   Import", color = Color.White, fontSize = 22.sp) }
        }
        Row(Modifier.fillMaxWidth()) {
            listOf("Projects", "MINI Mode").forEachIndexed { i, s ->
                Column(Modifier.weight(1f).clickable { tab = i }, horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(s, color = if (tab == i) Color.White else Color(0xFF888888), fontSize = 22.sp, modifier = Modifier.padding(vertical = 12.dp))
                    Box(Modifier.fillMaxWidth().height(3.dp).background(if (tab == i) Color.White else Color.Transparent))
                }
            }
        }
        Row(Modifier.fillMaxWidth().height(46.dp).background(SurfaceRaised).padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("☰", color = Color.White, fontSize = 24.sp)
            Text("Time ↓", Modifier.weight(1f), color = Color.White, fontSize = 20.sp, textAlign = TextAlign.Center)
            Text("Manage", color = Color.White, fontSize = 20.sp)
        }
        if (tab == 1) {
            Text("MINI Mode — قريباً", Modifier.padding(24.dp), color = Color.Gray, fontSize = 18.sp)
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(items) { p ->
                    Row(
                        Modifier.fillMaxWidth().height(98.dp).padding(horizontal = 10.dp, vertical = 5.dp).clip(RoundedCornerShape(12.dp)).background(SurfaceCard)
                            .clickable { try { onOpen(p.id, Store.load(ctx, p.id)) } catch (e: Exception) {} },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.size(98.dp).background(Color.Black)) {
                            val th = p.thumb
                            if (th != null) Image(th.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                        }
                        Column(Modifier.weight(1f).padding(start = 12.dp)) {
                            Text(p.name, color = PinkText, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            Text(fmtDate.format(Date(p.modified)), color = Color.White, fontSize = 15.sp)
                            Text("%.1fM".format(p.size / 1_048_576f), color = Color.White, fontSize = 15.sp)
                        }
                        Box {
                            Text("⋮", Modifier.clickable { menuFor = p.id }.padding(18.dp), color = Color.White, fontSize = 24.sp)
                            DropdownMenu(expanded = menuFor == p.id, onDismissRequest = { menuFor = "" }) {
                                DropdownMenuItem(text = { Text("Delete") }, onClick = {
                                    Store.delete(ctx, p.id)
                                    items = Store.list(ctx)
                                    menuFor = ""
                                })
                            }
                        }
                    }
                }
            }
        }
    }
    if (about) {
        AlertDialog(
            onDismissRequest = { about = false },
            confirmButton = { TextButton(onClick = { about = false }) { Text("OK", color = Pink) } },
            title = { Text("Motion Studio") },
            text = { Text("محرر حركة بالطبقات ومفاتيح الحركة.\nالمشاريع تُحفظ تلقائياً.") }
        )
    }
}

// ===================== المحرر =====================

@Composable
fun Editor(id: String, comp: Comp, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val player = remember { ExoPlayer.Builder(ctx).build() }
    DisposableEffect(Unit) { onDispose { player.release() } }
    var t by remember { mutableStateOf(0f) }
    var playing by remember { mutableStateOf(false) }
    var selId by remember { mutableStateOf(-1) }
    var menu by remember { mutableStateOf<String?>(null) }
    var more by remember { mutableStateOf(false) }
    var tlOpen by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var exporting by remember { mutableStateOf(false) }
    var prog by remember { mutableStateOf(0f) }
    var dialog by remember { mutableStateOf("") }
    var nameEdit by remember { mutableStateOf("") }
    val undoS = remember { ArrayList<String>() }
    val redoS = remember { ArrayList<String>() }
    val sel = comp.layers.firstOrNull { it.id == selId }
    val videoUri = comp.layers.firstOrNull { it.kind == Kind.VIDEO }?.uri
    val d = maxOf(comp.dur, 0.1f)

    fun snap() {
        undoS.add(Store.compToJson(comp).toString())
        if (undoS.size > 40) undoS.removeAt(0)
        redoS.clear()
    }
    fun restore(js: String) {
        val cache = HashMap<Int, Bitmap>()
        comp.layers.forEach { l -> l.bmp?.let { cache[l.id] = it } }
        Store.applyJson(comp, JSONObject(js), cache, Store.dir(ctx))
    }
    fun undo() {
        if (undoS.isEmpty()) return
        redoS.add(Store.compToJson(comp).toString())
        restore(undoS.removeAt(undoS.size - 1))
    }
    fun redo() {
        if (redoS.isEmpty()) return
        undoS.add(Store.compToJson(comp).toString())
        restore(redoS.removeAt(redoS.size - 1))
    }
    fun seek(v: Float) {
        t = v.coerceIn(0f, d)
        playing = false
        if (videoUri != null) player.seekTo((t * 1000).toLong())
    }
    fun setP(p: Prop, v: Float) {
        if (p.keys.isNotEmpty()) p.setKey(t, v) else p.base = v
    }
    fun toggleAnim(vararg ps: Prop) {
        snap()
        val anim = ps.any { it.keys.isNotEmpty() }
        ps.forEach { p ->
            if (anim) { p.base = p.at(t); p.keys.clear() } else p.setKey(t, p.base)
        }
    }
    fun toggleEase(vararg ps: Prop) {
        val n = !ps.first().smooth
        ps.forEach { it.smooth = n }
        status = if (n) "Easing: Smooth" else "Easing: Linear"
    }
    fun addLayer(kind: Kind, bmp: Bitmap? = null) {
        snap()
        val l = Layer(comp.nextId++, kind)
        l.outT = comp.dur
        l.name = when (kind) {
            Kind.TEXT -> "Text"
            Kind.RECT -> "Rectangle"
            Kind.ELLIPSE -> "Ellipse"
            Kind.FILL -> "Fill"
            Kind.IMAGE -> "Image"
            Kind.VIDEO -> "Video"
        }
        if (kind == Kind.RECT || kind == Kind.ELLIPSE || kind == Kind.FILL) l.color = 0xFFFF5CC8.toInt()
        if (kind == Kind.ELLIPSE) { l.w = 300f; l.h = 300f }
        if (kind == Kind.TEXT) l.h = 120f
        l.bmp = bmp
        comp.layers.add(l)
        selId = l.id
        menu = null
    }
    fun setRatio(r: String) {
        if (videoUri != null) { status = "Ratio is set by the video"; return }
        snap()
        comp.ratio = r
        when (r) {
            "16:9" -> { comp.cw = 1280; comp.ch = 720 }
            "9:16" -> { comp.cw = 720; comp.ch = 1280 }
            "1:1" -> { comp.cw = 1024; comp.ch = 1024 }
            "4:3" -> { comp.cw = 1280; comp.ch = 960 }
            "21:9" -> { comp.cw = 1280; comp.ch = 544 }
        }
    }
    fun doExport() {
        if (exporting) return
        exporting = true
        prog = 0f
        status = "Exporting..."
        scope.launch {
            try {
                exportComp(ctx, comp) { prog = it }
                status = "Saved to Movies/MotionStudio ✓"
            } catch (e: Exception) {
                status = "Export failed: ${e.message}"
            }
            exporting = false
        }
    }
    fun closeEditor() {
        try { Store.save(ctx, id, comp, true) } catch (e: Exception) {}
        onClose()
    }

    val pickVideo = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            try {
                try { ctx.contentResolver.takePersistableUriPermission(u, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) {}
                snap()
                addVideoLayer(ctx, comp, u)
                selId = comp.layers[0].id
                menu = null
                seek(0f)
            } catch (e: Exception) {
                status = "Cannot open video: ${e.message}"
            }
        }
    }
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            try {
                val raw = ctx.contentResolver.openInputStream(u)!!.use { BitmapFactory.decodeStream(it) }
                val sc = minOf(1f, 1024f / maxOf(raw.width, raw.height))
                val b = if (sc < 1f) Bitmap.createScaledBitmap(raw, (raw.width * sc).toInt(), (raw.height * sc).toInt(), true) else raw
                addLayer(Kind.IMAGE, b)
            } catch (e: Exception) {
                status = "Cannot open image: ${e.message}"
            }
        }
    }

    LaunchedEffect(videoUri) {
        if (videoUri != null) {
            player.setMediaItem(MediaItem.fromUri(videoUri))
            player.prepare()
            player.playWhenReady = false
        } else {
            player.clearMediaItems()
        }
    }
    LaunchedEffect(Unit) {
        while (true) {
            delay(10_000)
            withContext(Dispatchers.IO) { try { Store.save(ctx, id, comp, false) } catch (e: Exception) {} }
        }
    }
    LaunchedEffect(playing, videoUri) {
        if (!playing) {
            player.pause()
            return@LaunchedEffect
        }
        if (videoUri != null) {
            player.seekTo((t * 1000).toLong())
            player.play()
            while (true) {
                withFrameNanos { }
                t = minOf(player.currentPosition / 1000f, comp.dur)
                if (t >= comp.dur - 0.03f || player.playbackState == Player.STATE_ENDED) {
                    playing = false
                    break
                }
            }
        } else {
            var last = withFrameNanos { it }
            while (true) {
                val now = withFrameNanos { it }
                t += (now - last) / 1e9f
                last = now
                if (t >= comp.dur) {
                    t = comp.dur
                    playing = false
                    break
                }
            }
        }
    }
    BackHandler {
        val m = menu
        if (m != null) {
            menu = if (m.contains('/')) m.substringBeforeLast('/') else null
        } else {
            closeEditor()
        }
    }

    fun menuItems(m: String): List<MItem> = when (m) {
        "layer" -> listOf(
            MItem("Media", "layer/media"), MItem("Group", soon = true),
            MItem("Text", act = { addLayer(Kind.TEXT) }), MItem("Text 3D", soon = true),
            MItem("Shape", "layer/shape"), MItem("Adjustment Layer", soon = true),
            MItem("Fill", "layer/fill"), MItem("3D", soon = true), MItem("Import", soon = true)
        )
        "layer/media" -> listOf(
            MItem("Video", act = { pickVideo.launch(arrayOf("video/*")) }),
            MItem("Image", act = { pickImage.launch(arrayOf("image/*")) }),
            MItem("Extract Audio From Video", soon = true), MItem("Load From File", soon = true)
        )
        "layer/shape" -> listOf(
            MItem("Rectangle", act = { addLayer(Kind.RECT) }), MItem("Ellipse", act = { addLayer(Kind.ELLIPSE) })
        )
        "layer/fill" -> listOf(MItem("Solid", act = { addLayer(Kind.FILL) }))
        "prop" -> listOf(
            MItem("Recently Used", soon = true), MItem("Effect", "prop/effect"),
            MItem("Asset Store", soon = true), MItem("Fill", "prop/fill"),
            MItem("Mask", soon = true), MItem("2D Animation", soon = true),
            MItem("CC", soon = true), MItem("AI", soon = true)
        )
        "prop/effect" -> listOf("brightness", "contrast", "saturation").map { ty ->
            MItem(ty.replaceFirstChar { it.uppercase() }, act = {
                val l = sel
                if (l != null) { snap(); l.effects.add(Fx(ty)) }
                menu = null
            })
        }
        "prop/fill" -> listOf(
            "White" to android.graphics.Color.WHITE, "Pink" to 0xFFFF5CC8.toInt(), "Red" to 0xFFEF4444.toInt(),
            "Green" to 0xFF22C55E.toInt(), "Blue" to 0xFF3B82F6.toInt(), "Yellow" to 0xFFFACC15.toInt()
        ).map { (n, c) ->
            MItem(n, act = {
                val l = sel
                if (l != null) { snap(); l.color = c }
                menu = null
            })
        }
        else -> emptyList()
    }
    fun menuTitle(m: String): String = when (m) {
        "layer" -> "New Layer"
        "layer/media" -> "New Layer > Media"
        "layer/shape" -> "New Layer > Shape"
        "layer/fill" -> "New Layer > Fill"
        "prop" -> "New Property"
        "prop/effect" -> "New Property > Effect"
        else -> "New Property > Fill"
    }

    Column(Modifier.fillMaxSize().background(Color.Black)) {
        // ---------- المعاينة ----------
        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth().background(Color(0xFF090C13)), contentAlignment = Alignment.Center) {
            val ar = comp.cw.toFloat() / comp.ch
            val availW = maxWidth - 28.dp
            val availH = maxHeight - 20.dp
            val w = minOf(availW, availH * ar)
            val h = w / ar
            Box(Modifier.size(w, h).background(Color(0xFF0A0A0A))) {
                if (videoUri != null) {
                    AndroidView(factory = { c -> SurfaceView(c).also { player.setVideoSurfaceView(it) } }, modifier = Modifier.fillMaxSize())
                }
                Canvas(
                    Modifier.fillMaxSize().pointerInput(selId) {
                        detectDragGestures(onDragStart = { snap() }) { change, drag ->
                            val l = comp.layers.firstOrNull { it.id == selId }
                            if (l != null && l.kind != Kind.VIDEO) {
                                change.consume()
                                setP(l.px, l.px.at(t) + drag.x / size.width)
                                setP(l.py, l.py.at(t) + drag.y / size.height)
                            }
                        }
                    }
                ) {
                    val sc = size.width / comp.cw
                    drawIntoCanvas { cv ->
                        val c = cv.nativeCanvas
                        c.save()
                        c.scale(sc, sc)
                        drawLayers(c, comp, t)
                        val s = sel
                        if (s != null && s.kind != Kind.VIDEO) drawSelection(c, comp, s, t)
                        c.restore()
                    }
                }
            }
            if (comp.layers.isEmpty()) {
                Text("Get Started ▶", Modifier.clickable { menu = "layer" }.padding(20.dp), color = Color(0xFF9A9A9A), fontSize = 22.sp)
            }
            if (status.isNotEmpty()) {
                Column(
                    Modifier.align(Alignment.BottomCenter).padding(8.dp)
                        .background(Color(0xCC000000), RoundedCornerShape(8.dp)).clickable { status = "" }.padding(10.dp)
                ) {
                    Text(status, color = Color.White, fontSize = 14.sp)
                    if (exporting) {
                        LinearProgressIndicator(progress = { prog.coerceIn(0f, 1f) }, color = Pink, trackColor = Color(0xFF402030))
                    }
                }
            }
        }
        // ---------- الشريط الوردي ----------
        Row(Modifier.fillMaxWidth().height(52.dp).background(SurfaceRaised).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("▦", Modifier.clickable { selId = -1; menu = null }.padding(horizontal = 10.dp), color = Color.White, fontSize = 26.sp)
            if (sel == null) {
                Text("v0.2 - ${comp.name}", Modifier.weight(1f).clickable { nameEdit = comp.name; dialog = "projname" }, color = Color.White, fontSize = 19.sp)
            } else {
                Text(if (sel.visible) "◉" else "○", Modifier.clickable { snap(); sel.visible = !sel.visible }.padding(horizontal = 10.dp), color = Color.White, fontSize = 26.sp)
                Text("◎", Modifier.clickable {
                    snap()
                    val nid = comp.nextId++
                    val o = Store.layerToJson(sel)
                    o.put("id", nid)
                    val cache = HashMap<Int, Bitmap>()
                    sel.bmp?.let { cache[nid] = it }
                    val nl = Store.layerFromJson(o, cache, Store.dir(ctx))
                    nl.name = sel.name + " 2"
                    comp.layers.add(nl)
                    selId = nid
                }.padding(horizontal = 10.dp), color = Color.White, fontSize = 26.sp)
                Text("☰", Modifier.clickable { dialog = "layermenu" }.padding(horizontal = 10.dp), color = Color.White, fontSize = 26.sp)
                Text("✎ ${sel.name}", Modifier.weight(1f).clickable { nameEdit = sel.name; dialog = "rename" }, color = Color.White, fontSize = 19.sp, maxLines = 1)
            }
            Text("↶", Modifier.clickable { undo() }.padding(horizontal = 10.dp), color = Color.White, fontSize = 28.sp)
            Text("↷", Modifier.clickable { redo() }.padding(horizontal = 10.dp), color = Color.White, fontSize = 28.sp)
        }
        // ---------- شريط الطبقات ----------
        Row(Modifier.fillMaxWidth().height(84.dp).background(Color.Black), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.width(48.dp).clickable { tlOpen = !tlOpen }, horizontalAlignment = Alignment.CenterHorizontally) {
                Text("☰", color = Color.White, fontSize = 24.sp)
                Text(if (tlOpen) "▴" else "▾", color = Color.White, fontSize = 22.sp)
            }
            Row(
                Modifier.horizontalScroll(rememberScrollState()).padding(end = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically
            ) {
                Tile("Root", selId == -1, Color(0xFF444444), null) { selId = -1; menu = null }
                comp.layers.forEach { l ->
                    val bg = when (l.kind) {
                        Kind.RECT, Kind.ELLIPSE, Kind.FILL -> Color(l.color)
                        Kind.VIDEO -> Color(0xFF2A2A2A)
                        else -> Color(0xFF444444)
                    }
                    Tile(if (l.kind == Kind.VIDEO) "▶" else l.name.take(7), selId == l.id, bg, l.bmp) { selId = l.id; menu = null }
                }
                Box(
                    Modifier.size(62.dp)
                        .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp, bottomEnd = 16.dp, bottomStart = 4.dp))
                        .background(Brush.linearGradient(listOf(Color(0xFF3DE7FF), Color(0xFF2B86F5))))
                        .clickable { menu = "layer" },
                    contentAlignment = Alignment.Center
                ) { Text("+", color = Color.White, fontSize = 36.sp) }
            }
        }
        // ---------- اللوحة ----------
        Box(Modifier.weight(1.15f).fillMaxWidth().background(RowBg).verticalScroll(rememberScrollState())) {
            val m = menu
            if (m != null) {
                MenuPanel(
                    menuTitle(m), menuItems(m), grid = m == "prop",
                    onBack = { menu = if (m.contains('/')) m.substringBeforeLast('/') else null },
                    onOpen = { menu = it }, onSoon = { status = "قريباً" }
                )
            } else if (sel == null) {
                Column(Modifier.fillMaxWidth()) {
                    PanelHeader("⚙", "Project Settings")
                    SettingRow("Ratio", comp.ratio) { dialog = "ratio" }
                    SettingRow("FPS", "%.1f".format(comp.fps.toFloat())) { dialog = "fps" }
                    SettingRow("Preview Resolution", "${comp.previewRes}%") { dialog = "res" }
                    SettingRow("Preview Render Mode", comp.renderMode) { dialog = "mode" }
                    Spacer(Modifier.height(8.dp))
                    PanelHeader("▣", "3D Settings", onRight = { status = "قريباً" })
                    Spacer(Modifier.height(12.dp))
                    Box(
                        Modifier.fillMaxWidth().height(50.dp).background(Color(0xFFF4F4F4)).clickable { doExport() },
                        contentAlignment = Alignment.Center
                    ) { Text("⇪   Export", color = Color.Black, fontSize = 22.sp) }
                }
            } else if (sel.kind == Kind.VIDEO) {
                Column(Modifier.fillMaxWidth()) {
                    PanelHeader("▶", "Video")
                    Text("تحريك الفيديو وتحويلاته قريباً. الفيديو يُستخدم كخلفية للطبقات.", Modifier.padding(16.dp), color = Color.White, fontSize = 16.sp)
                    Text("Delete layer", Modifier.fillMaxWidth().clickable { snap(); comp.layers.remove(sel); selId = -1 }.padding(16.dp), color = PinkText, fontSize = 18.sp)
                }
            } else {
                Column(Modifier.fillMaxWidth()) {
                    PanelHeader("✥", "Transform", "☰", onRight = { snap(); sel.px.base = 0.5f; sel.py.base = 0.5f; sel.sx.base = 1f; sel.sy.base = 1f; sel.rrev.base = 0f; sel.rdeg.base = 0f; sel.op.base = 1f })
                    TRow("Position", listOf(sel.px.at(t), sel.py.at(t)), listOf("%.2f", "%.2f"), listOf(0.002f, 0.002f),
                        sel.px.keys.isNotEmpty() || sel.py.keys.isNotEmpty(), null, { snap() },
                        { i, v -> setP(if (i == 0) sel.px else sel.py, v) }, { toggleAnim(sel.px, sel.py) }, { toggleEase(sel.px, sel.py) })
                    TRow("Scale", listOf(sel.sx.at(t), sel.sy.at(t)), listOf("%.2f", "%.2f"), listOf(0.005f, 0.005f),
                        sel.sx.keys.isNotEmpty() || sel.sy.keys.isNotEmpty(),
                        { Text("∞", Modifier.clickable { sel.linkScale = !sel.linkScale }.padding(6.dp), color = if (sel.linkScale) PinkText else Color.Gray, fontSize = 22.sp) },
                        { snap() },
                        { i, v -> if (sel.linkScale) { setP(sel.sx, v); setP(sel.sy, v) } else setP(if (i == 0) sel.sx else sel.sy, v) },
                        { toggleAnim(sel.sx, sel.sy) }, { toggleEase(sel.sx, sel.sy) })
                    TRow("Pivot", listOf(sel.pvx.at(t), sel.pvy.at(t)), listOf("%.2f", "%.2f"), listOf(0.002f, 0.002f),
                        sel.pvx.keys.isNotEmpty() || sel.pvy.keys.isNotEmpty(), null, { snap() },
                        { i, v -> setP(if (i == 0) sel.pvx else sel.pvy, v) }, { toggleAnim(sel.pvx, sel.pvy) }, { toggleEase(sel.pvx, sel.pvy) })
                    TRow("Rotation", listOf(sel.rrev.at(t), sel.rdeg.at(t)), listOf("%.0f", "%.0f"), listOf(0.05f, 0.5f),
                        sel.rrev.keys.isNotEmpty() || sel.rdeg.keys.isNotEmpty(),
                        { Text("x", color = Color.White, fontSize = 18.sp) }, { snap() },
                        { i, v -> setP(if (i == 0) sel.rrev else sel.rdeg, v) }, { toggleAnim(sel.rrev, sel.rdeg) }, { toggleEase(sel.rrev, sel.rdeg) })
                    TRow("Opacity", listOf(sel.op.at(t)), listOf("%.2f"), listOf(0.003f), sel.op.keys.isNotEmpty(), null, { snap() },
                        { _, v -> setP(sel.op, v.coerceIn(0f, 1f)) }, { toggleAnim(sel.op) }, { toggleEase(sel.op) })
                    sel.effects.toList().forEach { e ->
                        TRow(e.type.replaceFirstChar { it.uppercase() }, listOf(e.amount.at(t)), listOf("%.2f"), listOf(0.005f),
                            e.amount.keys.isNotEmpty(), null, { snap() }, { _, v -> setP(e.amount, v) },
                            { toggleAnim(e.amount) }, { toggleEase(e.amount) },
                            trailing = { Text("✕", Modifier.clickable { snap(); sel.effects.remove(e) }.padding(10.dp), color = Color.White, fontSize = 20.sp) })
                    }
                    Row(Modifier.fillMaxWidth().background(HeadBg).clickable { more = !more }.padding(vertical = 12.dp), horizontalArrangement = Arrangement.Center) {
                        Text(if (more) "▴  Less..." else "▾  More...", color = Color.White, fontSize = 20.sp)
                    }
                    if (more) {
                        SettingRow("Start", "%.2f".format(sel.inT)) { dialog = "start" }
                        SettingRow("End", "%.2f".format(sel.outT)) { dialog = "end" }
                        if (sel.kind == Kind.TEXT) {
                            SettingRow("Text", sel.text) { nameEdit = sel.text; dialog = "text" }
                            SettingRow("Font Size", "%.0f".format(sel.h)) { dialog = "fsize" }
                        }
                        if (sel.kind == Kind.RECT || sel.kind == Kind.ELLIPSE) {
                            SettingRow("Width", "%.0f".format(sel.w)) { dialog = "w" }
                            SettingRow("Height", "%.0f".format(sel.h)) { dialog = "h" }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Box(Modifier.fillMaxWidth().height(50.dp).background(Color(0xFFF4F4F4)).clickable { menu = "prop" }, contentAlignment = Alignment.Center) {
                        Text("+", color = Color.Black, fontSize = 32.sp)
                    }
                }
            }
        }
        // ---------- الخط الزمني ----------
        if (tlOpen) {
            Column(Modifier.fillMaxWidth().heightIn(max = 130.dp).verticalScroll(rememberScrollState()).background(SurfaceCard)) {
                comp.layers.reversed().forEach { l -> LayerRow(l, comp.dur, t, l.id == selId) { selId = l.id } }
            }
        }
        Canvas(
            Modifier.fillMaxWidth().height(78.dp)
                .pointerInput(d) { detectTapGestures { o -> seek(o.x / size.width * d) } }
                .pointerInput(d) { detectDragGestures { ch, _ -> seek(ch.position.x / size.width * d) } }
        ) {
            val w = size.width
            val h = size.height
            drawRect(Color(0xFF6E6E6E), Offset(0f, 0f), Size(w, h))
            if (sel != null) drawRect(GreenBar, Offset(w * sel.inT / d, 0f), Size(w * (sel.outT - sel.inT) / d, h))
            for (i in 0..10) {
                val x = w * i / 10f
                drawLine(Color.White, Offset(x, h - (if (i % 5 == 0) 22f else 12f)), Offset(x, h), 3f)
            }
            sel?.let { s ->
                s.allProps().flatMap { pr -> pr.keys.map { it.t } }.distinct().forEach { kt ->
                    drawCircle(Color.White, 7f, Offset(w * kt / d, h * 0.55f))
                }
            }
            comp.markers.forEach { mk -> drawRect(Color(0xFFFFD60A), Offset(w * mk / d - 3f, 0f), Size(6f, h * 0.35f)) }
            drawIntoCanvas { cv ->
                val p = Paint(Paint.ANTI_ALIAS_FLAG)
                p.color = android.graphics.Color.WHITE
                p.textSize = 32f
                cv.nativeCanvas.drawText(tc(0f, comp.fps), 6f, 36f, p)
                p.textAlign = Paint.Align.CENTER
                cv.nativeCanvas.drawText(tc(d / 2f, comp.fps), w / 2f, 36f, p)
                p.textAlign = Paint.Align.RIGHT
                cv.nativeCanvas.drawText(tc(d, comp.fps), w - 6f, 36f, p)
            }
            val x = w * t / d
            drawLine(Color(0xFF00E040), Offset(x, 0f), Offset(x, h), 5f)
            drawRect(Color(0xFF00E040), Offset(x - 7f, 0f), Size(14f, 14f))
        }
        // ---------- الشريط السفلي ----------
        Row(Modifier.fillMaxWidth().height(62.dp).background(Color.Black), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceEvenly) {
            Text("⌂", Modifier.clickable { closeEditor() }.padding(8.dp), color = Color.White, fontSize = 30.sp)
            Text("⇪", Modifier.clickable { doExport() }.padding(8.dp), color = Color.White, fontSize = 30.sp)
            Box(Modifier.clickable {
                val ks = (sel?.allProps() ?: emptyList()).flatMap { p -> p.keys.map { it.t } }.filter { it < t - 0.05f }
                seek(ks.maxOrNull() ?: 0f)
            }.padding(10.dp)) { TIcon("prev") }
            Box(Modifier.clickable {
                if (t >= comp.dur - 0.05f) t = 0f
                playing = !playing
            }.padding(10.dp)) { TIcon(if (playing) "pause" else "play") }
            Box(Modifier.clickable {
                val ks = (sel?.allProps() ?: emptyList()).flatMap { p -> p.keys.map { it.t } }.filter { it > t + 0.05f }
                seek(ks.minOrNull() ?: d)
            }.padding(10.dp)) { TIcon("next") }
            Text("☆", Modifier.clickable {
                val i = comp.markers.indexOfFirst { kotlin.math.abs(it - t) < 0.1f }
                if (i >= 0) comp.markers.removeAt(i) else comp.markers.add(t)
            }.padding(8.dp), color = Color.White, fontSize = 30.sp)
            Box(
                Modifier.size(30.dp).border(2.dp, Color.White, CircleShape).clickable { dialog = "help" },
                contentAlignment = Alignment.Center
            ) { Text("?", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        }
    }

    // ---------- الحوارات ----------
    val choiceOpts: List<String> = when (dialog) {
        "ratio" -> listOf("16:9", "9:16", "1:1", "4:3", "21:9")
        "fps" -> listOf("24", "25", "30", "50", "60")
        "res" -> listOf("25", "50", "75", "100")
        "mode" -> listOf("Current Layer", "All Layers")
        else -> emptyList()
    }
    if (choiceOpts.isNotEmpty()) {
        AlertDialog(
            onDismissRequest = { dialog = "" },
            confirmButton = {},
            text = {
                Column {
                    choiceOpts.forEach { o ->
                        Text(o, Modifier.fillMaxWidth().clickable {
                            when (dialog) {
                                "ratio" -> setRatio(o)
                                "fps" -> comp.fps = o.toInt()
                                "res" -> comp.previewRes = o.toInt()
                                "mode" -> comp.renderMode = o
                            }
                            dialog = ""
                        }.padding(14.dp), fontSize = 20.sp)
                    }
                }
            }
        )
    }
    if (dialog == "rename" || dialog == "projname" || dialog == "text") {
        AlertDialog(
            onDismissRequest = { dialog = "" },
            confirmButton = {
                TextButton(onClick = {
                    snap()
                    when (dialog) {
                        "rename" -> sel?.name = nameEdit
                        "projname" -> comp.name = nameEdit
                        "text" -> sel?.text = nameEdit
                    }
                    dialog = ""
                }) { Text("OK", color = Pink) }
            },
            text = { OutlinedTextField(value = nameEdit, onValueChange = { nameEdit = it }, singleLine = true) }
        )
    }
    if (dialog == "start" || dialog == "end" || dialog == "fsize" || dialog == "w" || dialog == "h") {
        var v by remember(dialog) {
            mutableStateOf(
                when (dialog) {
                    "start" -> (sel?.inT ?: 0f).toString()
                    "end" -> (sel?.outT ?: 0f).toString()
                    "fsize" -> (sel?.h ?: 0f).toString()
                    "w" -> (sel?.w ?: 0f).toString()
                    else -> (sel?.h ?: 0f).toString()
                }
            )
        }
        AlertDialog(
            onDismissRequest = { dialog = "" },
            confirmButton = {
                TextButton(onClick = {
                    val n = v.toFloatOrNull()
                    if (n != null && sel != null) {
                        snap()
                        when (dialog) {
                            "start" -> sel.inT = n.coerceIn(0f, sel.outT)
                            "end" -> sel.outT = n.coerceIn(sel.inT, comp.dur)
                            "fsize", "h" -> sel.h = n.coerceAtLeast(1f)
                            "w" -> sel.w = n.coerceAtLeast(1f)
                        }
                    }
                    dialog = ""
                }) { Text("OK", color = Pink) }
            },
            text = {
                OutlinedTextField(
                    value = v, onValueChange = { v = it }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
            }
        )
    }
    if (dialog == "layermenu" && sel != null) {
        AlertDialog(
            onDismissRequest = { dialog = "" },
            confirmButton = {},
            text = {
                Column {
                    listOf("Delete", "Move Up", "Move Down").forEach { a ->
                        Text(a, Modifier.fillMaxWidth().clickable {
                            snap()
                            val i = comp.layers.indexOf(sel)
                            when (a) {
                                "Delete" -> { comp.layers.remove(sel); selId = -1 }
                                "Move Up" -> if (i < comp.layers.size - 1) { comp.layers.removeAt(i); comp.layers.add(i + 1, sel) }
                                "Move Down" -> if (i > 0) { comp.layers.removeAt(i); comp.layers.add(i - 1, sel) }
                            }
                            dialog = ""
                        }.padding(14.dp), fontSize = 20.sp)
                    }
                }
            }
        )
    }
    if (dialog == "help") {
        AlertDialog(
            onDismissRequest = { dialog = "" },
            confirmButton = { TextButton(onClick = { dialog = "" }) { Text("OK", color = Pink) } },
            title = { Text("Help") },
            text = {
                Text(
                    "• اضغط + لإضافة طبقة (فيديو، صورة، نص، شكل).\n" +
                        "• ◷ بجانب أي خاصية = تفعيل الحركة (Keyframes). غيّر القيمة عند أي زمن لتسجيل مفتاح.\n" +
                        "• اسحب الرقم الوردي يميناً/يساراً لتغييره، أو اضغطه لكتابة قيمة.\n" +
                        "• اسحب على المعاينة لتحريك الطبقة.\n" +
                        "• ⇪ للتصدير إلى Movies/MotionStudio."
                )
            }
        )
    }
}
