package com.motion.studio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Pink, onPrimary = Color.White, background = Color.Black, onBackground = Color.White,
                    surface = Color(0xFF1E1E1E), onSurface = Color.White, surfaceVariant = Color(0xFF2A2A2A), outline = Pink
                )
            ) {
                Surface(Modifier.fillMaxSize(), color = Color.Black) { App() }
            }
        }
    }
}

@Composable
fun App() {
    var open by remember { mutableStateOf<Pair<String, Comp>?>(null) }
    val o = open
    if (o == null) Home { id, c -> open = id to c }
    else Editor(o.first, o.second) { open = null }
}
