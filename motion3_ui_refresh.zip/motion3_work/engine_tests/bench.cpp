#include "engine.h"
#include <chrono>
#include <cstdio>
using namespace mo;
static Effect fx(int type, std::vector<float> v) { Effect e; e.type = type; for (float f : v) { Prop p; p.base = f; e.p.push_back(p); } return e; }
static double bench(int nfx, int type, std::vector<float> params, int W, int H) {
    Scene s; s.cw = 1280; s.ch = 720; static std::vector<uint8_t> t(1024 * 1024 * 4, 200);
    for (int i = 0; i < 4; ++i) { Layer L; L.kind = 1; L.bw = 600; L.bh = 600; L.px.base = .3f + .1f * i; L.py.base = .5f; L.sx.base = L.sy.base = 1; L.pvx.base = L.pvy.base = .5f; L.op.base = 1; L.rdeg.base = 10.f * i;
        if (i < nfx) L.fx.push_back(fx(type, params)); s.layers.push_back(L); }
    std::vector<Tex> tex(4); for (auto& x : tex) { x.px = t.data(); x.w = 1024; x.h = 1024; x.stride = 4096; }
    std::vector<uint8_t> out((size_t)W * H * 4);
    auto a = std::chrono::steady_clock::now(); for (int i = 0; i < 5; ++i) render(s, 0.f, W, H, out.data(), W * 4, tex, -1);
    return std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - a).count() / 5;
}
int main() {
    for (int res = 0; res < 2; ++res) { int W = res ? 1280 : 640, H = res ? 720 : 360; printf("== %dx%d\n", W, H);
      printf("no fx          %.1f ms\n", bench(0, 0, {}, W, H));
      printf("gauss x1       %.1f ms\n", bench(1, FX_GAUSS, {20}, W, H));
      printf("glow x1        %.1f ms\n", bench(1, FX_GLOW, {1, 30, .5f}, W, H));
      printf("brightness x4  %.1f ms\n", bench(4, FX_BRIGHTNESS, {.1f}, W, H));
      printf("dirblur x1     %.1f ms\n", bench(1, FX_DIRBLUR, {40, 0}, W, H)); }
}
