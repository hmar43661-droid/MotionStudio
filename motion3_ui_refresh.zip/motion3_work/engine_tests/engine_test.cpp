#include "engine.h"
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <vector>
using namespace mo;

static int fails = 0, checks = 0;
#define CHECK(cond, msg) do { checks++; if (!(cond)) { fails++; printf("FAIL: %s (%s:%d)\n", msg, __FILE__, __LINE__); } } while (0)
static bool near_(int a, int b, int tol) { return std::abs(a - b) <= tol; }

struct Img { int w, h; std::vector<uint8_t> d; Img(int w_, int h_) : w(w_), h(h_), d((size_t)w_ * h_ * 4, 0) {} 
  const uint8_t* at(int x, int y) const { return &d[((size_t)y * w + x) * 4]; } };

static Layer fill(float bw, float bh, float r, float g, float b, float a = 1.f) {
    Layer L; L.kind = 2; L.bw = bw; L.bh = bh; L.color[0] = r; L.color[1] = g; L.color[2] = b; L.color[3] = a;
    L.px.base = .5f; L.py.base = .5f; L.sx.base = 1; L.sy.base = 1; L.pvx.base = .5f; L.pvy.base = .5f; L.op.base = 1;
    return L;
}
static Img run(Scene& s, float t, int w, int h, int only = -1, const std::vector<Tex>& tex = {}) {
    Img im(w, h); render(s, t, w, h, im.d.data(), w * 4, tex, only); return im;
}
static Effect fx(int type, std::vector<float> v) { Effect e; e.type = type; for (float f : v) { Prop p; p.base = f; e.p.push_back(p); } return e; }

int main() {
    // 1 keyframes
    { Prop p; p.keys = {{0, 0}, {1, 10}}; p.smooth = false;
      CHECK(std::fabs(p.at(0.5f) - 5.f) < 1e-4, "linear key");
      p.smooth = true; CHECK(std::fabs(p.at(0.25f) - 1.5625f) < 1e-3, "smooth key");
      CHECK(p.at(-1) == 0 && p.at(2) == 10, "key clamp"); }
    // 2 fill + preview scale
    { Scene s; s.cw = 100; s.ch = 100; s.layers.push_back(fill(40, 40, 1, 0, 0));
      Img a = run(s, 0, 100, 100);
      CHECK(near_(a.at(50, 50)[0], 255, 1) && a.at(50, 50)[3] == 255, "fill center red");
      CHECK(a.at(10, 10)[3] == 0, "fill outside transparent");
      Img b = run(s, 0, 50, 50);
      CHECK(near_(b.at(25, 25)[0], 255, 1) && b.at(5, 5)[3] == 0, "preview resolution 50%"); }
    // 3 rotation 90 deg
    { Scene s; s.cw = 100; s.ch = 100; Layer L = fill(60, 20, 0, 1, 0); L.rdeg.base = 90; s.layers.push_back(L);
      Img a = run(s, 0, 100, 100);
      CHECK(a.at(50, 75)[3] == 255 && a.at(75, 50)[3] == 0, "rotation 90 swaps extent"); }
    // 4 opacity over white
    { Scene s; s.cw = 20; s.ch = 20; s.layers.push_back(fill(20, 20, 1, 1, 1)); Layer r = fill(20, 20, 1, 0, 0); r.op.base = 0.5f; s.layers.push_back(r);
      Img a = run(s, 0, 20, 20);
      CHECK(near_(a.at(10, 10)[0], 255, 1) && near_(a.at(10, 10)[1], 128, 2) && near_(a.at(10, 10)[2], 128, 2), "opacity blend"); }
    // 5 keyframed position (linear)
    { Scene s; s.cw = 100; s.ch = 100; Layer L = fill(20, 20, 1, 0, 0); L.px.keys = {{0, 0.25f}, {1, 0.75f}}; L.px.smooth = false; s.layers.push_back(L);
      Img a = run(s, 0, 100, 100), b = run(s, 1, 100, 100), c = run(s, 0.5f, 100, 100);
      CHECK(a.at(25, 50)[3] == 255 && a.at(75, 50)[3] == 0, "pos key t=0");
      CHECK(b.at(75, 50)[3] == 255 && b.at(25, 50)[3] == 0, "pos key t=1");
      CHECK(c.at(50, 50)[3] == 255, "pos key mid"); }
    // 6 texture bilinear + in/out time
    { std::vector<uint8_t> t = {255, 0, 0, 255, 0, 255, 0, 255, 0, 0, 255, 255, 255, 255, 255, 255};
      Scene s; s.cw = 40; s.ch = 40; Layer L; L.kind = 1; L.bw = 40; L.bh = 40; L.px.base = .5f; L.py.base = .5f; L.sx.base = L.sy.base = 1; L.pvx.base = L.pvy.base = .5f; L.op.base = 1; L.inT = 0; L.outT = 1;
      s.layers.push_back(L); Tex tx; tx.px = t.data(); tx.w = 2; tx.h = 2; tx.stride = 8;
      Img a = run(s, 0, 40, 40, -1, {tx});
      CHECK(near_(a.at(1, 1)[0], 255, 6) && near_(a.at(38, 1)[1], 255, 6) && near_(a.at(1, 38)[2], 255, 6), "texture corners");
      Img b = run(s, 2, 40, 40, -1, {tx}); CHECK(b.at(20, 20)[3] == 0, "layer out time hidden"); }
    // 7 brightness / invert / color chain
    { Scene s; s.cw = 20; s.ch = 20; Layer L = fill(20, 20, 0.5f, 0.5f, 0.5f); L.fx.push_back(fx(FX_BRIGHTNESS, {0.2f})); s.layers.push_back(L);
      Img a = run(s, 0, 20, 20); CHECK(near_(a.at(10, 10)[0], 179, 3), "brightness +0.2");
      Scene s2; s2.cw = 20; s2.ch = 20; Layer R = fill(20, 20, 1, 0, 0); R.fx.push_back(fx(FX_INVERT, {1})); s2.layers.push_back(R);
      Img b = run(s2, 0, 20, 20); CHECK(b.at(10, 10)[0] < 3 && near_(b.at(10, 10)[1], 255, 2) && near_(b.at(10, 10)[2], 255, 2), "invert");
      Scene s3; s3.cw = 20; s3.ch = 20; Layer G = fill(20, 20, 1, 0, 0); G.fx.push_back(fx(FX_SATURATION, {0})); s3.layers.push_back(G);
      Img c = run(s3, 0, 20, 20); CHECK(near_(c.at(10, 10)[0], c.at(10, 10)[1], 2) && near_(c.at(10, 10)[1], c.at(10, 10)[2], 2), "desaturate -> gray"); }
    // 8 gaussian blur conserves energy and spreads
    { Scene s; s.cw = 100; s.ch = 100; Layer L = fill(10, 10, 1, 1, 1); L.fx.push_back(fx(FX_GAUSS, {12})); s.layers.push_back(L);
      Img a = run(s, 0, 100, 100); double sum = 0; int mx = 0; for (int y = 0; y < 100; ++y) for (int x = 0; x < 100; ++x) { int v = a.at(x, y)[3]; sum += v; if (v > mx) mx = v; }
      double expect = 10.0 * 10.0 * 255.0; CHECK(std::fabs(sum - expect) / expect < 0.06, "blur energy conserved");
      CHECK(mx < 200 && a.at(50 + 9, 50)[3] > 5, "blur spreads");
      printf("   blur: peak=%d energy=%.1f%%\n", mx, 100 * sum / expect); }
    // 9 directional blur spreads along angle only
    { Scene s; s.cw = 100; s.ch = 100; Layer L = fill(10, 10, 1, 1, 1); L.fx.push_back(fx(FX_DIRBLUR, {30, 0})); s.layers.push_back(L);
      Img a = run(s, 0, 100, 100); CHECK(a.at(50 + 12, 50)[3] > 20 && a.at(50, 50 + 12)[3] == 0, "motion blur horizontal"); }
    { Scene s; s.cw = 100; s.ch = 100; Layer L = fill(10, 10, 1, 1, 1); L.fx.push_back(fx(FX_DIRBLUR, {30, 90})); s.layers.push_back(L);
      Img a = run(s, 0, 100, 100); CHECK(a.at(50, 50 + 12)[3] > 20 && a.at(50 + 12, 50)[3] == 0, "motion blur vertical (fast path)");
      Scene s2; s2.cw = 100; s2.ch = 100; Layer M = fill(10, 10, 1, 1, 1); M.fx.push_back(fx(FX_DIRBLUR, {30, 45})); s2.layers.push_back(M);
      Img b = run(s2, 0, 100, 100); CHECK(b.at(50 + 8, 50 + 8)[3] > 20 && b.at(50 + 14, 50 - 14)[3] == 0, "motion blur 45deg"); }
    // 10 chroma key
    { Scene s; s.cw = 20; s.ch = 20; Layer G = fill(20, 20, 0, 1, 0); G.fx.push_back(fx(FX_CHROMAKEY, {120, 30, 15, 0.5f})); s.layers.push_back(G);
      Img a = run(s, 0, 20, 20); CHECK(a.at(10, 10)[3] < 5, "chroma key removes green");
      Scene s2; s2.cw = 20; s2.ch = 20; Layer R = fill(20, 20, 1, 0, 0); R.fx.push_back(fx(FX_CHROMAKEY, {120, 30, 15, 0.5f})); s2.layers.push_back(R);
      Img b = run(s2, 0, 20, 20); CHECK(b.at(10, 10)[3] == 255, "chroma key keeps red"); }
    // 11 mask ellipse
    { Scene s; s.cw = 100; s.ch = 100; Layer L = fill(100, 100, 1, 1, 1); L.fx.push_back(fx(FX_MASK, {1, .5f, .5f, .5f, .5f, 0.05f, 0})); s.layers.push_back(L);
      Img a = run(s, 0, 100, 100); CHECK(a.at(50, 50)[3] == 255 && a.at(3, 3)[3] == 0 && a.at(50, 3)[3] == 0, "ellipse mask");
      Scene s2 = s; s2.layers[0].fx[0].p[6].base = 1; Img b = run(s2, 0, 100, 100); CHECK(b.at(50, 50)[3] == 0 && b.at(3, 3)[3] == 255, "mask invert"); }
    // 12 glow spreads brightness
    { Scene s; s.cw = 100; s.ch = 100; Layer L = fill(10, 10, 1, 1, 1); L.fx.push_back(fx(FX_GLOW, {1.f, 20, 0.5f})); s.layers.push_back(L);
      Img a = run(s, 0, 100, 100); CHECK(a.at(50 + 9, 50)[3] > 10 && a.at(50, 50)[3] == 255, "glow halo"); }
    // 13 rgb split
    { Scene s; s.cw = 100; s.ch = 100; Layer L = fill(10, 10, 1, 1, 1); L.fx.push_back(fx(FX_RGBSPLIT, {6, 0})); s.layers.push_back(L);
      Img a = run(s, 0, 100, 100); const uint8_t* right = a.at(50 + 5 + 3, 50); const uint8_t* left = a.at(50 - 5 - 4, 50);
      CHECK(right[0] > 200 && right[2] < 10, "rgb split right red-only"); CHECK(left[2] > 200 && left[0] < 10, "rgb split left blue-only"); }
    // 14 blend modes
    { Scene s; s.cw = 20; s.ch = 20; s.layers.push_back(fill(20, 20, 0, 1, 0)); Layer r = fill(20, 20, 1, 0, 0); r.blend = BL_MULTIPLY; s.layers.push_back(r);
      Img a = run(s, 0, 20, 20); CHECK(a.at(10, 10)[0] < 3 && a.at(10, 10)[1] < 3, "multiply red*green=black");
      Scene s2; s2.cw = 20; s2.ch = 20; s2.layers.push_back(fill(20, 20, 0.5f, 0.5f, 0.5f)); Layer w = fill(20, 20, 0.5f, 0.5f, 0.5f); w.blend = BL_ADD; s2.layers.push_back(w);
      Img b = run(s2, 0, 20, 20); CHECK(near_(b.at(10, 10)[0], 255, 2), "add"); }
    // 15 mosaic + mirror
    { std::vector<uint8_t> t(40 * 40 * 4); for (int y = 0; y < 40; ++y) for (int x = 0; x < 40; ++x) { uint8_t* p = &t[(y * 40 + x) * 4]; p[0] = x * 6; p[1] = 0; p[2] = 0; p[3] = 255; }
      Scene s; s.cw = 40; s.ch = 40; Layer L; L.kind = 1; L.bw = 40; L.bh = 40; L.px.base = .5f; L.py.base = .5f; L.sx.base = L.sy.base = 1; L.pvx.base = L.pvy.base = .5f; L.op.base = 1; L.fx.push_back(fx(FX_MOSAIC, {10})); s.layers.push_back(L);
      Tex tx; tx.px = t.data(); tx.w = 40; tx.h = 40; tx.stride = 160; Img a = run(s, 0, 40, 40, -1, {tx});
      CHECK(a.at(1, 5)[0] == a.at(8, 5)[0] && a.at(1, 5)[0] != a.at(12, 5)[0], "mosaic blocks");
      s.layers[0].fx.clear(); s.layers[0].fx.push_back(fx(FX_MIRROR, {1})); Img b = run(s, 0, 40, 40, -1, {tx});
      CHECK(near_(b.at(38, 20)[0], b.at(1, 20)[0], 8), "mirror left->right"); }
    // 16 curves / tone / color correct / hsl / vignette
    { Scene s; s.cw = 20; s.ch = 20; Layer L = fill(20, 20, 0.25f, 0.25f, 0.25f); L.fx.push_back(fx(FX_TONE, {1.f, 0, 0, 0, 0, 0, 0})); s.layers.push_back(L);
      Img a = run(s, 0, 20, 20); CHECK(near_(a.at(10, 10)[0], 128, 4), "tone exposure +1 doubles");
      Scene s2; s2.cw = 20; s2.ch = 20; Layer C = fill(20, 20, 0.2f, 0.2f, 0.2f); C.fx.push_back(fx(FX_CURVES, {1.f, 0, 0, 0})); s2.layers.push_back(C);
      Img b = run(s2, 0, 20, 20); CHECK(b.at(10, 10)[0] > 51 + 8, "curves shadows lift");
      Scene s3; s3.cw = 20; s3.ch = 20; Layer H = fill(20, 20, 1, 0, 0); H.fx.push_back(fx(FX_HSL, {120, 1, 0})); s3.layers.push_back(H);
      Img c = run(s3, 0, 20, 20); CHECK(c.at(10, 10)[1] > c.at(10, 10)[0], "hsl hue +120 red->green-ish");
      Scene s4; s4.cw = 20; s4.ch = 20; Layer V = fill(20, 20, 0.5f, 0.5f, 0.5f); V.fx.push_back(fx(FX_COLORCORRECT, {1.f, 1, 0, 0})); s4.layers.push_back(V);
      Img d = run(s4, 0, 20, 20); CHECK(d.at(10, 10)[0] > 200, "color correct exposure");
      Scene s5; s5.cw = 100; s5.ch = 100; Layer W = fill(100, 100, 1, 1, 1); W.fx.push_back(fx(FX_VIGNETTE, {1.f, 0.6f, 0.4f})); s5.layers.push_back(W);
      Img e = run(s5, 0, 100, 100); CHECK(e.at(50, 50)[0] > e.at(2, 2)[0] + 100, "vignette darkens corners"); }
    // 17 shake moves the layer
    { Scene s; s.cw = 100; s.ch = 100; Layer L = fill(10, 10, 1, 0, 0); L.fx.push_back(fx(FX_SHAKE, {0.3f, 1.f})); s.layers.push_back(L);
      Img a = run(s, 0.37f, 100, 100); double cxs = 0, cys = 0, n = 0;
      for (int y = 0; y < 100; ++y) for (int x = 0; x < 100; ++x) if (a.at(x, y)[3] > 128) { cxs += x; cys += y; n++; }
      CHECK(n > 50, "shake renders layer"); if (n > 0) { cxs /= n; cys /= n; CHECK(std::fabs(cxs - 50) + std::fabs(cys - 50) > 2.0, "shake displaces layer"); }
      Scene s0 = s; s0.layers[0].fx.clear(); Img b = run(s0, 0.37f, 100, 100); CHECK(b.at(50, 50)[3] == 255, "no shake stays centered"); }
    // 18 edges / emboss / grain / chromaab / lens run without crashing & modify
    { std::vector<uint8_t> t(40 * 40 * 4); for (int y = 0; y < 40; ++y) for (int x = 0; x < 40; ++x) { uint8_t* p = &t[(y * 40 + x) * 4]; uint8_t v = x < 20 ? 0 : 255; p[0] = p[1] = p[2] = v; p[3] = 255; }
      int types[] = {FX_FINDEDGES, FX_EMBOSS, FX_GRAIN, FX_CHROMAAB, FX_LENSDIST, FX_RADIALBLUR, FX_CROSSBLUR, FX_HUE, FX_SEPIA, FX_CONTRAST};
      for (int ty : types) { Scene s; s.cw = 40; s.ch = 40; Layer L; L.kind = 1; L.bw = 40; L.bh = 40; L.px.base = .5f; L.py.base = .5f; L.sx.base = L.sy.base = 1; L.pvx.base = L.pvy.base = .5f; L.op.base = 1;
        L.fx.push_back(fx(ty, {0.5f, 0.5f, 0.5f})); s.layers.push_back(L); Tex tx; tx.px = t.data(); tx.w = 40; tx.h = 40; tx.stride = 160; Img a = run(s, 0.1f, 40, 40, -1, {tx}); CHECK(a.d.size() == 40 * 40 * 4, "effect runs"); }
      Scene s; s.cw = 40; s.ch = 40; Layer L; L.kind = 1; L.bw = 40; L.bh = 40; L.px.base = .5f; L.py.base = .5f; L.sx.base = L.sy.base = 1; L.pvx.base = L.pvy.base = .5f; L.op.base = 1; L.fx.push_back(fx(FX_FINDEDGES, {1, 0})); s.layers.push_back(L);
      Tex tx; tx.px = t.data(); tx.w = 40; tx.h = 40; tx.stride = 160; Img a = run(s, 0, 40, 40, -1, {tx}); CHECK(a.at(20, 20)[0] > 200 && a.at(5, 20)[0] < 10, "find edges detects vertical edge"); }
    // 19 performance (1280x720, 4 layers, gauss + glow)
    { Scene s; s.cw = 1280; s.ch = 720; std::vector<uint8_t> t(1024 * 1024 * 4, 200);
      for (int i = 0; i < 4; ++i) { Layer L; L.kind = 1; L.bw = 600; L.bh = 600; L.px.base = .3f + .1f * i; L.py.base = .5f; L.sx.base = L.sy.base = 1; L.pvx.base = L.pvy.base = .5f; L.op.base = 1; L.rdeg.base = 10.f * i; if (i == 1) L.fx.push_back(fx(FX_GAUSS, {20})); if (i == 2) L.fx.push_back(fx(FX_GLOW, {1, 30, 0.5f})); s.layers.push_back(L); }
      std::vector<Tex> tex(4); for (auto& x : tex) { x.px = t.data(); x.w = 1024; x.h = 1024; x.stride = 4096; }
      for (int pass = 0; pass < 2; ++pass) { int W = pass ? 1280 : 640, H = pass ? 720 : 360; Img im(W, H);
        auto a = std::chrono::steady_clock::now(); for (int i = 0; i < 5; ++i) render(s, 0.f, W, H, im.d.data(), W * 4, tex, -1);
        double ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - a).count() / 5; printf("   perf %dx%d (4 layers, blur+glow): %.1f ms/frame\n", W, H, ms); } }
    printf("%d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
