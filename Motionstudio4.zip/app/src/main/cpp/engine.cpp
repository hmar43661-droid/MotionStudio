#include "engine.h"

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstring>

namespace mo {

float Prop::at(float t) const {
    if (keys.empty()) return base;
    if (t <= keys.front().t) return keys.front().v;
    if (t >= keys.back().t) return keys.back().v;
    size_t lo = 0, hi = keys.size() - 1;
    while (hi - lo > 1) {
        size_t mid = (lo + hi) / 2;
        if (keys[mid].t <= t) lo = mid; else hi = mid;
    }
    const Key& a = keys[lo];
    const Key& b = keys[hi];
    float d = b.t - a.t;
    if (d <= 1e-6f) return b.v;
    float f = (t - a.t) / d;
    if (smooth) f = f * f * (3.f - 2.f * f);
    return a.v + (b.v - a.v) * f;
}

namespace {

const float kPi = 3.14159265358979f;

inline float clampf(float v, float a, float b) { return v < a ? a : (v > b ? b : v); }
inline uint8_t u8(float v) { v = v < 0.f ? 0.f : (v > 255.f ? 255.f : v); return (uint8_t)(v + 0.5f); }
inline float smoothstep(float a, float b, float x) {
    float t = clampf((x - a) / (b - a), 0.f, 1.f);
    return t * t * (3.f - 2.f * t);
}

struct Buf {
    int w = 0, h = 0;
    std::vector<uint8_t> d;  // premultiplied RGBA
    Buf() {}
    Buf(int w_, int h_) : w(w_), h(h_), d((size_t)w_ * (size_t)h_ * 4, 0) {}
    uint8_t* px(int x, int y) { return &d[((size_t)y * w + x) * 4]; }
    const uint8_t* px(int x, int y) const { return &d[((size_t)y * w + x) * 4]; }
};

struct FxCtx {
    float osx, osy;     // composition -> output pixel scale
    int x0, y0;         // buffer origin in output space
    float t;
    float inv[6];       // output px (x,y) -> layer coords (u,v)
    float fw[6];        // layer coords (u,v) -> output px (x,y)
    float bw, bh;
};

float P(const Effect& e, size_t i, float def, float t) { return i < e.p.size() ? e.p[i].at(t) : def; }

// ---------------- color matrix ----------------
struct CM { float m[20]; };

CM cmId() {
    CM c;
    memset(c.m, 0, sizeof c.m);
    c.m[0] = c.m[6] = c.m[12] = c.m[18] = 1.f;
    return c;
}
// result = B applied after A
CM cmCompose(const CM& A, const CM& B) {
    CM C;
    for (int r = 0; r < 4; ++r) {
        for (int c = 0; c < 4; ++c) {
            float s = 0.f;
            for (int k = 0; k < 4; ++k) s += B.m[r * 5 + k] * A.m[k * 5 + c];
            C.m[r * 5 + c] = s;
        }
        float o = B.m[r * 5 + 4];
        for (int k = 0; k < 4; ++k) o += B.m[r * 5 + k] * A.m[k * 5 + 4];
        C.m[r * 5 + 4] = o;
    }
    return C;
}
CM cmBrightness(float v) { CM c = cmId(); c.m[4] = c.m[9] = c.m[14] = v; return c; }
CM cmContrast(float k) { CM c = cmId(); c.m[0] = c.m[6] = c.m[12] = k; c.m[4] = c.m[9] = c.m[14] = 0.5f * (1.f - k); return c; }
CM cmSaturation(float s) {
    const float lr = 0.2126f, lg = 0.7152f, lb = 0.0722f;
    CM c = cmId();
    float rows[3][3] = {{lr * (1 - s) + s, lg * (1 - s), lb * (1 - s)},
                        {lr * (1 - s), lg * (1 - s) + s, lb * (1 - s)},
                        {lr * (1 - s), lg * (1 - s), lb * (1 - s) + s}};
    for (int r = 0; r < 3; ++r) for (int k = 0; k < 3; ++k) c.m[r * 5 + k] = rows[r][k];
    return c;
}
CM cmHue(float deg) {
    float r = deg * kPi / 180.f, cs = std::cos(r), sn = std::sin(r);
    CM c = cmId();
    float v[9] = {0.213f + cs * 0.787f - sn * 0.213f, 0.715f - cs * 0.715f - sn * 0.715f, 0.072f - cs * 0.072f + sn * 0.928f,
                  0.213f - cs * 0.213f + sn * 0.143f, 0.715f + cs * 0.285f + sn * 0.140f, 0.072f - cs * 0.072f - sn * 0.283f,
                  0.213f - cs * 0.213f - sn * 0.787f, 0.715f - cs * 0.715f + sn * 0.715f, 0.072f + cs * 0.928f + sn * 0.072f};
    for (int r2 = 0; r2 < 3; ++r2) for (int k = 0; k < 3; ++k) c.m[r2 * 5 + k] = v[r2 * 3 + k];
    return c;
}
CM cmInvert(float a) { CM c = cmId(); float k = 1.f - 2.f * a; c.m[0] = c.m[6] = c.m[12] = k; c.m[4] = c.m[9] = c.m[14] = a; return c; }
CM cmSepia(float a) {
    CM c = cmId();
    float v[9] = {(1 - a) + a * 0.393f, a * 0.769f, a * 0.189f,
                  a * 0.349f, (1 - a) + a * 0.686f, a * 0.168f,
                  a * 0.272f, a * 0.534f, (1 - a) + a * 0.131f};
    for (int r = 0; r < 3; ++r) for (int k = 0; k < 3; ++k) c.m[r * 5 + k] = v[r * 3 + k];
    return c;
}

void applyCM(Buf& b, const CM& c) {
    const float* m = c.m;
    uint8_t* d = b.d.data();
    size_t n = (size_t)b.w * b.h;
    for (size_t i = 0; i < n; ++i, d += 4) {
        int a = d[3];
        if (a == 0) continue;
        float ia = 1.f / (float)a, af = a / 255.f;
        float r = d[0] * ia, g = d[1] * ia, bl = d[2] * ia;
        float nr = clampf(m[0] * r + m[1] * g + m[2] * bl + m[3] * af + m[4], 0.f, 1.f);
        float ng = clampf(m[5] * r + m[6] * g + m[7] * bl + m[8] * af + m[9], 0.f, 1.f);
        float nb = clampf(m[10] * r + m[11] * g + m[12] * bl + m[13] * af + m[14], 0.f, 1.f);
        float na = clampf(m[15] * r + m[16] * g + m[17] * bl + m[18] * af + m[19], 0.f, 1.f);
        d[0] = u8(nr * na * 255.f);
        d[1] = u8(ng * na * 255.f);
        d[2] = u8(nb * na * 255.f);
        d[3] = u8(na * 255.f);
    }
}

void applyLUT(Buf& b, const uint8_t* lr, const uint8_t* lg, const uint8_t* lb) {
    uint8_t* d = b.d.data();
    size_t n = (size_t)b.w * b.h;
    for (size_t i = 0; i < n; ++i, d += 4) {
        int a = d[3];
        if (a == 0) continue;
        float ia = 255.f / (float)a;
        int r = (int)clampf(d[0] * ia + 0.5f, 0.f, 255.f);
        int g = (int)clampf(d[1] * ia + 0.5f, 0.f, 255.f);
        int bl = (int)clampf(d[2] * ia + 0.5f, 0.f, 255.f);
        float af = a / 255.f;
        d[0] = u8(lr[r] * af);
        d[1] = u8(lg[g] * af);
        d[2] = u8(lb[bl] * af);
    }
}

void buildCurve(uint8_t lut[256], float sh, float mid, float hi, float con) {
    float xs[5] = {0.f, 0.25f, 0.5f, 0.75f, 1.f};
    float ys[5] = {0.f, clampf(0.25f + 0.2f * sh, 0.f, 1.f), clampf(0.5f + 0.2f * mid, 0.f, 1.f),
                   clampf(0.75f + 0.2f * hi, 0.f, 1.f), 1.f};
    float m[5];
    for (int i = 0; i < 5; ++i) {
        if (i == 0) m[i] = (ys[1] - ys[0]) / (xs[1] - xs[0]);
        else if (i == 4) m[i] = (ys[4] - ys[3]) / (xs[4] - xs[3]);
        else m[i] = (ys[i + 1] - ys[i - 1]) / (xs[i + 1] - xs[i - 1]);
    }
    for (int i = 0; i < 256; ++i) {
        float x = i / 255.f;
        int s = 0;
        while (s < 3 && x > xs[s + 1]) ++s;
        float h = xs[s + 1] - xs[s], tt = (x - xs[s]) / h;
        float t2 = tt * tt, t3 = t2 * tt;
        float y = (2 * t3 - 3 * t2 + 1) * ys[s] + (t3 - 2 * t2 + tt) * h * m[s] + (-2 * t3 + 3 * t2) * ys[s + 1] + (t3 - t2) * h * m[s + 1];
        y = clampf(y, 0.f, 1.f);
        float sm = y * y * (3.f - 2.f * y);
        y = clampf(y + con * (sm - y), 0.f, 1.f);
        lut[i] = u8(y * 255.f);
    }
}

// ---------------- blur ----------------
void box1D(const uint8_t* src, uint8_t* dst, int len, int lines, ptrdiff_t stepAlong, ptrdiff_t stepLine, int r) {
    // horizontal pass: stepAlong == 4
    if (r <= 0) { memcpy(dst, src, (size_t)len * lines * 4); return; }
    float inv = 1.f / (float)(2 * r + 1);
    for (int l = 0; l < lines; ++l) {
        const uint8_t* s = src + l * stepLine;
        uint8_t* d = dst + l * stepLine;
        int acc[4] = {0, 0, 0, 0};
        for (int i = 0; i <= r && i < len; ++i)
            for (int c = 0; c < 4; ++c) acc[c] += s[i * stepAlong + c];
        for (int i = 0; i < len; ++i) {
            for (int c = 0; c < 4; ++c) d[i * stepAlong + c] = (uint8_t)(acc[c] * inv + 0.5f);
            int add = i + r + 1, sub = i - r;
            if (add < len) for (int c = 0; c < 4; ++c) acc[c] += s[add * stepAlong + c];
            if (sub >= 0) for (int c = 0; c < 4; ++c) acc[c] -= s[sub * stepAlong + c];
        }
    }
}

// vertical pass: sweeps row by row (cache friendly)
void boxV(const uint8_t* src, uint8_t* dst, int w, int h, int r) {
    if (r <= 0) { memcpy(dst, src, (size_t)w * h * 4); return; }
    const size_t rowB = (size_t)w * 4;
    float inv = 1.f / (float)(2 * r + 1);
    std::vector<int> acc(rowB, 0);
    for (int y = 0; y <= r && y < h; ++y)
        for (size_t i = 0; i < rowB; ++i) acc[i] += src[(size_t)y * rowB + i];
    for (int y = 0; y < h; ++y) {
        uint8_t* d = dst + (size_t)y * rowB;
        for (size_t i = 0; i < rowB; ++i) d[i] = (uint8_t)(acc[i] * inv + 0.5f);
        int add = y + r + 1, sub = y - r;
        if (add < h) { const uint8_t* a = src + (size_t)add * rowB; for (size_t i = 0; i < rowB; ++i) acc[i] += a[i]; }
        if (sub >= 0) { const uint8_t* a = src + (size_t)sub * rowB; for (size_t i = 0; i < rowB; ++i) acc[i] -= a[i]; }
    }
}

void boxesForGauss(float sigma, int n, int* sizes) {
    float wIdeal = std::sqrt(12.f * sigma * sigma / n + 1.f);
    int wl = (int)std::floor(wIdeal);
    if (wl % 2 == 0) --wl;
    if (wl < 1) wl = 1;
    int wu = wl + 2;
    float mIdeal = (12.f * sigma * sigma - n * wl * wl - 4.f * n * wl - 3.f * n) / (-4.f * wl - 4.f);
    int m = (int)std::lround(mIdeal);
    for (int i = 0; i < n; ++i) sizes[i] = i < m ? wl : wu;
}

void gaussAxis(Buf& b, float sigma, bool horizontal) {
    if (sigma < 0.3f || b.w == 0 || b.h == 0) return;
    int sizes[3];
    boxesForGauss(sigma, 3, sizes);
    std::vector<uint8_t> tmp(b.d.size());
    for (int p = 0; p < 3; ++p) {
        int r = (sizes[p] - 1) / 2;
        if (horizontal) box1D(b.d.data(), tmp.data(), b.w, b.h, 4, (ptrdiff_t)b.w * 4, r);
        else boxV(b.d.data(), tmp.data(), b.w, b.h, r);
        b.d.swap(tmp);
    }
}

void gauss(Buf& b, float sigma) {
    gaussAxis(b, sigma, true);
    gaussAxis(b, sigma, false);
}

void bilinear(const Buf& b, float x, float y, float out[4]) {
    // x,y in pixel coordinates where pixel centers are at +0.5
    float fx = x - 0.5f, fy = y - 0.5f;
    int x0 = (int)std::floor(fx), y0 = (int)std::floor(fy);
    float ax = fx - x0, ay = fy - y0;
    out[0] = out[1] = out[2] = out[3] = 0.f;
    for (int j = 0; j < 2; ++j)
        for (int i = 0; i < 2; ++i) {
            int xx = x0 + i, yy = y0 + j;
            if (xx < 0 || yy < 0 || xx >= b.w || yy >= b.h) continue;
            float w = (i ? ax : 1.f - ax) * (j ? ay : 1.f - ay);
            const uint8_t* p = b.px(xx, yy);
            for (int c = 0; c < 4; ++c) out[c] += w * p[c];
        }
}

void dirBlur(Buf& b, float lenPx, float angleDeg) {
    if (lenPx < 0.75f) return;
    float a = angleDeg * kPi / 180.f;
    float ca = std::cos(a), sa = std::sin(a);
    if (std::fabs(sa) < 1e-3f) {            // horizontal: single box pass
        int r = std::max(1, (int)std::lround(lenPx * 0.5f));
        std::vector<uint8_t> tmp(b.d.size());
        box1D(b.d.data(), tmp.data(), b.w, b.h, 4, (ptrdiff_t)b.w * 4, r);
        b.d.swap(tmp);
        return;
    }
    if (std::fabs(ca) < 1e-3f) {            // vertical
        int r = std::max(1, (int)std::lround(lenPx * 0.5f));
        std::vector<uint8_t> tmp(b.d.size());
        boxV(b.d.data(), tmp.data(), b.w, b.h, r);
        b.d.swap(tmp);
        return;
    }
    int n = (int)clampf(std::ceil(lenPx), 2.f, 64.f);
    std::vector<int> ox(n), oy(n);
    for (int i = 0; i < n; ++i) {
        float f = (float)i / (float)(n - 1) - 0.5f;
        ox[i] = (int)std::lround(ca * lenPx * f);
        oy[i] = (int)std::lround(sa * lenPx * f);
    }
    Buf src = b;
    for (int y = 0; y < b.h; ++y)
        for (int x = 0; x < b.w; ++x) {
            int acc[4] = {0, 0, 0, 0};
            for (int i = 0; i < n; ++i) {
                int sx = x + ox[i], sy = y + oy[i];
                if (sx < 0 || sy < 0 || sx >= b.w || sy >= b.h) continue;
                const uint8_t* p = src.px(sx, sy);
                acc[0] += p[0]; acc[1] += p[1]; acc[2] += p[2]; acc[3] += p[3];
            }
            uint8_t* o = b.px(x, y);
            for (int c = 0; c < 4; ++c) o[c] = (uint8_t)(acc[c] / n);
        }
}

void radialBlur(Buf& b, float amount, float cx, float cy) {
    if (amount < 0.002f) return;
    const int n = 16;
    Buf src = b;
    for (int y = 0; y < b.h; ++y)
        for (int x = 0; x < b.w; ++x) {
            float acc[4] = {0, 0, 0, 0};
            for (int i = 0; i < n; ++i) {
                float f = 1.f - amount * 0.5f * ((float)i / (n - 1));
                int sx = (int)std::lround(cx + (x - cx) * f), sy = (int)std::lround(cy + (y - cy) * f);
                if (sx < 0 || sy < 0 || sx >= b.w || sy >= b.h) continue;
                const uint8_t* p = src.px(sx, sy);
                for (int c = 0; c < 4; ++c) acc[c] += p[c];
            }
            uint8_t* o = b.px(x, y);
            for (int c = 0; c < 4; ++c) o[c] = u8(acc[c] / n);
        }
}

void glow(Buf& b, float intensity, float radiusPx, float thr) {
    if (intensity <= 0.f || radiusPx < 0.3f) return;
    Buf g = b;
    uint8_t* d = g.d.data();
    size_t n = (size_t)g.w * g.h;
    for (size_t i = 0; i < n; ++i, d += 4) {
        int a = d[3];
        if (a == 0) continue;
        float ia = 1.f / a;
        float l = 0.2126f * d[0] * ia + 0.7152f * d[1] * ia + 0.0722f * d[2] * ia;
        float f = clampf((l - thr) / (1.f - thr + 1e-3f), 0.f, 1.f);
        for (int c = 0; c < 4; ++c) d[c] = u8(d[c] * f);
    }
    gauss(g, radiusPx * 0.5f);
    uint8_t* o = b.d.data();
    const uint8_t* s = g.d.data();
    for (size_t i = 0; i < n * 4; ++i) o[i] = u8(o[i] + s[i] * intensity);
}

void rgbSplit(Buf& b, float amtPx, float angleDeg) {
    if (amtPx < 0.3f) return;
    float a = angleDeg * kPi / 180.f;
    int ox = (int)std::lround(std::cos(a) * amtPx), oy = (int)std::lround(std::sin(a) * amtPx);
    Buf src = b;
    for (int y = 0; y < b.h; ++y)
        for (int x = 0; x < b.w; ++x) {
            const uint8_t* c = src.px(x, y);
            int rx = x - ox, ry = y - oy, bx = x + ox, by = y + oy;
            uint8_t r = 0, bl = 0, ar = 0, ab = 0;
            if (rx >= 0 && ry >= 0 && rx < b.w && ry < b.h) { const uint8_t* p = src.px(rx, ry); r = p[0]; ar = p[3]; }
            if (bx >= 0 && by >= 0 && bx < b.w && by < b.h) { const uint8_t* p = src.px(bx, by); bl = p[2]; ab = p[3]; }
            uint8_t* o = b.px(x, y);
            o[0] = r; o[1] = c[1]; o[2] = bl;
            o[3] = std::max(std::max(ar, ab), c[3]);
        }
}

void chromaAb(Buf& b, float strength) {
    if (strength < 0.01f) return;
    float k = strength * 0.03f;
    float cx = b.w * 0.5f, cy = b.h * 0.5f;
    Buf src = b;
    for (int y = 0; y < b.h; ++y)
        for (int x = 0; x < b.w; ++x) {
            const uint8_t* c = src.px(x, y);
            int rx = (int)std::lround(cx + (x - cx) * (1.f + k)), ry = (int)std::lround(cy + (y - cy) * (1.f + k));
            int bx = (int)std::lround(cx + (x - cx) * (1.f - k)), by = (int)std::lround(cy + (y - cy) * (1.f - k));
            uint8_t r = 0, bl = 0, ar = 0, ab = 0;
            if (rx >= 0 && ry >= 0 && rx < b.w && ry < b.h) { const uint8_t* p = src.px(rx, ry); r = p[0]; ar = p[3]; }
            if (bx >= 0 && by >= 0 && bx < b.w && by < b.h) { const uint8_t* p = src.px(bx, by); bl = p[2]; ab = p[3]; }
            uint8_t* o = b.px(x, y);
            o[0] = r; o[1] = c[1]; o[2] = bl;
            o[3] = std::max(std::max(ar, ab), c[3]);
        }
}

void mosaic(Buf& b, int cell, int absX0, int absY0) {
    if (cell < 2) return;
    Buf src = b;
    // grid aligned to absolute output coordinates so it is stable while editing
    int offX = ((absX0 % cell) + cell) % cell, offY = ((absY0 % cell) + cell) % cell;
    for (int by = -offY; by < b.h; by += cell)
        for (int bx = -offX; bx < b.w; bx += cell) {
            int xs = std::max(bx, 0), ys = std::max(by, 0), xe = std::min(bx + cell, b.w), ye = std::min(by + cell, b.h);
            int cnt = (xe - xs) * (ye - ys);
            if (cnt <= 0) continue;
            int acc[4] = {0, 0, 0, 0};
            for (int y = ys; y < ye; ++y)
                for (int x = xs; x < xe; ++x) {
                    const uint8_t* p = src.px(x, y);
                    for (int c = 0; c < 4; ++c) acc[c] += p[c];
                }
            uint8_t v[4];
            for (int c = 0; c < 4; ++c) v[c] = (uint8_t)(acc[c] / cnt);
            for (int y = ys; y < ye; ++y)
                for (int x = xs; x < xe; ++x) memcpy(b.px(x, y), v, 4);
        }
}

void findEdges(Buf& b, float strength, bool invert) {
    Buf src = b;
    auto L = [&](int x, int y) {
        x = std::max(0, std::min(b.w - 1, x));
        y = std::max(0, std::min(b.h - 1, y));
        const uint8_t* p = src.px(x, y);
        return (0.2126f * p[0] + 0.7152f * p[1] + 0.0722f * p[2]) / 255.f;
    };
    for (int y = 0; y < b.h; ++y)
        for (int x = 0; x < b.w; ++x) {
            float gx = -L(x - 1, y - 1) - 2 * L(x - 1, y) - L(x - 1, y + 1) + L(x + 1, y - 1) + 2 * L(x + 1, y) + L(x + 1, y + 1);
            float gy = -L(x - 1, y - 1) - 2 * L(x, y - 1) - L(x + 1, y - 1) + L(x - 1, y + 1) + 2 * L(x, y + 1) + L(x + 1, y + 1);
            float m = clampf(std::sqrt(gx * gx + gy * gy) * strength, 0.f, 1.f);
            if (invert) m = 1.f - m;
            uint8_t* o = b.px(x, y);
            float a = src.px(x, y)[3] / 255.f;
            o[0] = o[1] = o[2] = u8(m * a * 255.f);
            o[3] = src.px(x, y)[3];
        }
}

void emboss(Buf& b, float strength, float angleDeg) {
    Buf src = b;
    float a = angleDeg * kPi / 180.f;
    int dx = (int)std::lround(std::cos(a)), dy = (int)std::lround(std::sin(a));
    if (dx == 0 && dy == 0) dx = 1;
    auto L = [&](int x, int y) {
        x = std::max(0, std::min(b.w - 1, x));
        y = std::max(0, std::min(b.h - 1, y));
        const uint8_t* p = src.px(x, y);
        return (0.2126f * p[0] + 0.7152f * p[1] + 0.0722f * p[2]) / 255.f;
    };
    for (int y = 0; y < b.h; ++y)
        for (int x = 0; x < b.w; ++x) {
            float v = clampf(0.5f + strength * (L(x + dx, y + dy) - L(x - dx, y - dy)), 0.f, 1.f);
            uint8_t* o = b.px(x, y);
            float al = src.px(x, y)[3] / 255.f;
            o[0] = o[1] = o[2] = u8(v * al * 255.f);
            o[3] = src.px(x, y)[3];
        }
}

void chromaKey(Buf& b, float keyHue, float tol, float soft, float spill) {
    soft = std::max(soft, 0.5f);
    uint8_t* d = b.d.data();
    size_t n = (size_t)b.w * b.h;
    for (size_t i = 0; i < n; ++i, d += 4) {
        int a = d[3];
        if (a == 0) continue;
        float r = d[0] / (float)a, g = d[1] / (float)a, bl = d[2] / (float)a;
        float mx = std::max(r, std::max(g, bl)), mn = std::min(r, std::min(g, bl)), dl = mx - mn;
        float sat = mx > 0.f ? dl / mx : 0.f;
        float keep = 1.f;
        if (sat > 0.2f && mx > 0.1f && dl > 1e-4f) {
            float h;
            if (mx == r) h = 60.f * std::fmod((g - bl) / dl + 6.f, 6.f);
            else if (mx == g) h = 60.f * ((bl - r) / dl + 2.f);
            else h = 60.f * ((r - g) / dl + 4.f);
            float dh = std::fabs(h - keyHue);
            if (dh > 180.f) dh = 360.f - dh;
            keep = clampf((dh - tol) / soft, 0.f, 1.f);
        }
        if (keep < 1.f && spill > 0.f) {
            float lumv = 0.2126f * r + 0.7152f * g + 0.0722f * bl;
            float k = spill * (1.f - keep);
            r += (lumv - r) * k; g += (lumv - g) * k; bl += (lumv - bl) * k;
        }
        float na = (a / 255.f) * keep;
        d[0] = u8(r * na * 255.f);
        d[1] = u8(g * na * 255.f);
        d[2] = u8(bl * na * 255.f);
        d[3] = u8(na * 255.f);
    }
}

// ---------------- effect chain ----------------
void applyEffects(Buf& b, const Layer& L, const FxCtx& cx) {
    CM pending = cmId();
    bool hasPending = false;
    auto flush = [&]() {
        if (hasPending) { applyCM(b, pending); pending = cmId(); hasPending = false; }
    };
    auto add = [&](const CM& m) { pending = cmCompose(pending, m); hasPending = true; };
    const float t = cx.t;
    const float sc = 0.5f * (cx.osx + cx.osy);
    for (const Effect& e : L.fx) {
        switch (e.type) {
            case FX_BRIGHTNESS: add(cmBrightness(P(e, 0, 0.f, t))); break;
            case FX_CONTRAST: add(cmContrast(P(e, 0, 1.f, t))); break;
            case FX_SATURATION: add(cmSaturation(P(e, 0, 1.f, t))); break;
            case FX_HUE: add(cmHue(P(e, 0, 0.f, t))); break;
            case FX_INVERT: add(cmInvert(clampf(P(e, 0, 0.f, t), 0.f, 1.f))); break;
            case FX_SEPIA: add(cmSepia(clampf(P(e, 0, 0.f, t), 0.f, 1.f))); break;
            case FX_HSL: {
                add(cmHue(P(e, 0, 0.f, t)));
                add(cmSaturation(P(e, 1, 1.f, t)));
                add(cmBrightness(P(e, 2, 0.f, t)));
                break;
            }
            case FX_COLORCORRECT: {
                flush();
                float ex = std::pow(2.f, P(e, 0, 0.f, t)), gm = std::max(0.05f, P(e, 1, 1.f, t));
                float tp = P(e, 2, 0.f, t), tn = P(e, 3, 0.f, t);
                float gain[3] = {ex * (1.f + 0.25f * tp), ex * (1.f - 0.15f * tn), ex * (1.f - 0.25f * tp)};
                uint8_t lut[3][256];
                for (int c = 0; c < 3; ++c)
                    for (int i = 0; i < 256; ++i) lut[c][i] = u8(std::pow(clampf(i / 255.f * gain[c], 0.f, 1.f), 1.f / gm) * 255.f);
                applyLUT(b, lut[0], lut[1], lut[2]);
                break;
            }
            case FX_CURVES: {
                flush();
                uint8_t lut[256];
                buildCurve(lut, P(e, 0, 0.f, t), P(e, 1, 0.f, t), P(e, 2, 0.f, t), P(e, 3, 0.f, t));
                applyLUT(b, lut, lut, lut);
                break;
            }
            case FX_TONE: {
                flush();
                float ex = std::pow(2.f, P(e, 0, 0.f, t)), gam = std::pow(2.f, -P(e, 1, 0.f, t)), con = P(e, 2, 0.f, t);
                float hi = P(e, 3, 0.f, t), sh = P(e, 4, 0.f, t), wh = P(e, 5, 0.f, t), bk = P(e, 6, 0.f, t);
                uint8_t lut[256];
                for (int i = 0; i < 256; ++i) {
                    float y = clampf(i / 255.f * ex, 0.f, 1.f);
                    y = std::pow(y, gam);
                    float sm = y * y * (3.f - 2.f * y);
                    y = y + con * (sm - y);
                    y += hi * 0.25f * 4.f * y * y * (1.f - y);
                    y += sh * 0.25f * 4.f * (1.f - y) * (1.f - y) * y;
                    y = y / (1.f - 0.3f * wh);
                    y += bk * 0.15f * std::pow(1.f - y, 4.f);
                    lut[i] = u8(clampf(y, 0.f, 1.f) * 255.f);
                }
                applyLUT(b, lut, lut, lut);
                break;
            }
            case FX_GAUSS: flush(); gauss(b, P(e, 0, 0.f, t) * sc * 0.5f); break;
            case FX_CROSSBLUR:
                flush();
                gaussAxis(b, P(e, 0, 0.f, t) * sc * 0.5f, true);
                gaussAxis(b, P(e, 1, 0.f, t) * sc * 0.5f, false);
                break;
            case FX_DIRBLUR: flush(); dirBlur(b, P(e, 0, 0.f, t) * sc, P(e, 1, 0.f, t)); break;
            case FX_RADIALBLUR: {
                flush();
                float ux = (P(e, 1, 0.5f, t)) * L.bw, uy = (P(e, 2, 0.5f, t)) * L.bh;
                float ox = cx.fw[0] * ux + cx.fw[1] * uy + cx.fw[2] - cx.x0;
                float oy = cx.fw[3] * ux + cx.fw[4] * uy + cx.fw[5] - cx.y0;
                radialBlur(b, P(e, 0, 0.f, t), ox, oy);
                break;
            }
            case FX_GLOW: flush(); glow(b, P(e, 0, 1.f, t), P(e, 1, 20.f, t) * sc, P(e, 2, 0.5f, t)); break;
            case FX_VIGNETTE: {
                flush();
                float amt = clampf(P(e, 0, 0.5f, t), 0.f, 1.f), size = P(e, 1, 0.8f, t), soft = std::max(0.05f, P(e, 2, 0.5f, t));
                for (int y = 0; y < b.h; ++y)
                    for (int x = 0; x < b.w; ++x) {
                        float ax = (float)(x + cx.x0), ay = (float)(y + cx.y0);
                        float u = cx.inv[0] * ax + cx.inv[1] * ay + cx.inv[2], v = cx.inv[3] * ax + cx.inv[4] * ay + cx.inv[5];
                        float dx = (u / cx.bw - 0.5f) * 2.f, dy = (v / cx.bh - 0.5f) * 2.f;
                        float dist = std::sqrt(dx * dx + dy * dy) * 0.7071f;
                        float vg = smoothstep(size - soft, size + soft * 0.5f, dist * 1.4f);
                        float f = 1.f - amt * vg;
                        uint8_t* p = b.px(x, y);
                        p[0] = u8(p[0] * f); p[1] = u8(p[1] * f); p[2] = u8(p[2] * f);
                    }
                break;
            }
            case FX_GRAIN: {
                flush();
                float amt = clampf(P(e, 0, 0.3f, t), 0.f, 1.f), speed = P(e, 1, 1.f, t);
                uint32_t seed = (uint32_t)(int)(t * 24.f * speed) * 2654435761u;
                for (int y = 0; y < b.h; ++y)
                    for (int x = 0; x < b.w; ++x) {
                        uint32_t h = (uint32_t)(x + cx.x0) * 374761393u + (uint32_t)(y + cx.y0) * 668265263u + seed;
                        h = (h ^ (h >> 13)) * 1274126177u;
                        h ^= h >> 16;
                        float nz = ((h & 0xFFFF) / 65535.f - 0.5f) * 2.f * amt * 0.35f * 255.f;
                        uint8_t* p = b.px(x, y);
                        float al = p[3] / 255.f;
                        for (int c = 0; c < 3; ++c) p[c] = u8(std::min((float)p[3], std::max(0.f, p[c] + nz * al)));
                    }
                break;
            }
            case FX_RGBSPLIT: flush(); rgbSplit(b, P(e, 0, 0.f, t) * sc, P(e, 1, 0.f, t)); break;
            case FX_CHROMAAB: flush(); chromaAb(b, P(e, 0, 0.f, t)); break;
            case FX_MOSAIC: flush(); mosaic(b, (int)std::lround(P(e, 0, 1.f, t) * sc), cx.x0, cx.y0); break;
            case FX_MIRROR: {
                flush();
                int mode = (int)std::lround(P(e, 0, 0.f, t));
                if (mode <= 0) break;
                Buf src = b;
                for (int y = 0; y < b.h; ++y)
                    for (int x = 0; x < b.w; ++x) {
                        float ax = (float)(x + cx.x0), ay = (float)(y + cx.y0);
                        float u = cx.inv[0] * ax + cx.inv[1] * ay + cx.inv[2], v = cx.inv[3] * ax + cx.inv[4] * ay + cx.inv[5];
                        float nu = u, nv = v;
                        if (mode == 1 && u > cx.bw * 0.5f) nu = cx.bw - u;
                        else if (mode == 2 && u < cx.bw * 0.5f) nu = cx.bw - u;
                        else if (mode == 3 && v > cx.bh * 0.5f) nv = cx.bh - v;
                        else if (mode == 4 && v < cx.bh * 0.5f) nv = cx.bh - v;
                        if (nu == u && nv == v) continue;
                        float sx = cx.fw[0] * nu + cx.fw[1] * nv + cx.fw[2] - cx.x0;
                        float sy = cx.fw[3] * nu + cx.fw[4] * nv + cx.fw[5] - cx.y0;
                        float o[4];
                        bilinear(src, sx, sy, o);
                        uint8_t* p = b.px(x, y);
                        for (int c = 0; c < 4; ++c) p[c] = u8(o[c]);
                    }
                break;
            }
            case FX_LENSDIST: {
                flush();
                float k = P(e, 0, 0.f, t);
                if (std::fabs(k) < 1e-3f) break;
                Buf src = b;
                for (int y = 0; y < b.h; ++y)
                    for (int x = 0; x < b.w; ++x) {
                        float ax = (float)(x + cx.x0), ay = (float)(y + cx.y0);
                        float u = cx.inv[0] * ax + cx.inv[1] * ay + cx.inv[2], v = cx.inv[3] * ax + cx.inv[4] * ay + cx.inv[5];
                        float dx = u / cx.bw - 0.5f, dy = v / cx.bh - 0.5f;
                        float r2 = dx * dx + dy * dy, f = 1.f + k * r2 * 4.f;
                        float nu = (0.5f + dx * f) * cx.bw, nv = (0.5f + dy * f) * cx.bh;
                        float sx = cx.fw[0] * nu + cx.fw[1] * nv + cx.fw[2] - cx.x0;
                        float sy = cx.fw[3] * nu + cx.fw[4] * nv + cx.fw[5] - cx.y0;
                        float o[4];
                        bilinear(src, sx, sy, o);
                        uint8_t* p = b.px(x, y);
                        for (int c = 0; c < 4; ++c) p[c] = u8(o[c]);
                    }
                break;
            }
            case FX_FINDEDGES: flush(); findEdges(b, P(e, 0, 1.f, t) * 2.f, P(e, 1, 0.f, t) > 0.5f); break;
            case FX_EMBOSS: flush(); emboss(b, P(e, 0, 1.f, t), P(e, 1, 45.f, t)); break;
            case FX_CHROMAKEY: flush(); chromaKey(b, P(e, 0, 120.f, t), P(e, 1, 30.f, t), P(e, 2, 15.f, t), P(e, 3, 0.5f, t)); break;
            case FX_MASK: {
                flush();
                int shape = (int)std::lround(P(e, 0, 0.f, t));
                float mx = P(e, 1, 0.5f, t), my = P(e, 2, 0.5f, t), mw = std::max(0.01f, P(e, 3, 0.6f, t)), mh = std::max(0.01f, P(e, 4, 0.6f, t));
                float feather = std::max(0.f, P(e, 5, 0.1f, t));
                bool invert = P(e, 6, 0.f, t) > 0.5f;
                for (int y = 0; y < b.h; ++y)
                    for (int x = 0; x < b.w; ++x) {
                        float ax = (float)(x + cx.x0) + 0.f, ay = (float)(y + cx.y0) + 0.f;
                        float u = cx.inv[0] * ax + cx.inv[1] * ay + cx.inv[2], v = cx.inv[3] * ax + cx.inv[4] * ay + cx.inv[5];
                        float dx = (u / cx.bw - mx) / (mw * 0.5f), dy = (v / cx.bh - my) / (mh * 0.5f);
                        float dd = shape == 1 ? std::sqrt(dx * dx + dy * dy) : std::max(std::fabs(dx), std::fabs(dy));
                        float cov = clampf((1.f + feather - dd) / (feather + 1e-4f), 0.f, 1.f);
                        if (invert) cov = 1.f - cov;
                        uint8_t* p = b.px(x, y);
                        for (int c = 0; c < 4; ++c) p[c] = u8(p[c] * cov);
                    }
                break;
            }
            default: break;
        }
    }
    flush();
}

// ---------------- compositing ----------------
inline void blendNormal(uint8_t* d, const uint8_t* s) {
    int sa = s[3];
    if (sa == 0) return;
    if (sa == 255) { memcpy(d, s, 4); return; }
    int inv = 255 - sa;
    d[0] = (uint8_t)(s[0] + (d[0] * inv + 127) / 255);
    d[1] = (uint8_t)(s[1] + (d[1] * inv + 127) / 255);
    d[2] = (uint8_t)(s[2] + (d[2] * inv + 127) / 255);
    d[3] = (uint8_t)(sa + (d[3] * inv + 127) / 255);
}

inline void blendPixelF(uint8_t* dst, const float s[4], int mode) {
    float sa = s[3] / 255.f, da = dst[3] / 255.f;
    if (sa <= 0.f) return;
    if (mode == BL_ADD) {
        for (int c = 0; c < 4; ++c) dst[c] = u8(s[c] + dst[c]);
        return;
    }
    float outA = sa + da - sa * da;
    for (int c = 0; c < 3; ++c) {
        float sp = s[c] / 255.f, dp = dst[c] / 255.f;
        float cs = sp / sa, cd = da > 0.f ? dp / da : 0.f;
        float B;
        if (mode == BL_MULTIPLY) B = cs * cd;
        else if (mode == BL_SCREEN) B = cs + cd - cs * cd;
        else B = cd <= 0.5f ? 2.f * cs * cd : 1.f - 2.f * (1.f - cs) * (1.f - cd);
        float r = (1.f - da) * sp + (1.f - sa) * dp + sa * da * B;
        dst[c] = u8(r * 255.f);
    }
    dst[3] = u8(outA * 255.f);
}

// bilinear, clamp-to-edge, 8-bit fixed point
inline void sampleFast(const Tex& t, float tx, float ty, uint8_t* o) {
    tx = clampf(tx - 0.5f, 0.f, (float)(t.w - 1));
    ty = clampf(ty - 0.5f, 0.f, (float)(t.h - 1));
    int x0 = (int)tx, y0 = (int)ty;
    int fx = (int)((tx - x0) * 256.f), fy = (int)((ty - y0) * 256.f);
    int x1 = std::min(x0 + 1, t.w - 1), y1 = std::min(y0 + 1, t.h - 1);
    const uint8_t* r0 = t.px + (size_t)y0 * t.stride;
    const uint8_t* r1 = t.px + (size_t)y1 * t.stride;
    const uint8_t* p00 = r0 + x0 * 4; const uint8_t* p10 = r0 + x1 * 4;
    const uint8_t* p01 = r1 + x0 * 4; const uint8_t* p11 = r1 + x1 * 4;
    int ifx = 256 - fx, ify = 256 - fy;
    for (int c = 0; c < 4; ++c) {
        int top = p00[c] * ifx + p10[c] * fx;
        int bot = p01[c] * ifx + p11[c] * fx;
        o[c] = (uint8_t)((top * ify + bot * fy) >> 16);
    }
}

}  // namespace

void render(const Scene& sc, float t, int outW, int outH, uint8_t* out, int outStride,
            const std::vector<Tex>& tex, int onlyIndex) {
    if (outW <= 0 || outH <= 0 || sc.cw <= 0 || sc.ch <= 0) return;
    for (int y = 0; y < outH; ++y) memset(out + (size_t)y * outStride, 0, (size_t)outW * 4);
    const float osx = (float)outW / sc.cw, osy = (float)outH / sc.ch;

    for (size_t li = 0; li < sc.layers.size(); ++li) {
        const Layer& L = sc.layers[li];
        if (!L.visible || L.kind == 0 || t < L.inT || t > L.outT) continue;
        if (onlyIndex >= 0 && (int)li != onlyIndex) continue;
        float opac = clampf(L.op.at(t), 0.f, 1.f);
        if (opac <= 0.f) continue;
        const Tex* tx = nullptr;
        if (L.kind == 1) {
            if (li >= tex.size() || !tex[li].px || tex[li].w <= 0) continue;
            tx = &tex[li];
        }
        float sx = L.sx.at(t), sy = L.sy.at(t);
        if (std::fabs(sx) < 1e-5f || std::fabs(sy) < 1e-5f || L.bw <= 0.f || L.bh <= 0.f) continue;
        float pvx = L.pvx.at(t) * L.bw, pvy = L.pvy.at(t) * L.bh;
        float ang = (L.rrev.at(t) * 360.f + L.rdeg.at(t)) * kPi / 180.f;
        float cs = std::cos(ang), sn = std::sin(ang);
        float px = L.px.at(t) * sc.cw, py = L.py.at(t) * sc.ch;
        float margin = 2.f;
        for (const Effect& e : L.fx) {
            if (e.type == FX_SHAKE) {
                float a = P(e, 0, 0.f, t), sp = P(e, 1, 1.f, t), tt = t * sp;
                px += (float)(std::sin(tt * 47.0) * 30.0 * a + std::sin(tt * 91.0 + 1.3) * 14.0 * a);
                py += (float)(std::cos(tt * 53.0) * 30.0 * a + std::cos(tt * 83.0) * 14.0 * a);
            }
        }
        const float scl = 0.5f * (osx + osy);
        for (const Effect& e : L.fx) {
            switch (e.type) {
                case FX_GAUSS: margin = std::max(margin, P(e, 0, 0.f, t) * scl * 0.5f * 3.f + 2.f); break;
                case FX_CROSSBLUR: margin = std::max(margin, std::max(P(e, 0, 0.f, t), P(e, 1, 0.f, t)) * scl * 1.5f + 2.f); break;
                case FX_DIRBLUR: margin = std::max(margin, P(e, 0, 0.f, t) * scl * 0.5f + 2.f); break;
                case FX_GLOW: margin = std::max(margin, P(e, 1, 20.f, t) * scl * 1.5f + 2.f); break;
                case FX_RGBSPLIT: margin = std::max(margin, P(e, 0, 0.f, t) * scl + 2.f); break;
                case FX_MOSAIC: margin = std::max(margin, P(e, 0, 1.f, t) * scl + 2.f); break;
                default: break;
            }
        }
        float fw[6];
        fw[0] = sx * cs * osx;  fw[1] = -sy * sn * osx;
        fw[2] = (-pvx * sx * cs + pvy * sy * sn + px) * osx;
        fw[3] = sx * sn * osy;  fw[4] = sy * cs * osy;
        fw[5] = (-pvx * sx * sn - pvy * sy * cs + py) * osy;
        float inv[6];
        {
            float kx = 1.f / osx, ky = 1.f / osy;
            inv[0] = kx * cs / sx;  inv[1] = ky * sn / sx;
            inv[2] = ((0.5f * kx - px) * cs + (0.5f * ky - py) * sn) / sx + pvx;
            inv[3] = -kx * sn / sy; inv[4] = ky * cs / sy;
            inv[5] = (-(0.5f * kx - px) * sn + (0.5f * ky - py) * cs) / sy + pvy;
        }
        float cu[4] = {0.f, L.bw, L.bw, 0.f}, cvv[4] = {0.f, 0.f, L.bh, L.bh};
        float minx = 1e9f, miny = 1e9f, maxx = -1e9f, maxy = -1e9f;
        for (int i = 0; i < 4; ++i) {
            float X = fw[0] * cu[i] + fw[1] * cvv[i] + fw[2], Y = fw[3] * cu[i] + fw[4] * cvv[i] + fw[5];
            minx = std::min(minx, X); maxx = std::max(maxx, X); miny = std::min(miny, Y); maxy = std::max(maxy, Y);
        }
        int bx0 = std::max(0, (int)std::floor(minx - margin)), by0 = std::max(0, (int)std::floor(miny - margin));
        int bx1 = std::min(outW, (int)std::ceil(maxx + margin)), by1 = std::min(outH, (int)std::ceil(maxy + margin));
        if (bx1 <= bx0 || by1 <= by0) continue;
        const int rw = bx1 - bx0, rh = by1 - by0;
        const float texSx = tx ? tx->w / L.bw : 0.f, texSy = tx ? tx->h / L.bh : 0.f;
        const float edgeK = std::fabs(sx) * osx, edgeKy = std::fabs(sy) * osy;
        const int fr = (int)std::lround(L.color[0] * L.color[3] * 255.f), fg = (int)std::lround(L.color[1] * L.color[3] * 255.f),
                  fb = (int)std::lround(L.color[2] * L.color[3] * 255.f), fa = (int)std::lround(L.color[3] * 255.f);

        // returns false when the pixel is outside the layer box
        auto shade = [&](float u, float v, uint8_t* o) -> bool {
            float du = std::min(u, L.bw - u) * edgeK, dv = std::min(v, L.bh - v) * edgeKy;
            if (du < -0.5f || dv < -0.5f) return false;
            float cov = clampf(du + 0.5f, 0.f, 1.f) * clampf(dv + 0.5f, 0.f, 1.f);
            if (tx) sampleFast(*tx, u * texSx, v * texSy, o);
            else { o[0] = (uint8_t)fr; o[1] = (uint8_t)fg; o[2] = (uint8_t)fb; o[3] = (uint8_t)fa; }
            if (cov < 0.999f) {
                int c256 = (int)(cov * 256.f);
                for (int c = 0; c < 4; ++c) o[c] = (uint8_t)((o[c] * c256) >> 8);
            }
            return true;
        };
        const int opI = (int)(opac * 256.f + 0.5f);
        auto emit = [&](uint8_t* drow, const uint8_t* s4) {
            uint8_t s[4] = {s4[0], s4[1], s4[2], s4[3]};
            if (opI < 256) for (int c = 0; c < 4; ++c) s[c] = (uint8_t)((s[c] * opI) >> 8);
            if (L.blend == BL_NORMAL) blendNormal(drow, s);
            else { float f4[4] = {(float)s[0], (float)s[1], (float)s[2], (float)s[3]}; blendPixelF(drow, f4, L.blend); }
        };

        if (L.fx.empty()) {
            for (int y = 0; y < rh; ++y) {
                float u = inv[0] * (float)bx0 + inv[1] * (float)(y + by0) + inv[2];
                float v = inv[3] * (float)bx0 + inv[4] * (float)(y + by0) + inv[5];
                uint8_t* drow = out + (size_t)(y + by0) * outStride + (size_t)bx0 * 4;
                for (int x = 0; x < rw; ++x, drow += 4, u += inv[0], v += inv[3]) {
                    uint8_t s4[4];
                    if (!shade(u, v, s4)) continue;
                    emit(drow, s4);
                }
            }
        } else {
            Buf buf(rw, rh);
            for (int y = 0; y < rh; ++y) {
                float u = inv[0] * (float)bx0 + inv[1] * (float)(y + by0) + inv[2];
                float v = inv[3] * (float)bx0 + inv[4] * (float)(y + by0) + inv[5];
                uint8_t* row = buf.px(0, y);
                for (int x = 0; x < rw; ++x, row += 4, u += inv[0], v += inv[3]) shade(u, v, row);
            }
            FxCtx cx;
            cx.osx = osx; cx.osy = osy; cx.x0 = bx0; cx.y0 = by0; cx.t = t; cx.bw = L.bw; cx.bh = L.bh;
            memcpy(cx.inv, inv, sizeof inv);
            memcpy(cx.fw, fw, sizeof fw);
            applyEffects(buf, L, cx);
            for (int y = 0; y < rh; ++y) {
                const uint8_t* srow = buf.px(0, y);
                uint8_t* drow = out + (size_t)(y + by0) * outStride + (size_t)bx0 * 4;
                for (int x = 0; x < rw; ++x, srow += 4, drow += 4) {
                    if (srow[3] == 0 && L.blend == BL_NORMAL) continue;
                    emit(drow, srow);
                }
            }
        }
    }
}

}  // namespace mo
