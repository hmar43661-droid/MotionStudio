cmake_minimum_required(VERSION 3.18.1)
project(motion LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
# `assembleDebug` would otherwise compile the engine with -O0 (far too slow for real-time preview)
set(CMAKE_CXX_FLAGS_DEBUG "-O3 -DNDEBUG")
set(CMAKE_CXX_FLAGS_RELEASE "-O3 -DNDEBUG")

add_library(motion SHARED engine.cpp jni_bridge.cpp)
find_library(log-lib log)
target_link_libraries(motion jnigraphics ${log-lib})
