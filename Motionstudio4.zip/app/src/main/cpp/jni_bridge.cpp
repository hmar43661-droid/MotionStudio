// JNI bridge between Kotlin (Engine.kt) and the C++ engine.
// Scene blob layout (float32 array):
//   blob  := [nLayers] layer*
//   layer := [kind, visible, inT, outT, bw, bh, r, g, b, a, blend]
//            + 9 props (px,py,sx,sy,pvx,pvy,rrev,rdeg,op)
//            + [nFx] + fx*
//   fx    := [type, nParams] + prop*
//   prop  := [base, smooth, nKeys, (t, v) * nKeys]
#include <jni.h>
#include <android/bitmap.h>

#include <vector>

#include "engine.h"

using namespace mo;

namespace {

struct Handle {
    Scene scene;
};

struct Reader {
    const float* p;
    const float* end;
    bool ok = true;
    float next() {
        if (p >= end) { ok = false; return 0.f; }
        return *p++;
    }
};

Prop readProp(Reader& r) {
    Prop pr;
    pr.base = r.next();
    pr.smooth = r.next() > 0.5f;
    int n = (int)(r.next() + 0.5f);
    if (n < 0 || n > 100000) { r.ok = false; return pr; }
    pr.keys.reserve((size_t)n);
    for (int i = 0; i < n && r.ok; ++i) {
        Key k;
        k.t = r.next();
        k.v = r.next();
        pr.keys.push_back(k);
    }
    return pr;
}

bool decode(const float* data, int len, Scene& sc) {
    Reader r{data, data + len};
    int n = (int)(r.next() + 0.5f);
    if (n < 0 || n > 4096) return false;
    sc.layers.clear();
    sc.layers.reserve((size_t)n);
    for (int i = 0; i < n && r.ok; ++i) {
        Layer L;
        L.kind = (int)(r.next() + 0.5f);
        L.visible = r.next() > 0.5f;
        L.inT = r.next();
        L.outT = r.next();
        L.bw = r.next();
        L.bh = r.next();
        for (int c = 0; c < 4; ++c) L.color[c] = r.next();
        L.blend = (int)(r.next() + 0.5f);
        L.px = readProp(r); L.py = readProp(r);
        L.sx = readProp(r); L.sy = readProp(r);
        L.pvx = readProp(r); L.pvy = readProp(r);
        L.rrev = readProp(r); L.rdeg = readProp(r);
        L.op = readProp(r);
        int nfx = (int)(r.next() + 0.5f);
        if (nfx < 0 || nfx > 256) return false;
        for (int f = 0; f < nfx && r.ok; ++f) {
            Effect e;
            e.type = (int)(r.next() + 0.5f);
            int np = (int)(r.next() + 0.5f);
            if (np < 0 || np > 16) return false;
            for (int k = 0; k < np && r.ok; ++k) e.p.push_back(readProp(r));
            L.fx.push_back(std::move(e));
        }
        sc.layers.push_back(std::move(L));
    }
    return r.ok;
}

}  // namespace

extern "C" {

JNIEXPORT jlong JNICALL Java_com_motion_studio_Engine_nCreate(JNIEnv*, jclass) {
    return (jlong) new Handle();
}

JNIEXPORT void JNICALL Java_com_motion_studio_Engine_nDestroy(JNIEnv*, jclass, jlong h) {
    delete (Handle*)h;
}

JNIEXPORT jint JNICALL Java_com_motion_studio_Engine_nSetScene(JNIEnv* env, jclass, jlong h, jint cw, jint ch,
                                                                jfloatArray blob, jint len) {
    Handle* hd = (Handle*)h;
    if (!hd || cw <= 0 || ch <= 0 || len <= 0) return -1;
    jfloat* data = env->GetFloatArrayElements(blob, nullptr);
    if (!data) return -2;
    Scene sc;
    sc.cw = cw;
    sc.ch = ch;
    bool ok = decode(data, len, sc);
    env->ReleaseFloatArrayElements(blob, data, JNI_ABORT);
    if (!ok) return -3;
    hd->scene = std::move(sc);
    return 0;
}

JNIEXPORT jint JNICALL Java_com_motion_studio_Engine_nRender(JNIEnv* env, jclass, jlong h, jfloat t, jobject out,
                                                              jobjectArray tex, jint only) {
    Handle* hd = (Handle*)h;
    if (!hd) return -1;
    AndroidBitmapInfo info;
    if (AndroidBitmap_getInfo(env, out, &info) != ANDROID_BITMAP_RESULT_SUCCESS) return -2;
    if (info.format != ANDROID_BITMAP_FORMAT_RGBA_8888) return -3;
    void* pix = nullptr;
    if (AndroidBitmap_lockPixels(env, out, &pix) != ANDROID_BITMAP_RESULT_SUCCESS || !pix) return -4;

    const size_t nl = hd->scene.layers.size();
    std::vector<Tex> texs(nl);
    std::vector<jobject> locked;
    jsize ta = tex ? env->GetArrayLength(tex) : 0;
    for (jsize i = 0; i < ta && (size_t)i < nl; ++i) {
        jobject b = env->GetObjectArrayElement(tex, i);
        if (!b) continue;
        AndroidBitmapInfo ti;
        void* tp = nullptr;
        if (AndroidBitmap_getInfo(env, b, &ti) == ANDROID_BITMAP_RESULT_SUCCESS &&
            ti.format == ANDROID_BITMAP_FORMAT_RGBA_8888 &&
            AndroidBitmap_lockPixels(env, b, &tp) == ANDROID_BITMAP_RESULT_SUCCESS && tp) {
            texs[(size_t)i].px = (const uint8_t*)tp;
            texs[(size_t)i].w = (int)ti.width;
            texs[(size_t)i].h = (int)ti.height;
            texs[(size_t)i].stride = (int)ti.stride;
            locked.push_back(b);
        } else {
            env->DeleteLocalRef(b);
        }
    }

    mo::render(hd->scene, t, (int)info.width, (int)info.height, (uint8_t*)pix, (int)info.stride, texs, (int)only);

    for (jobject b : locked) {
        AndroidBitmap_unlockPixels(env, b);
        env->DeleteLocalRef(b);
    }
    AndroidBitmap_unlockPixels(env, out);
    return 0;
}

}  // extern "C"
