package com.motion.studio

import android.graphics.Paint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.matchParentSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.roundToInt

private fun clockLabel(sec: Float, fine: Boolean): String {
    if (fine) return "%.1fs".format(sec)
    val s = sec.toInt()
    return "%d:%02d".format(s / 60, s % 60)
}

/**
 * Timeline: the playhead stays at the centre and the tracks scroll under it.
 * Top track = video clips (ripple, with draggable trim handles); below = layer bars.
 */
@Composable
fun TimelineView(st: EditorState) {
    val comp = st.comp
    val density = LocalDensity.current
    val pps = 52f  // dp per second
    BoxWithConstraints(Modifier.fillMaxWidth().height(if (st.tlExpanded) 196.dp else 112.dp).padding(top = 4.dp)) {
        val widthPx = with(density) { maxWidth.toPx() }
        val ppsPx = with(density) { pps.dp.toPx() }
        val centerPx = widthPx / 2f
        Column(
            Modifier.fillMaxSize()
                .pointerInput(ppsPx) { detectHorizontalDragGestures { change, dx -> change.consume(); st.seek(st.t - dx / ppsPx) } }
                .pointerInput(Unit) { detectTapGestures { st.selId = -1 } }
        ) {
            // ---- ruler ----
            Canvas(Modifier.fillMaxWidth().height(26.dp)) {
                val half = size.width / 2f
                val tn = st.tDraw
                val t0 = tn - half / ppsPx
                val t1 = tn + half / ppsPx
                var step = 1f
                val cands = floatArrayOf(0.1f, 0.5f, 1f, 2f, 5f, 10f, 30f, 60f, 300f)
                for (c in cands) { step = c; if (c * ppsPx >= 46f) break }
                val p = Paint(Paint.ANTI_ALIAS_FLAG)
                p.color = 0xFF8E98C4.toInt()
                p.textSize = 11f * density.density
                var k = ceil(max(t0, 0f) / step).toInt()
                drawIntoCanvas { cv ->
                    while (k * step <= t1 && k * step <= comp.dur + step) {
                        val x = half + (k * step - tn) * ppsPx
                        drawLine(Color(0x55FFFFFF), Offset(x, size.height - 9f), Offset(x, size.height), 2f)
                        cv.nativeCanvas.drawText(clockLabel(k * step, step < 1f), x + 4f, size.height - 6f, p)
                        k++
                    }
                }
                comp.markers.forEach { m ->
                    val x = half + (m - tn) * ppsPx
                    drawCircle(Color(0xFFFFD60A), 4f * density.density, Offset(x, 4f * density.density))
                }
            }
            // ---- video track ----
            Box(Modifier.fillMaxWidth().height(54.dp)) {
                st.videoClips().forEach { c -> ClipBlock(st, c, pps, ppsPx, centerPx) }
            }
            // ---- layer bars ----
            if (st.tlExpanded) {
                Column(Modifier.fillMaxWidth().weight(1f).verticalScroll(rememberScrollState())) {
                    comp.layers.filter { it.kind != Kind.VIDEO }.reversed().forEach { l -> LayerBar(st, l, pps, ppsPx, centerPx) }
                }
            }
        }
        // ---- playhead ----
        Box(Modifier.align(Alignment.TopCenter).width(2.dp).fillMaxHeight().background(PinkC))
        Row(
            Modifier.align(Alignment.TopCenter).clip(RoundedCornerShape(8.dp)).background(PinkC)
                .tap { st.toggleMarker() }.padding(horizontal = 8.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Ico("flag", 12.dp, Color.White)
            Text(" " + tcShort(st.t), color = Color.White, fontSize = 12.sp)
        }
        Box(Modifier.align(Alignment.CenterStart).size(28.dp).tap { st.tlExpanded = !st.tlExpanded }, contentAlignment = Alignment.Center) {
            Ico(if (st.tlExpanded) "chevD" else "chevR", 16.dp, TxtLo)
        }
    }
}

@Composable
private fun ClipBlock(st: EditorState, c: Layer, pps: Float, ppsPx: Float, centerPx: Float) {
    val selected = st.selId == c.id
    val shape = RoundedCornerShape(10.dp)
    Box(
        Modifier.offset { IntOffset(((c.inT - st.tDraw) * ppsPx + centerPx).roundToInt(), 0) }
            .width(((c.outT - c.inT) * pps).dp).fillMaxHeight().padding(horizontal = 1.dp, vertical = 3.dp)
            .clip(shape).background(Brush.horizontalGradient(listOf(Color(0xFF223070), Color(0xFF2B2A6B))))
            .then(if (selected) Modifier.border(2.dp, TealC, shape) else Modifier)
            .tap { st.selId = c.id }
    ) {
        val th = c.thumb
        if (th != null) Image(th.asImageBitmap(), null, Modifier.matchParentSize(), contentScale = ContentScale.Crop, alpha = 0.55f)
        Text(c.name, color = TxtHi, fontSize = 11.sp, maxLines = 1, modifier = Modifier.align(Alignment.TopStart).padding(start = 24.dp, top = 3.dp))
        Text(clockLabel(c.outT - c.inT, false), color = TxtHi, fontSize = 11.sp, modifier = Modifier.align(Alignment.BottomEnd).padding(end = 24.dp, bottom = 2.dp))
        if (selected) {
            Box(
                Modifier.align(Alignment.CenterStart).width(22.dp).fillMaxHeight().background(TealC)
                    .pointerInput(c.id, ppsPx) {
                        detectHorizontalDragGestures(onDragStart = { st.snap() }) { change, dx -> change.consume(); st.trimStart(c, dx / ppsPx) }
                    },
                contentAlignment = Alignment.Center
            ) { Box(Modifier.width(3.dp).height(18.dp).background(Ink, RoundedCornerShape(2.dp))) }
            Box(
                Modifier.align(Alignment.CenterEnd).width(22.dp).fillMaxHeight().background(TealC)
                    .pointerInput(c.id, ppsPx) {
                        detectHorizontalDragGestures(onDragStart = { st.snap() }) { change, dx -> change.consume(); st.trimEnd(c, dx / ppsPx) }
                    },
                contentAlignment = Alignment.Center
            ) { Box(Modifier.width(3.dp).height(18.dp).background(Ink, RoundedCornerShape(2.dp))) }
        }
    }
}

@Composable
private fun LayerBar(st: EditorState, l: Layer, pps: Float, ppsPx: Float, centerPx: Float) {
    val selected = st.selId == l.id
    val shape = RoundedCornerShape(8.dp)
    val tint = when (l.kind) {
        Kind.TEXT -> Color(0xFF1FA48D)
        Kind.IMAGE -> Color(0xFFB04A82)
        Kind.FILL -> Color(0xFF6B4BC8)
        else -> Color(0xFF3C5BD0)
    }
    Box(Modifier.fillMaxWidth().height(30.dp)) {
        Box(
            Modifier.offset { IntOffset(((l.inT - st.tDraw) * ppsPx + centerPx).roundToInt(), 0) }
                .width(((l.outT - l.inT) * pps).dp).fillMaxHeight().padding(vertical = 3.dp)
                .clip(shape).background(tint.copy(alpha = if (l.visible) 0.9f else 0.35f))
                .then(if (selected) Modifier.border(2.dp, TealC, shape) else Modifier)
                .tap { st.selId = l.id }
        ) {
            Canvas(Modifier.matchParentSize()) {
                l.allProps().flatMap { pr -> pr.keys.map { it.t } }.distinct().forEach { kt ->
                    drawCircle(Color.White, 3.5f * density, Offset((kt - l.inT) * ppsPx, size.height / 2f))
                }
            }
            Text(l.name, color = Color.White, fontSize = 11.sp, maxLines = 1, modifier = Modifier.align(Alignment.CenterStart).padding(start = 22.dp))
            if (selected) {
                Box(
                    Modifier.align(Alignment.CenterStart).width(18.dp).fillMaxHeight().background(TealC)
                        .pointerInput(l.id, ppsPx) {
                            detectHorizontalDragGestures(onDragStart = { st.snap() }) { change, dx -> change.consume(); st.trimLayerIn(l, dx / ppsPx) }
                        }
                )
                Box(
                    Modifier.align(Alignment.CenterEnd).width(18.dp).fillMaxHeight().background(TealC)
                        .pointerInput(l.id, ppsPx) {
                            detectHorizontalDragGestures(onDragStart = { st.snap() }) { change, dx -> change.consume(); st.trimLayerOut(l, dx / ppsPx) }
                        }
                )
            }
        }
    }
}
