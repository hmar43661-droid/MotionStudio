package com.motion.studio

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color as AColor
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.abs
import kotlin.math.ceil

enum class Kind { VIDEO, TEXT, RECT, ELLIPSE, FILL, IMAGE }

class Key(val t: Float, val v: Float)

/** Animatable value (stopwatch): constant base value or keyframes with optional ease. */
class Prop(val initial: Float) {
    var base by mutableStateOf(initial)
    var smooth by mutableStateOf(true)
    val keys = mutableStateListOf<Key>()

    fun setKey(t: Float, v: Float) {
        val i = keys.indexOfFirst { abs(it.t - t) < 0.02f }
        if (i >= 0) keys.removeAt(i)
        keys.add(Key(t, v))
        keys.sortBy { it.t }
    }

    fun at(t: Float): Float {
        if (keys.isEmpty()) return base
        if (t <= keys.first().t) return keys.first().v
        if (t >= keys.last().t) return keys.last().v
        for (i in 0 until keys.size - 1) {
            val a = keys[i]
            val b = keys[i + 1]
            if (t >= a.t && t <= b.t) {
                val f = (t - a.t) / (b.t - a.t)
                val e = if (smooth) f * f * (3f - 2f * f) else f
                return a.v + (b.v - a.v) * e
            }
        }
        return keys.last().v
    }

    fun toJson(): JSONObject {
        val a = JSONArray()
        keys.forEach { a.put(JSONArray().put(it.t.toDouble()).put(it.v.toDouble())) }
        return JSONObject().put("b", base.toDouble()).put("s", smooth).put("k", a)
    }

    fun fromJson(o: JSONObject?) {
        if (o == null) return
        base = o.optDouble("b", initial.toDouble()).toFloat()
        smooth = o.optBoolean("s", true)
        keys.clear()
        val a = o.optJSONArray("k")
        if (a != null) for (i in 0 until a.length()) {
            val k = a.getJSONArray(i)
            keys.add(Key(k.getDouble(0).toFloat(), k.getDouble(1).toFloat()))
        }
    }
}

// ===================== Effects (ids match the C++ engine enum FxType) =====================

class FxParam(val name: String, val min: Float, val max: Float, val def: Float, val fmt: String = "%.2f")
class FxDef(val type: String, val id: Int, val label: String, val cat: String, val params: List<FxParam>, val preview: List<Float>)

val FX_DEFS = listOf(
    FxDef("brightness", 0, "Brightness", "Color", listOf(FxParam("Amount", -1f, 1f, 0f)), listOf(0.35f)),
    FxDef("contrast", 1, "Contrast", "Color", listOf(FxParam("Amount", 0f, 2f, 1f)), listOf(1.6f)),
    FxDef("saturation", 2, "Saturation", "Color", listOf(FxParam("Amount", 0f, 2f, 1f)), listOf(1.9f)),
    FxDef("hue", 3, "Hue", "Color", listOf(FxParam("Degrees", -180f, 180f, 0f, "%.0f")), listOf(120f)),
    FxDef("invert", 4, "Invert", "Color", listOf(FxParam("Amount", 0f, 1f, 0f)), listOf(1f)),
    FxDef("sepia", 5, "Sepia", "Color", listOf(FxParam("Amount", 0f, 1f, 0f)), listOf(1f)),
    FxDef("colorcorrect", 6, "Color Correction", "Color",
        listOf(FxParam("Exposure", -3f, 3f, 0f), FxParam("Gamma", 0.2f, 3f, 1f), FxParam("Temperature", -1f, 1f, 0f), FxParam("Tint", -1f, 1f, 0f)),
        listOf(0.6f, 1f, 0.5f, 0f)),
    FxDef("curves", 7, "Curves", "Color",
        listOf(FxParam("Shadows", -1f, 1f, 0f), FxParam("Midtones", -1f, 1f, 0f), FxParam("Highlights", -1f, 1f, 0f), FxParam("Contrast", -1f, 1f, 0f)),
        listOf(0.6f, 0f, -0.4f, 0.5f)),
    FxDef("hsl", 8, "HSL", "Color",
        listOf(FxParam("Hue", -180f, 180f, 0f, "%.0f"), FxParam("Saturation", 0f, 2f, 1f), FxParam("Lightness", -1f, 1f, 0f)),
        listOf(80f, 1.4f, 0f)),
    FxDef("tone", 9, "Tone", "Color",
        listOf(FxParam("Exposure", -3f, 3f, 0f), FxParam("Gamma", -1f, 1f, 0f), FxParam("Contrast", -1f, 1f, 0f), FxParam("Highlights", -1f, 1f, 0f),
            FxParam("Shadows", -1f, 1f, 0f), FxParam("Whites", -1f, 1f, 0f), FxParam("Blacks", -1f, 1f, 0f)),
        listOf(0.5f, 0f, 0.4f, 0f, 0f, 0f, 0f)),
    FxDef("gauss", 10, "Gaussian Blur", "Blur", listOf(FxParam("Radius", 0f, 100f, 12f, "%.0f")), listOf(6f)),
    FxDef("dirblur", 11, "Motion Blur", "Blur", listOf(FxParam("Length", 0f, 200f, 30f, "%.0f"), FxParam("Angle", -180f, 180f, 0f, "%.0f")), listOf(25f, 0f)),
    FxDef("radialblur", 12, "Radial Blur", "Blur", listOf(FxParam("Amount", 0f, 1f, 0.3f), FxParam("Center X", 0f, 1f, 0.5f), FxParam("Center Y", 0f, 1f, 0.5f)), listOf(0.5f, 0.5f, 0.5f)),
    FxDef("crossblur", 13, "Cross Blur", "Blur", listOf(FxParam("Horizontal", 0f, 100f, 10f, "%.0f"), FxParam("Vertical", 0f, 100f, 10f, "%.0f")), listOf(8f, 2f)),
    FxDef("glow", 14, "Glow", "Light", listOf(FxParam("Intensity", 0f, 3f, 1f), FxParam("Radius", 0f, 100f, 20f, "%.0f"), FxParam("Threshold", 0f, 1f, 0.5f)), listOf(1f, 12f, 0.4f)),
    FxDef("vignette", 15, "Vignette", "Light", listOf(FxParam("Amount", 0f, 1f, 0.5f), FxParam("Size", 0.2f, 1.5f, 0.8f), FxParam("Softness", 0.05f, 1f, 0.5f)), listOf(0.9f, 0.6f, 0.4f)),
    FxDef("grain", 16, "Grain", "Stylize", listOf(FxParam("Amount", 0f, 1f, 0.3f), FxParam("Speed", 0f, 5f, 1f)), listOf(0.6f, 1f)),
    FxDef("mosaic", 19, "Mosaic", "Stylize", listOf(FxParam("Size", 1f, 100f, 12f, "%.0f")), listOf(10f)),
    FxDef("findedges", 22, "Find Edges", "Stylize", listOf(FxParam("Strength", 0f, 3f, 1f), FxParam("Invert", 0f, 1f, 0f, "%.0f")), listOf(1f, 0f)),
    FxDef("emboss", 23, "Emboss", "Stylize", listOf(FxParam("Strength", 0f, 3f, 1f), FxParam("Angle", -180f, 180f, 45f, "%.0f")), listOf(1f, 45f)),
    FxDef("rgbsplit", 17, "RGB Split", "Glitch", listOf(FxParam("Amount", 0f, 60f, 8f, "%.0f"), FxParam("Angle", -180f, 180f, 0f, "%.0f")), listOf(8f, 0f)),
    FxDef("chromaab", 18, "Chromatic Aberration", "Glitch", listOf(FxParam("Strength", 0f, 1f, 0.4f)), listOf(0.8f)),
    FxDef("mirror", 20, "Mirror", "Distort", listOf(FxParam("Mode", 0f, 4f, 1f, "%.0f")), listOf(1f)),
    FxDef("lensdist", 21, "Lens Distortion", "Distort", listOf(FxParam("Amount", -1f, 1f, 0.3f)), listOf(0.6f)),
    FxDef("chromakey", 24, "Chroma Key", "Keying",
        listOf(FxParam("Key Hue", 0f, 360f, 120f, "%.0f"), FxParam("Tolerance", 0f, 90f, 30f, "%.0f"), FxParam("Softness", 0f, 60f, 15f, "%.0f"), FxParam("Spill", 0f, 1f, 0.5f)),
        listOf(120f, 30f, 15f, 0.5f)),
    FxDef("mask", 25, "Mask", "Keying",
        listOf(FxParam("Shape", 0f, 1f, 0f, "%.0f"), FxParam("X", 0f, 1f, 0.5f), FxParam("Y", 0f, 1f, 0.5f), FxParam("Width", 0f, 2f, 0.6f),
            FxParam("Height", 0f, 2f, 0.6f), FxParam("Feather", 0f, 1f, 0.1f), FxParam("Invert", 0f, 1f, 0f, "%.0f")),
        listOf(1f, 0.5f, 0.5f, 0.6f, 0.6f, 0.2f, 0f)),
    FxDef("shake", 26, "Shake", "Motion", listOf(FxParam("Amount", 0f, 1f, 0.3f), FxParam("Speed", 0.1f, 5f, 1f)), listOf(0.4f, 1f))
)
val FX_CATS = listOf("Color", "Blur", "Light", "Stylize", "Glitch", "Distort", "Keying", "Motion")

class Fx(val type: String) {
    val def: FxDef = FX_DEFS.firstOrNull { it.type == type } ?: FX_DEFS[0]
    val params: List<Prop> = def.params.map { Prop(it.def) }
}

// ===================== Layers / project =====================

class Layer(val id: Int, val kind: Kind) {
    var name by mutableStateOf("")
    var text by mutableStateOf("Text")
    var color by mutableStateOf(AColor.WHITE)
    var w by mutableStateOf(400f)
    var h by mutableStateOf(240f)
    var shape by mutableStateOf("")
    var inT by mutableStateOf(0f)
    var outT by mutableStateOf(10f)
    var visible by mutableStateOf(true)
    var linkScale by mutableStateOf(true)
    var uri: Uri? = null
    var bmp: Bitmap? = null
    var imgFile: String? = null
    // video clip fields (source in/out in seconds)
    var srcIn by mutableStateOf(0f)
    var srcOut by mutableStateOf(0f)
    var srcDur by mutableStateOf(0f)
    var vw: Int = 0
    var vh: Int = 0
    var mediaId: Int = -1
    var thumb: Bitmap? by mutableStateOf<Bitmap?>(null)
    // raster cache (text / shapes are rasterised and handed to the C++ engine as textures)
    var raster: Bitmap? = null
    var rasterSig: String = ""
    val px = Prop(0.5f)
    val py = Prop(0.5f)
    val sx = Prop(1f)
    val sy = Prop(1f)
    val pvx = Prop(0.5f)
    val pvy = Prop(0.5f)
    val rrev = Prop(0f)
    val rdeg = Prop(0f)
    val op = Prop(1f)
    val effects = mutableStateListOf<Fx>()

    fun transformProps(): List<Prop> = listOf(px, py, sx, sy, pvx, pvy, rrev, rdeg, op)
    fun allProps(): List<Prop> = transformProps() + effects.flatMap { it.params }
}

class MediaInfo(val id: Int, val kind: String, val uri: String, val name: String, val dur: Float, val w: Int, val h: Int) {
    var thumb: Bitmap? by mutableStateOf<Bitmap?>(null)
}

class Comp {
    var name by mutableStateOf("Untitled")
    var cw by mutableStateOf(1280)
    var ch by mutableStateOf(720)
    var dur by mutableStateOf(10f)
    var fps by mutableStateOf(30)
    var ratio by mutableStateOf("16:9")
    var previewRes by mutableStateOf(50)
    var renderMode by mutableStateOf("All Layers")
    var nextId = 1
    var nextMediaId = 1
    val layers = mutableStateListOf<Layer>()
    val markers = mutableStateListOf<Float>()
    val media = mutableStateListOf<MediaInfo>()
}

// ===================== Geometry (kept in sync with the C++ engine) =====================

fun imgFit(l: Layer, cw: Int, ch: Int): Float {
    val b = l.bmp ?: return 1f
    return minOf(cw.toFloat() / b.width, ch.toFloat() / b.height)
}

fun boxSize(l: Layer, cw: Int, ch: Int): Pair<Float, Float> = when (l.kind) {
    Kind.TEXT -> {
        val p = Paint()
        p.textSize = l.h
        p.isFakeBoldText = true
        val fm = p.fontMetrics
        maxOf(1f, ceil(p.measureText(l.text))) to maxOf(1f, ceil(fm.descent - fm.ascent))
    }
    Kind.RECT, Kind.ELLIPSE -> maxOf(1, l.w.toInt()).toFloat() to maxOf(1, l.h.toInt()).toFloat()
    Kind.IMAGE -> {
        val f = imgFit(l, cw, ch)
        (l.bmp?.width ?: 1) * f to (l.bmp?.height ?: 1) * f
    }
    else -> cw.toFloat() to ch.toFloat()
}

fun layerMatrix(l: Layer, t: Float, cw: Int, ch: Int): Matrix {
    val (bw, bh) = boxSize(l, cw, ch)
    val m = Matrix()
    m.postTranslate(-l.pvx.at(t) * bw, -l.pvy.at(t) * bh)
    m.postScale(l.sx.at(t), l.sy.at(t))
    m.postRotate(l.rrev.at(t) * 360f + l.rdeg.at(t))
    m.postTranslate(l.px.at(t) * cw, l.py.at(t) * ch)
    val sh = l.effects.firstOrNull { it.type == "shake" }
    if (sh != null) {
        val a = sh.params[0].at(t)
        val sp = sh.params[1].at(t)
        val tt = t * sp
        m.postTranslate(
            (Math.sin(tt * 47.0) * 30.0 * a + Math.sin(tt * 91.0 + 1.3) * 14.0 * a).toFloat(),
            (Math.cos(tt * 53.0) * 30.0 * a + Math.cos(tt * 83.0) * 14.0 * a).toFloat()
        )
    }
    return m
}

fun drawSelection(c: Canvas, comp: Comp, l: Layer, t: Float) {
    val (bw, bh) = boxSize(l, comp.cw, comp.ch)
    val pts = floatArrayOf(0f, 0f, bw, 0f, bw, bh, 0f, bh, bw / 2f, 0f, bw, bh / 2f, bw / 2f, bh, 0f, bh / 2f)
    layerMatrix(l, t, comp.cw, comp.ch).mapPoints(pts)
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.style = Paint.Style.STROKE
    p.strokeWidth = 3f
    p.color = AColor.argb(220, 45, 224, 194)
    p.pathEffect = DashPathEffect(floatArrayOf(10f, 8f), 0f)
    val path = Path()
    path.moveTo(pts[0], pts[1])
    for (i in 1..3) path.lineTo(pts[i * 2], pts[i * 2 + 1])
    path.close()
    c.drawPath(path, p)
    p.style = Paint.Style.FILL
    p.pathEffect = null
    for (i in 4..7) c.drawRect(pts[i * 2] - 9f, pts[i * 2 + 1] - 9f, pts[i * 2] + 9f, pts[i * 2 + 1] + 9f, p)
}

/** Rasterises text / shapes so the C++ engine can transform and composite them as textures. */
fun ensureRaster(l: Layer, cw: Int, ch: Int): Bitmap? {
    when (l.kind) {
        Kind.IMAGE -> return l.bmp
        Kind.TEXT, Kind.RECT, Kind.ELLIPSE -> {
            val (bw, bh) = boxSize(l, cw, ch)
            val sig = "${l.kind}|${l.shape}|${l.text}|${l.color}|$bw|$bh"
            val cur = l.raster
            if (cur != null && sig == l.rasterSig) return cur
            val bmp = Bitmap.createBitmap(maxOf(1, bw.toInt()), maxOf(1, bh.toInt()), Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp)
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.color = l.color
            val w = bmp.width.toFloat()
            val h = bmp.height.toFloat()
            if (l.kind == Kind.TEXT) {
                p.textSize = l.h
                p.isFakeBoldText = true
                c.drawText(l.text, 0f, -p.fontMetrics.ascent, p)
            } else when (l.shape) {
                "ellipse", "circle" -> c.drawOval(RectF(0f, 0f, w, h), p)
                "rounded" -> c.drawRoundRect(RectF(0f, 0f, w, h), minOf(w, h) * 0.22f, minOf(w, h) * 0.22f, p)
                "triangle" -> {
                    val path = Path()
                    path.moveTo(w / 2f, 0f); path.lineTo(w, h); path.lineTo(0f, h); path.close()
                    c.drawPath(path, p)
                }
                "diamond" -> {
                    val path = Path()
                    path.moveTo(w / 2f, 0f); path.lineTo(w, h / 2f); path.lineTo(w / 2f, h); path.lineTo(0f, h / 2f); path.close()
                    c.drawPath(path, p)
                }
                else -> c.drawRect(0f, 0f, w, h, p)
            }
            l.raster = bmp
            l.rasterSig = sig
            return bmp
        }
        else -> return null
    }
}

// ===================== Video clips (ripple timeline) =====================

fun relayoutVideo(comp: Comp) {
    val clips = comp.layers.filter { it.kind == Kind.VIDEO }
    if (clips.isEmpty()) return
    val oldDur = comp.dur
    var cur = 0f
    for (l in clips) {
        val len = l.srcOut - l.srcIn
        l.inT = cur
        l.outT = cur + len
        cur += len
    }
    for (l in comp.layers) {
        if (l.kind == Kind.VIDEO) continue
        if (l.outT >= oldDur - 0.01f) l.outT = cur
        if (l.outT > cur) l.outT = cur
        if (l.inT >= l.outT) l.inT = maxOf(0f, l.outT - 0.1f)
    }
    comp.dur = cur
}

fun addClipLayer(comp: Comp, m: MediaInfo): Layer {
    val l = Layer(comp.nextId++, Kind.VIDEO)
    l.name = m.name.take(18)
    l.uri = Uri.parse(m.uri)
    l.srcIn = 0f
    l.srcOut = m.dur
    l.srcDur = m.dur
    l.vw = m.w
    l.vh = m.h
    l.mediaId = m.id
    l.thumb = m.thumb
    if (comp.layers.none { it.kind == Kind.VIDEO }) {
        val sc = minOf(1f, 1280f / maxOf(m.w, m.h, 1))
        comp.cw = maxOf(2, (m.w * sc).toInt() / 2 * 2)
        comp.ch = maxOf(2, (m.h * sc).toInt() / 2 * 2)
        comp.ratio = "Custom"
    }
    comp.layers.add(comp.layers.indexOfLast { it.kind == Kind.VIDEO } + 1, l)
    relayoutVideo(comp)
    return l
}

fun persistUri(ctx: Context, u: Uri) {
    try {
        ctx.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
    } catch (e: Exception) {
    }
}

fun displayName(ctx: Context, uri: Uri): String =
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (i >= 0 && c.moveToFirst()) c.getString(i) else null
    } ?: "media"

/** Reads metadata + thumbnail of a picked video/image. Returns null if unsupported. */
fun makeMedia(ctx: Context, comp: Comp, u: Uri): MediaInfo? {
    val type = ctx.contentResolver.getType(u) ?: ""
    val name = displayName(ctx, u)
    if (type.startsWith("video")) {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, u)
            var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 1280
            var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 720
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) { val tmp = w; w = h; h = tmp }
            val d = (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 5000L) / 1000f
            val m = MediaInfo(comp.nextMediaId++, "video", u.toString(), name, d, w, h)
            r.getFrameAtTime(0)?.let { f ->
                val k = 256f / maxOf(f.width, f.height)
                m.thumb = Bitmap.createScaledBitmap(f, maxOf(1, (f.width * k).toInt()), maxOf(1, (f.height * k).toInt()), true)
            }
            return m
        } finally {
            r.release()
        }
    }
    if (type.startsWith("image")) {
        val raw = ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it) } ?: return null
        val k = 256f / maxOf(raw.width, raw.height)
        val m = MediaInfo(comp.nextMediaId++, "image", u.toString(), name, 0f, raw.width, raw.height)
        m.thumb = Bitmap.createScaledBitmap(raw, maxOf(1, (raw.width * k).toInt()), maxOf(1, (raw.height * k).toInt()), true)
        return m
    }
    return null
}

fun decodeImage(ctx: Context, u: Uri): Bitmap? {
    val raw = ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it) } ?: return null
    val sc = minOf(1f, 1024f / maxOf(raw.width, raw.height))
    return if (sc < 1f) Bitmap.createScaledBitmap(raw, (raw.width * sc).toInt(), (raw.height * sc).toInt(), true) else raw
}

// ===================== Effect thumbnails (rendered by the C++ engine) =====================

fun sampleBitmap(): Bitmap {
    val b = Bitmap.createBitmap(160, 160, Bitmap.Config.ARGB_8888)
    val c = Canvas(b)
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.shader = LinearGradient(0f, 0f, 160f, 160f, intArrayOf(0xFF8B5CF6.toInt(), 0xFF22D3EE.toInt(), 0xFFF472B6.toInt()), null, Shader.TileMode.CLAMP)
    c.drawRect(0f, 0f, 160f, 160f, p)
    p.shader = null
    p.color = AColor.WHITE
    c.drawCircle(52f, 56f, 26f, p)
    p.color = 0xFFFACC15.toInt()
    c.drawCircle(112f, 104f, 20f, p)
    p.color = 0xFF00FF00.toInt()
    c.drawCircle(112f, 40f, 16f, p)
    p.color = AColor.argb(110, 0, 0, 0)
    for (i in 0..4) c.drawRect(0f, 20f + i * 32f, 160f, 26f + i * 32f, p)
    return b
}

fun fxThumb(d: FxDef): Bitmap {
    val comp = Comp()
    comp.cw = 160
    comp.ch = 160
    val l = Layer(1, Kind.IMAGE)
    l.bmp = sampleBitmap()
    l.outT = 1f
    val e = Fx(d.type)
    d.preview.forEachIndexed { i, v -> if (i < e.params.size) e.params[i].base = v }
    l.effects.add(e)
    comp.layers.add(l)
    val out = Bitmap.createBitmap(160, 160, Bitmap.Config.ARGB_8888)
    val r = Renderer()
    try {
        r.render(comp, 0.5f, out)
    } finally {
        r.close()
    }
    return out
}

// ===================== Project storage =====================

class ProjInfo(
    val id: String, val name: String, val modified: Long, val size: Long, val thumb: Bitmap?,
    val ratio: String, val height: Int, val fps: Int, val dur: Float
)

object Store {
    fun dir(ctx: Context): File = File(ctx.filesDir, "projects").also { it.mkdirs() }

    fun layerToJson(l: Layer): JSONObject {
        val fx = JSONArray()
        l.effects.forEach { e ->
            val ps = JSONArray()
            e.params.forEach { ps.put(it.toJson()) }
            fx.put(JSONObject().put("t", e.type).put("ps", ps))
        }
        val pr = JSONObject()
            .put("px", l.px.toJson()).put("py", l.py.toJson()).put("sx", l.sx.toJson()).put("sy", l.sy.toJson())
            .put("pvx", l.pvx.toJson()).put("pvy", l.pvy.toJson()).put("rrev", l.rrev.toJson())
            .put("rdeg", l.rdeg.toJson()).put("op", l.op.toJson())
        return JSONObject().put("id", l.id).put("kind", l.kind.name).put("name", l.name).put("text", l.text)
            .put("color", l.color).put("w", l.w.toDouble()).put("h", l.h.toDouble()).put("shape", l.shape)
            .put("in", l.inT.toDouble()).put("out", l.outT.toDouble()).put("vis", l.visible)
            .put("link", l.linkScale).put("uri", l.uri?.toString() ?: "").put("img", l.imgFile ?: "")
            .put("srcIn", l.srcIn.toDouble()).put("srcOut", l.srcOut.toDouble()).put("srcDur", l.srcDur.toDouble())
            .put("vw", l.vw).put("vh", l.vh).put("mediaId", l.mediaId)
            .put("props", pr).put("fx", fx)
    }

    fun compToJson(c: Comp): JSONObject {
        val la = JSONArray()
        c.layers.forEach { la.put(layerToJson(it)) }
        val mk = JSONArray()
        c.markers.forEach { mk.put(it.toDouble()) }
        val md = JSONArray()
        c.media.forEach {
            md.put(JSONObject().put("id", it.id).put("kind", it.kind).put("uri", it.uri).put("name", it.name)
                .put("dur", it.dur.toDouble()).put("w", it.w).put("h", it.h))
        }
        return JSONObject().put("name", c.name).put("cw", c.cw).put("ch", c.ch).put("dur", c.dur.toDouble())
            .put("fps", c.fps).put("ratio", c.ratio).put("pres", c.previewRes).put("mode", c.renderMode)
            .put("next", c.nextId).put("nextMedia", c.nextMediaId).put("markers", mk).put("media", md).put("layers", la)
    }

    fun layerFromJson(o: JSONObject, bmps: Map<Int, Bitmap>, thumbs: Map<Int, Bitmap>, d: File): Layer {
        val l = Layer(o.getInt("id"), Kind.valueOf(o.getString("kind")))
        l.name = o.optString("name")
        l.text = o.optString("text", "Text")
        l.color = o.optInt("color", AColor.WHITE)
        l.w = o.optDouble("w", 400.0).toFloat()
        l.h = o.optDouble("h", 240.0).toFloat()
        l.shape = o.optString("shape", "")
        l.inT = o.optDouble("in", 0.0).toFloat()
        l.outT = o.optDouble("out", 10.0).toFloat()
        l.visible = o.optBoolean("vis", true)
        l.linkScale = o.optBoolean("link", true)
        val u = o.optString("uri")
        l.uri = if (u.isNotEmpty()) Uri.parse(u) else null
        l.imgFile = o.optString("img").ifEmpty { null }
        // projects saved by v0.2 have no source in/out: derive them from the layer range
        l.srcIn = o.optDouble("srcIn", 0.0).toFloat()
        l.srcOut = o.optDouble("srcOut", (l.outT - l.inT).toDouble()).toFloat()
        l.srcDur = o.optDouble("srcDur", l.srcOut.toDouble()).toFloat()
        l.vw = o.optInt("vw", 0)
        l.vh = o.optInt("vh", 0)
        l.mediaId = o.optInt("mediaId", -1)
        l.thumb = thumbs[l.id]
        l.bmp = bmps[l.id] ?: l.imgFile?.let { fn ->
            val f = File(d, fn)
            if (f.exists()) BitmapFactory.decodeFile(f.path) else null
        }
        val pr = o.optJSONObject("props")
        if (pr != null) {
            l.px.fromJson(pr.optJSONObject("px")); l.py.fromJson(pr.optJSONObject("py"))
            l.sx.fromJson(pr.optJSONObject("sx")); l.sy.fromJson(pr.optJSONObject("sy"))
            l.pvx.fromJson(pr.optJSONObject("pvx")); l.pvy.fromJson(pr.optJSONObject("pvy"))
            l.rrev.fromJson(pr.optJSONObject("rrev")); l.rdeg.fromJson(pr.optJSONObject("rdeg"))
            l.op.fromJson(pr.optJSONObject("op"))
        }
        val fx = o.optJSONArray("fx")
        if (fx != null) for (i in 0 until fx.length()) {
            val fo = fx.getJSONObject(i)
            val type = fo.optString("t")
            if (FX_DEFS.none { it.type == type }) continue
            val e = Fx(type)
            val ps = fo.optJSONArray("ps")
            if (ps != null) {
                for (k in 0 until minOf(ps.length(), e.params.size)) e.params[k].fromJson(ps.optJSONObject(k))
            } else {
                e.params[0].fromJson(fo.optJSONObject("a"))  // v0.2 format: single "amount"
            }
            l.effects.add(e)
        }
        return l
    }

    fun applyJson(c: Comp, o: JSONObject, d: File) {
        val oldBmp = HashMap<Int, Bitmap>()
        val oldThumb = HashMap<Int, Bitmap>()
        val oldMedia = HashMap<Int, Bitmap>()
        c.layers.forEach { l -> l.bmp?.let { oldBmp[l.id] = it }; l.thumb?.let { oldThumb[l.id] = it } }
        c.media.forEach { m -> m.thumb?.let { oldMedia[m.id] = it } }
        c.name = o.optString("name", "Untitled")
        c.cw = o.optInt("cw", 1280)
        c.ch = o.optInt("ch", 720)
        c.dur = o.optDouble("dur", 10.0).toFloat()
        c.fps = o.optInt("fps", 30)
        c.ratio = o.optString("ratio", "16:9")
        c.previewRes = o.optInt("pres", 50)
        c.renderMode = o.optString("mode", "All Layers").let { if (it == "Current Layer") "All Layers" else it }
        c.nextId = o.optInt("next", 1)
        c.nextMediaId = o.optInt("nextMedia", 1)
        c.media.clear()
        val md = o.optJSONArray("media")
        if (md != null) for (i in 0 until md.length()) {
            val mo = md.getJSONObject(i)
            val m = MediaInfo(mo.getInt("id"), mo.optString("kind"), mo.optString("uri"), mo.optString("name"),
                mo.optDouble("dur", 0.0).toFloat(), mo.optInt("w"), mo.optInt("h"))
            m.thumb = oldMedia[m.id] ?: File(d, "${o.optString("pid")}_m${m.id}.jpg").takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path) }
            c.media.add(m)
        }
        c.layers.clear()
        val a = o.optJSONArray("layers")
        if (a != null) for (i in 0 until a.length()) c.layers.add(layerFromJson(a.getJSONObject(i), oldBmp, oldThumb, d))
        for (l in c.layers) if (l.kind == Kind.VIDEO && l.thumb == null) l.thumb = c.media.firstOrNull { it.id == l.mediaId }?.thumb
        c.markers.clear()
        val mk = o.optJSONArray("markers")
        if (mk != null) for (i in 0 until mk.length()) c.markers.add(mk.getDouble(i).toFloat())
    }

    fun save(ctx: Context, id: String, c: Comp, withThumb: Boolean) {
        val d = dir(ctx)
        c.layers.toList().forEach { l ->
            val b = l.bmp
            if (l.kind == Kind.IMAGE && b != null) {
                val fn = "${id}_${l.id}.png"
                val f = File(d, fn)
                if (!f.exists()) f.outputStream().use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
                l.imgFile = fn
            }
        }
        c.media.toList().forEach { m ->
            val th = m.thumb
            val f = File(d, "${id}_m${m.id}.jpg")
            if (th != null && !f.exists()) f.outputStream().use { th.compress(Bitmap.CompressFormat.JPEG, 80, it) }
        }
        File(d, "$id.json").writeText(compToJson(c).put("pid", id).toString())
        if (withThumb) thumb(ctx, id, c)
    }

    private fun thumb(ctx: Context, id: String, c: Comp) {
        try {
            val tw = 360
            val th = (360f * c.ch / c.cw).toInt().coerceAtLeast(1)
            val bmp = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(AColor.BLACK)
            val cv = Canvas(bmp)
            val first = c.layers.firstOrNull { it.kind == Kind.VIDEO && it.uri != null }
            if (first != null) {
                val r = MediaMetadataRetriever()
                try {
                    r.setDataSource(ctx, first.uri)
                    r.getFrameAtTime((first.srcIn * 1_000_000f).toLong())?.let { f ->
                        val k = minOf(tw.toFloat() / f.width, th.toFloat() / f.height)
                        val sw = maxOf(1, (f.width * k).toInt())
                        val sh = maxOf(1, (f.height * k).toInt())
                        cv.drawBitmap(Bitmap.createScaledBitmap(f, sw, sh, true), (tw - sw) / 2f, (th - sh) / 2f, null)
                    }
                } finally {
                    r.release()
                }
            }
            val ov = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888)
            val rd = Renderer()
            try {
                rd.render(c, 0f, ov)
            } finally {
                rd.close()
            }
            cv.drawBitmap(ov, 0f, 0f, null)
            File(dir(ctx), "$id.jpg").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 82, it) }
        } catch (e: Exception) {
        }
    }

    fun load(ctx: Context, id: String): Comp {
        val c = Comp()
        applyJson(c, JSONObject(File(dir(ctx), "$id.json").readText()).put("pid", id), dir(ctx))
        return c
    }

    fun list(ctx: Context): List<ProjInfo> {
        val d = dir(ctx)
        val files = d.listFiles { f -> f.extension == "json" } ?: return emptyList()
        return files.map { f ->
            val id = f.nameWithoutExtension
            var name = "Untitled"
            var ratio = "16:9"
            var height = 720
            var fps = 30
            var dur = 0f
            try {
                val o = JSONObject(f.readText())
                name = o.optString("name", "Untitled")
                ratio = o.optString("ratio", "16:9")
                height = o.optInt("ch", 720)
                fps = o.optInt("fps", 30)
                dur = o.optDouble("dur", 0.0).toFloat()
            } catch (e: Exception) {
            }
            val size = d.listFiles { x -> x.name.startsWith(id) }?.sumOf { it.length() } ?: f.length()
            val th = File(d, "$id.jpg").takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path) }
            ProjInfo(id, name, f.lastModified(), size, th, ratio, height, fps, dur)
        }.sortedByDescending { it.modified }
    }

    fun delete(ctx: Context, id: String) {
        dir(ctx).listFiles { x -> x.name.startsWith(id) }?.forEach { it.delete() }
    }
}
