package com.motion.studio

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color as AColor
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.google.common.collect.ImmutableList
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

fun saveToMovies(ctx: Context, f: File, name: String): Uri {
    val resolver = ctx.contentResolver
    val values = ContentValues().apply {
        put(MediaStore.Video.Media.DISPLAY_NAME, "$name.mp4")
        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
        put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/MotionStudio")
        put(MediaStore.Video.Media.IS_PENDING, 1)
    }
    val out = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
        ?: throw IllegalStateException("Cannot create output file")
    try {
        resolver.openOutputStream(out)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
        values.clear()
        values.put(MediaStore.Video.Media.IS_PENDING, 0)
        resolver.update(out, values, null, null)
    } catch (e: Exception) {
        resolver.delete(out, null, null)
        throw e
    } finally {
        f.delete()
    }
    return out
}

/**
 * Exports the project to MP4 (H.264). Video clips are concatenated with their trims; every frame is
 * composited by the C++ engine (all other layers + effects) through a bitmap overlay on the whole composition.
 */
suspend fun exportComp(ctx: Context, comp: Comp, onProgress: (Float) -> Unit): Uri = withContext(Dispatchers.Main) {
    val cw = comp.cw
    val ch = comp.ch
    val renderer = Renderer()
    try {
        val overlay = object : BitmapOverlay() {
            override fun getBitmap(presentationTimeUs: Long): Bitmap {
                val b = Bitmap.createBitmap(cw, ch, Bitmap.Config.ARGB_8888)
                renderer.render(comp, presentationTimeUs / 1_000_000f, b)
                return b
            }
        }
        val fx = listOf<Effect>(
            Presentation.createForWidthAndHeight(cw, ch, Presentation.LAYOUT_SCALE_TO_FIT),
            OverlayEffect(ImmutableList.of<TextureOverlay>(overlay))
        )
        val clips = comp.layers.filter { it.kind == Kind.VIDEO && it.uri != null }
        val items: List<EditedMediaItem> = if (clips.isNotEmpty()) {
            clips.map { c ->
                val clipping = MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs((c.srcIn * 1000f).toLong())
                    .setEndPositionMs((c.srcOut * 1000f).toLong())
                    .build()
                EditedMediaItem.Builder(MediaItem.Builder().setUri(c.uri!!).setClippingConfiguration(clipping).build()).build()
            }
        } else {
            val bg = File(ctx.cacheDir, "bg.png")
            val bb = Bitmap.createBitmap(cw, ch, Bitmap.Config.ARGB_8888)
            bb.eraseColor(AColor.BLACK)
            bg.outputStream().use { bb.compress(Bitmap.CompressFormat.PNG, 100, it) }
            listOf(
                EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(bg)))
                    .setDurationUs((comp.dur * 1_000_000f).toLong())
                    .setFrameRate(comp.fps)
                    .build()
            )
        }
        val composition = Composition.Builder(listOf(EditedMediaItemSequence(items)))
            .setEffects(Effects(emptyList(), fx))
            .build()
        val out = File(ctx.cacheDir, "out_${System.currentTimeMillis()}.mp4")
        suspendCancellableCoroutine<Unit> { cont ->
            val tr = Transformer.Builder(ctx)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        if (cont.isActive) cont.resume(Unit)
                    }

                    override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                        if (cont.isActive) cont.resumeWithException(exportException)
                    }
                }).build()
            tr.start(composition, out.absolutePath)
            val holder = ProgressHolder()
            val h = Handler(Looper.getMainLooper())
            h.post(object : Runnable {
                override fun run() {
                    if (!cont.isActive) return
                    if (tr.getProgress(holder) != Transformer.PROGRESS_STATE_NOT_STARTED) onProgress(holder.progress / 100f)
                    h.postDelayed(this, 400)
                }
            })
            cont.invokeOnCancellation { tr.cancel() }
        }
        withContext(Dispatchers.IO) { saveToMovies(ctx, out, "Motion_${System.currentTimeMillis()}") }
    } finally {
        renderer.close()
    }
}
