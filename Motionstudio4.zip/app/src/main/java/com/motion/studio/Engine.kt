package com.motion.studio

import android.graphics.Bitmap

/** JNI entry points of the C++ engine (libmotion.so, see src/main/cpp). */
object Engine {
    val ok: Boolean = try {
        System.loadLibrary("motion")
        true
    } catch (e: UnsatisfiedLinkError) {
        false
    }

    @JvmStatic external fun nCreate(): Long
    @JvmStatic external fun nDestroy(h: Long)
    @JvmStatic external fun nSetScene(h: Long, cw: Int, ch: Int, blob: FloatArray, len: Int): Int
    @JvmStatic external fun nRender(h: Long, t: Float, out: Bitmap, tex: Array<Bitmap?>, only: Int): Int
}

/**
 * Encodes the composition (layers, keyframes, effects) and asks the C++ engine to render a frame.
 * Blob layout is documented in jni_bridge.cpp.
 */
class Renderer : AutoCloseable {
    private val h: Long = if (Engine.ok) Engine.nCreate() else 0L
    private var blob = FloatArray(2048)
    private var n = 0

    private fun put(v: Float) {
        if (n == blob.size) blob = blob.copyOf(n * 2)
        blob[n++] = v
    }

    private fun putProp(p: Prop) {
        put(p.base)
        put(if (p.smooth) 1f else 0f)
        put(p.keys.size.toFloat())
        for (k in p.keys) {
            put(k.t)
            put(k.v)
        }
    }

    /** Returns 0 on success. `out` must be a mutable ARGB_8888 bitmap (it is cleared and redrawn). */
    fun render(comp: Comp, t: Float, out: Bitmap, onlyId: Int = -1): Int {
        if (h == 0L) return -100
        n = 0
        val layers = comp.layers.toList()
        put(layers.size.toFloat())
        val tex = arrayOfNulls<Bitmap>(layers.size)
        var only = if (onlyId >= 0) layers.size else -1
        for ((i, l) in layers.withIndex()) {
            if (l.id == onlyId) only = i
            val kind = when (l.kind) {
                Kind.VIDEO -> 0f
                Kind.FILL -> 2f
                else -> 1f
            }
            val (bw, bh) = boxSize(l, comp.cw, comp.ch)
            put(kind)
            put(if (l.visible) 1f else 0f)
            put(l.inT)
            put(l.outT)
            put(bw)
            put(bh)
            put(((l.color shr 16) and 255) / 255f)
            put(((l.color shr 8) and 255) / 255f)
            put((l.color and 255) / 255f)
            put(((l.color ushr 24) and 255) / 255f)
            put(0f)  // blend mode: Normal
            putProp(l.px); putProp(l.py); putProp(l.sx); putProp(l.sy)
            putProp(l.pvx); putProp(l.pvy); putProp(l.rrev); putProp(l.rdeg); putProp(l.op)
            put(l.effects.size.toFloat())
            for (e in l.effects) {
                put(e.def.id.toFloat())
                put(e.params.size.toFloat())
                for (p in e.params) putProp(p)
            }
            tex[i] = if (kind == 1f) ensureRaster(l, comp.cw, comp.ch) else null
        }
        if (Engine.nSetScene(h, comp.cw, comp.ch, blob, n) != 0) return -101
        return Engine.nRender(h, t, out, tex, only)
    }

    override fun close() {
        if (h != 0L) Engine.nDestroy(h)
    }
}
