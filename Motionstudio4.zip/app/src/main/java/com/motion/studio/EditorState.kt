package com.motion.studio

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.SeekParameters
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

/** All editor state + actions (timeline, clips, layers, undo, clipboard, export). */
class EditorState(val ctx: Context, val id: String, val comp: Comp) {
    val player: ExoPlayer = ExoPlayer.Builder(ctx).build().also { it.setSeekParameters(SeekParameters.CLOSEST_SYNC) }
    val renderer = Renderer()
    lateinit var scopeRef: CoroutineScope   // set by EditorScreen (used by menu actions that launch coroutines)

    var t by mutableStateOf(0f)          // UI-rate time (throttled while playing)
    var tDraw by mutableStateOf(0f)      // frame-rate time (read only by draw code)
    var playing by mutableStateOf(false)
    var selId by mutableStateOf(-1)
    var panel by mutableStateOf(if (comp.layers.isEmpty()) "add" else "none")
    var addTab by mutableStateOf("media")
    var fxCat by mutableStateOf("Color")
    var more by mutableStateOf(false)
    var status by mutableStateOf("")
    var exporting by mutableStateOf(false)
    var prog by mutableStateOf(0f)
    var hint by mutableStateOf("")
    var dialog by mutableStateOf("")
    var nameEdit by mutableStateOf("")
    var menuOpen by mutableStateOf(false)
    var tlExpanded by mutableStateOf(true)
    var previewWeight by mutableStateOf(1.25f)
    var clipboard by mutableStateOf<String?>(null)
    private var clipBmp: Bitmap? = null
    private var clipThumb: Bitmap? = null
    private val undoS = ArrayList<String>()
    private val redoS = ArrayList<String>()

    fun sel(): Layer? = comp.layers.firstOrNull { it.id == selId }
    fun videoClips(): List<Layer> = comp.layers.filter { it.kind == Kind.VIDEO && it.uri != null }
    fun playlistSig(): String = videoClips().joinToString("|") { "${it.uri}@${it.srcIn}-${it.srcOut}" }
    fun dur(): Float = maxOf(comp.dur, 0.1f)
    fun togglePanel(p: String) { panel = if (panel == p) "none" else p }

    // ---------------- undo / redo ----------------
    fun snap() {
        undoS.add(Store.compToJson(comp).toString())
        if (undoS.size > 40) undoS.removeAt(0)
        redoS.clear()
    }

    private fun restore(js: String) {
        Store.applyJson(comp, JSONObject(js), Store.dir(ctx))
    }

    fun undo() {
        if (undoS.isEmpty()) return
        redoS.add(Store.compToJson(comp).toString())
        restore(undoS.removeAt(undoS.size - 1))
    }

    fun redo() {
        if (redoS.isEmpty()) return
        undoS.add(Store.compToJson(comp).toString())
        restore(redoS.removeAt(redoS.size - 1))
    }

    // ---------------- time / playback ----------------
    fun seek(v: Float) {
        t = v.coerceIn(0f, dur())
        tDraw = t
        playing = false
        seekPlayer(t)
    }

    fun seekPlayer(time: Float) {
        val clips = videoClips()
        if (clips.isEmpty() || player.mediaItemCount != clips.size) return
        var idx = clips.indexOfLast { time >= it.inT }
        if (idx < 0) idx = 0
        val c = clips[idx]
        val maxPos = maxOf(0L, ((c.srcOut - c.srcIn) * 1000f).toLong() - 30L)
        player.seekTo(idx, ((time - c.inT) * 1000f).toLong().coerceIn(0L, maxPos))
    }

    private fun marks(): List<Float> {
        val out = ArrayList<Float>()
        val s = sel()
        if (s != null) {
            out.add(s.inT)
            out.add(s.outT)
            s.allProps().forEach { p -> p.keys.forEach { out.add(it.t) } }
        } else {
            out.add(0f)
            videoClips().forEach { out.add(it.outT) }
            out.addAll(comp.markers)
        }
        return out
    }

    fun jumpPrev() { seek(marks().filter { it < t - 0.05f }.maxOrNull() ?: 0f) }
    fun jumpNext() { seek(marks().filter { it > t + 0.05f }.minOrNull() ?: dur()) }

    fun togglePlay() {
        if (!playing && t >= comp.dur - 0.05f) { t = 0f; tDraw = 0f }
        playing = !playing
    }

    fun toggleMarker() {
        val i = comp.markers.indexOfFirst { kotlin.math.abs(it - t) < 0.1f }
        if (i >= 0) comp.markers.removeAt(i) else comp.markers.add(t)
    }

    // ---------------- keyframes ----------------
    fun setP(p: Prop, v: Float) { if (p.keys.isNotEmpty()) p.setKey(t, v) else p.base = v }

    fun toggleAnim(vararg ps: Prop) {
        snap()
        val anim = ps.any { it.keys.isNotEmpty() }
        ps.forEach { p -> if (anim) { p.base = p.at(t); p.keys.clear() } else p.setKey(t, p.base) }
    }

    fun toggleEase(vararg ps: Prop) {
        val n = !ps.first().smooth
        ps.forEach { it.smooth = n }
        status = if (n) "Easing: Smooth" else "Easing: Linear"
    }

    // ---------------- layers ----------------
    fun addLayer(kind: Kind, bmp: Bitmap? = null, shape: String = ""): Layer {
        snap()
        val l = Layer(comp.nextId++, kind)
        l.outT = comp.dur
        l.name = when (kind) {
            Kind.TEXT -> "Text"
            Kind.RECT -> "Shape"
            Kind.ELLIPSE -> "Circle"
            Kind.FILL -> "Solid"
            Kind.IMAGE -> "Image"
            Kind.VIDEO -> "Video"
        }
        if (kind == Kind.RECT || kind == Kind.ELLIPSE) l.color = 0xFF2DE0C2.toInt()
        if (kind == Kind.FILL) l.color = 0xFF8B5CF6.toInt()
        if (kind == Kind.TEXT) l.h = 120f
        l.shape = shape
        l.bmp = bmp
        comp.layers.add(l)
        selId = l.id
        return l
    }

    fun addShape(name: String) {
        val l = when (name) {
            "circle" -> addLayer(Kind.ELLIPSE, shape = "circle").also { it.w = 300f; it.h = 300f }
            "square" -> addLayer(Kind.RECT, shape = "square").also { it.w = 300f; it.h = 300f }
            "rounded" -> addLayer(Kind.RECT, shape = "rounded").also { it.w = 340f; it.h = 340f }
            "triangle" -> addLayer(Kind.RECT, shape = "triangle").also { it.w = 320f; it.h = 300f }
            "diamond" -> addLayer(Kind.RECT, shape = "diamond").also { it.w = 320f; it.h = 320f }
            else -> addLayer(Kind.RECT, shape = "rect").also { it.w = 480f; it.h = 270f }
        }
        l.name = name.replaceFirstChar { it.uppercase() }
    }

    fun importMedia(uris: List<Uri>, scope: CoroutineScope) {
        scope.launch {
            val list = withContext(Dispatchers.IO) {
                uris.mapNotNull { u ->
                    try {
                        persistUri(ctx, u)
                        makeMedia(ctx, comp, u)
                    } catch (e: Exception) {
                        null
                    }
                }
            }
            list.forEach { comp.media.add(it) }
            status = if (list.isEmpty()) "Unsupported file" else "Imported ${list.size} file(s)"
        }
    }

    fun addMedia(m: MediaInfo) {
        try {
            if (m.kind == "video") {
                snap()
                val l = addClipLayer(comp, m)
                selId = l.id
                seek(l.inT)
            } else {
                val b = decodeImage(ctx, Uri.parse(m.uri))
                if (b == null) { status = "Cannot open image"; return }
                addLayer(Kind.IMAGE, b).name = m.name.take(18)
            }
        } catch (e: Exception) {
            status = "Cannot add media: ${e.message}"
        }
    }

    fun trimStart(c: Layer, d: Float) {
        c.srcIn = (c.srcIn + d).coerceIn(0f, c.srcOut - 0.2f)
        relayoutVideo(comp)
    }

    fun trimEnd(c: Layer, d: Float) {
        c.srcOut = (c.srcOut + d).coerceIn(c.srcIn + 0.2f, maxOf(c.srcDur, c.srcIn + 0.2f))
        relayoutVideo(comp)
    }

    fun trimLayerIn(l: Layer, d: Float) { l.inT = (l.inT + d).coerceIn(0f, l.outT - 0.1f) }
    fun trimLayerOut(l: Layer, d: Float) { l.outT = (l.outT + d).coerceIn(l.inT + 0.1f, maxOf(comp.dur, l.inT + 0.1f)) }

    fun deleteSelected() {
        val l = sel() ?: return
        snap()
        comp.layers.remove(l)
        selId = -1
        if (l.kind == Kind.VIDEO) relayoutVideo(comp)
        seek(minOf(t, dur()))
    }

    fun moveSelected(up: Boolean) {
        val l = sel() ?: return
        snap()
        val i = comp.layers.indexOf(l)
        if (up && i < comp.layers.size - 1) { comp.layers.removeAt(i); comp.layers.add(i + 1, l) }
        if (!up && i > 0) { comp.layers.removeAt(i); comp.layers.add(i - 1, l) }
        relayoutVideo(comp)
    }

    private fun cloneLayer(l: Layer, js: JSONObject, bmp: Bitmap?, thumb: Bitmap?): Layer {
        val nid = comp.nextId++
        js.put("id", nid)
        val bm = HashMap<Int, Bitmap>()
        bmp?.let { bm[nid] = it }
        val th = HashMap<Int, Bitmap>()
        thumb?.let { th[nid] = it }
        return Store.layerFromJson(js, bm, th, Store.dir(ctx))
    }

    fun duplicateSelected() {
        val l = sel() ?: return
        snap()
        val nl = cloneLayer(l, Store.layerToJson(l), l.bmp, l.thumb)
        nl.name = l.name + " 2"
        comp.layers.add(comp.layers.indexOf(l) + 1, nl)
        selId = nl.id
        if (l.kind == Kind.VIDEO) relayoutVideo(comp)
    }

    fun copySelected() {
        val l = sel() ?: return
        clipboard = Store.layerToJson(l).toString()
        clipBmp = l.bmp
        clipThumb = l.thumb
        status = "Layer copied"
    }

    fun pasteLayer() {
        val js = clipboard ?: return
        snap()
        val o = JSONObject(js)
        val nl = cloneLayer(Layer(0, Kind.FILL), o, clipBmp, clipThumb)
        nl.name = nl.name + " 2"
        if (nl.kind == Kind.VIDEO) comp.layers.add(comp.layers.indexOfLast { it.kind == Kind.VIDEO } + 1, nl) else comp.layers.add(nl)
        selId = nl.id
        if (nl.kind == Kind.VIDEO) relayoutVideo(comp)
    }

    /** Copies transform + effects (the "style") of the copied layer onto the selected one. */
    fun pasteStyle() {
        val js = clipboard ?: return
        val dst = sel() ?: return
        snap()
        val src = Store.layerFromJson(JSONObject(js).put("id", -1), emptyMap(), emptyMap(), Store.dir(ctx))
        val a = src.transformProps()
        val b = dst.transformProps()
        for (i in a.indices) b[i].fromJson(a[i].toJson())
        dst.color = src.color
        dst.effects.clear()
        src.effects.forEach { e ->
            val ne = Fx(e.type)
            for (i in e.params.indices) ne.params[i].fromJson(e.params[i].toJson())
            dst.effects.add(ne)
        }
        status = "Style pasted"
    }

    fun replaceMedia(u: Uri) {
        val l = sel() ?: return
        try {
            persistUri(ctx, u)
            snap()
            if (l.kind == Kind.IMAGE) {
                l.bmp = decodeImage(ctx, u)
                l.rasterSig = ""
            } else if (l.kind == Kind.VIDEO) {
                val m = makeMedia(ctx, comp, u)
                if (m == null || m.kind != "video") { status = "Pick a video file"; return }
                comp.media.add(m)
                l.uri = Uri.parse(m.uri)
                l.srcIn = 0f
                l.srcOut = m.dur
                l.srcDur = m.dur
                l.vw = m.w
                l.vh = m.h
                l.mediaId = m.id
                l.thumb = m.thumb
                relayoutVideo(comp)
            }
        } catch (e: Exception) {
            status = "Replace failed: ${e.message}"
        }
    }

    // ---------------- effects ----------------
    fun addEffect(def: FxDef) {
        val l = sel()
        if (l == null) { status = "Select a layer first"; return }
        if (l.kind == Kind.VIDEO) { status = "Effects apply to image, text, shape and solid layers"; return }
        snap()
        l.effects.add(Fx(def.type))
        panel = "fx"
    }

    fun setRatio(r: String) {
        if (videoClips().isNotEmpty()) { status = "Ratio follows the video"; return }
        snap()
        comp.ratio = r
        when (r) {
            "16:9" -> { comp.cw = 1280; comp.ch = 720 }
            "9:16" -> { comp.cw = 720; comp.ch = 1280 }
            "1:1" -> { comp.cw = 1024; comp.ch = 1024 }
            "4:3" -> { comp.cw = 1280; comp.ch = 960 }
            "21:9" -> { comp.cw = 1280; comp.ch = 544 }
        }
    }

    // ---------------- persistence / export ----------------
    fun persist() {
        try {
            Store.save(ctx, id, comp, true)
        } catch (e: Exception) {
        }
    }

    fun exportNow(scope: CoroutineScope) {
        if (exporting) return
        exporting = true
        prog = 0f
        status = "Exporting..."
        scope.launch {
            try {
                exportComp(ctx, comp) { prog = it }
                status = "Saved to Movies/MotionStudio"
            } catch (e: Exception) {
                status = "Export failed: ${e.message}"
            }
            exporting = false
        }
    }

    /** Old projects (v0.2) have video layers without thumbnails: build them lazily. */
    suspend fun loadMissingThumbs() {
        withContext(Dispatchers.IO) {
            for (l in comp.layers.toList()) {
                if (l.kind != Kind.VIDEO || l.thumb != null) continue
                val u = l.uri ?: continue
                val r = MediaMetadataRetriever()
                try {
                    r.setDataSource(ctx, u)
                    r.getFrameAtTime((l.srcIn * 1_000_000f).toLong())?.let { f ->
                        val k = 256f / maxOf(f.width, f.height)
                        l.thumb = Bitmap.createScaledBitmap(f, maxOf(1, (f.width * k).toInt()), maxOf(1, (f.height * k).toInt()), true)
                    }
                } catch (e: Exception) {
                } finally {
                    r.release()
                }
            }
        }
    }

    fun release() {
        try { player.release() } catch (e: Exception) {}
        renderer.close()
    }
}
