package com.motion.studio

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.matchParentSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.UUID

fun tcShort(s: Float): String {
    val t = s.toInt()
    return "%02d:%02d:%02d".format(t / 3600, (t / 60) % 60, t % 60)
}

@Composable
fun HomeScreen(onOpen: (String, Comp) -> Unit) {
    val ctx = LocalContext.current
    var items by remember { mutableStateOf(Store.list(ctx)) }
    var seeAll by remember { mutableStateOf(false) }
    var delId by remember { mutableStateOf("") }
    val scroll = rememberScrollState()

    fun create(u: Uri?) {
        val c = Comp()
        try {
            if (u != null) {
                persistUri(ctx, u)
                val m = makeMedia(ctx, c, u)
                if (m != null) {
                    c.media.add(m)
                    if (m.kind == "video") {
                        addClipLayer(c, m)
                    } else {
                        val b = decodeImage(ctx, u)
                        if (b != null) {
                            val l = Layer(c.nextId++, Kind.IMAGE)
                            l.name = "Image"
                            l.bmp = b
                            l.outT = c.dur
                            c.layers.add(l)
                        }
                    }
                }
            }
        } catch (e: Exception) {
        }
        val id = UUID.randomUUID().toString().replace("-", "").take(12)
        Store.save(ctx, id, c, true)
        onOpen(id, c)
    }
    val pickVideo = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) create(u) }
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) create(u) }

    Box(Modifier.fillMaxSize().cosmic()) {
        Stars(Modifier.fillMaxSize())
        Column(Modifier.fillMaxSize().verticalScroll(scroll).padding(horizontal = 18.dp)) {
            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Canvas(Modifier.size(44.dp)) {
                    drawCircle(GoldC, size.width * 0.34f, Offset(size.width * 0.45f, size.height * 0.5f))
                    drawCircle(Navy, size.width * 0.30f, Offset(size.width * 0.56f, size.height * 0.44f))
                    drawCircle(GoldC, size.width * 0.05f, Offset(size.width * 0.78f, size.height * 0.28f))
                }
                Spacer(Modifier.width(10.dp))
                Text("Motion Studio", color = GoldC, fontSize = 27.sp, fontFamily = FontFamily.Serif, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(16.dp))
            // hero card
            val heroShape = RoundedCornerShape(22.dp)
            Box(Modifier.fillMaxWidth().height(206.dp).clip(heroShape).border(1.dp, GoldDim.copy(alpha = 0.45f), heroShape)) {
                Canvas(Modifier.matchParentSize()) {
                    drawRect(Brush.horizontalGradient(listOf(Color(0xFF0A1030), Color(0xFF111A46))))
                    val c = Offset(size.width * 0.8f, size.height * 0.5f)
                    drawCircle(Brush.radialGradient(listOf(Color(0xCCE6D3B3), Color(0x558B7BC8), Color.Transparent), c, size.height * 0.85f), size.height * 0.85f, c)
                    for (i in 0..5) {
                        drawArc(
                            Color(0x33FFFFFF), 20f * i, 210f, false,
                            Offset(size.width * 0.52f - i * 16f, size.height * 0.18f - i * 9f),
                            Size(size.width * 0.5f + i * 32f, size.height * 0.64f + i * 18f), style = Stroke(2f)
                        )
                    }
                }
                Column(Modifier.padding(18.dp)) {
                    Text("WELCOME", color = GoldDim, fontSize = 12.sp, letterSpacing = 2.sp)
                    Spacer(Modifier.height(6.dp))
                    Text("CRAFT YOUR\nCOSMIC CINEMA.", color = GoldC, fontSize = 25.sp, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, lineHeight = 29.sp)
                    Spacer(Modifier.height(4.dp))
                    Text("Where imagination knows no bounds.", color = GoldC.copy(alpha = 0.85f), fontSize = 13.sp)
                    Spacer(Modifier.height(14.dp))
                    val pill = RoundedCornerShape(50)
                    Row(
                        Modifier.clip(pill).border(1.5.dp, Brush.horizontalGradient(listOf(GoldC, GoldDim)), pill)
                            .background(Color(0x33E6D3B3)).tap { create(null) }.padding(horizontal = 18.dp, vertical = 11.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Ico("plus", 18.dp, GoldC)
                        Spacer(Modifier.width(8.dp))
                        Text("Begin New Odyssey", color = TxtHi, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
            Text("Quick Access", color = GoldC, fontSize = 22.sp, fontFamily = FontFamily.Serif, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(14.dp)) {
                QuickCard(Modifier.weight(1f), "video", "Import Video", "Start a project from a clip") { pickVideo.launch(arrayOf("video/*")) }
                QuickCard(Modifier.weight(1f), "media", "Import Image", "Start a project from a picture") { pickImage.launch(arrayOf("image/*")) }
            }
            Spacer(Modifier.height(26.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Your masterpieces", Modifier.weight(1f), color = GoldC, fontSize = 22.sp, fontFamily = FontFamily.Serif, fontWeight = FontWeight.SemiBold)
                Row(Modifier.tap { seeAll = !seeAll }.padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(if (seeAll) "Show less" else "See all", color = TxtLo, fontSize = 14.sp)
                    Spacer(Modifier.width(4.dp))
                    Ico(if (seeAll) "chevD" else "chevR", 14.dp, TxtLo)
                }
            }
            Spacer(Modifier.height(10.dp))
            if (items.isEmpty()) {
                Text("No projects yet. Tap + to begin.", color = TxtLo, fontSize = 14.sp, modifier = Modifier.padding(vertical = 18.dp))
            } else if (!seeAll) {
                LazyRow(horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(14.dp)) {
                    items(items) { p -> ProjectCard(p, Modifier.width(236.dp), { onOpen(p.id, Store.load(ctx, p.id)) }) { delId = p.id } }
                }
            } else {
                Column(verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(14.dp)) {
                    items.forEach { p -> ProjectCard(p, Modifier.fillMaxWidth(), { onOpen(p.id, Store.load(ctx, p.id)) }) { delId = p.id } }
                }
            }
            Spacer(Modifier.height(120.dp))
        }
        // bottom navigation + floating "+" button
        Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(92.dp)) {
            Row(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(68.dp)
                    .background(Brush.verticalGradient(listOf(Color(0xEE111633), Color(0xFF080B22)))).padding(horizontal = 36.dp),
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
            ) {
                HomeNav("home", "Home", !seeAll) { seeAll = false }
                Spacer(Modifier.width(80.dp))
                HomeNav("folder", "Projects", seeAll) { seeAll = true }
            }
            Box(
                Modifier.align(Alignment.TopCenter).size(70.dp).clip(CircleShape)
                    .background(Brush.radialGradient(listOf(Color(0xFFF3E6C8), Color(0xFFC9AE78)))).tap { create(null) },
                contentAlignment = Alignment.Center
            ) { Ico("plus", 30.dp, Color(0xFF1A1A2E)) }
        }
    }
    if (delId.isNotEmpty()) {
        AlertDialog(
            onDismissRequest = { delId = "" },
            containerColor = Color(0xFF1B2150),
            title = { Text("Delete project?", color = TxtHi) },
            text = { Text("This cannot be undone.", color = TxtLo) },
            confirmButton = {
                TextButton(onClick = { Store.delete(ctx, delId); items = Store.list(ctx); delId = "" }) { Text("Delete", color = PinkC) }
            },
            dismissButton = { TextButton(onClick = { delId = "" }) { Text("Cancel", color = TxtLo) } }
        )
    }
}

@Composable
fun QuickCard(modifier: Modifier, icon: String, title: String, sub: String, onClick: () -> Unit) {
    val s = RoundedCornerShape(20.dp)
    Column(
        modifier.height(150.dp).clip(s).border(1.dp, LineC, s)
            .background(Brush.verticalGradient(listOf(Color(0xFF131A40), Color(0xFF0C1030)))).tap(onClick = onClick).padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Ico(icon, 34.dp, GoldC)
            Spacer(Modifier.width(10.dp))
            Text(title, color = TxtHi, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(10.dp))
        Text(sub, color = TxtLo, fontSize = 13.sp, lineHeight = 17.sp)
        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = androidx.compose.foundation.layout.Arrangement.End) { Ico("chevR", 18.dp, TxtLo) }
    }
}

@Composable
fun ProjectCard(p: ProjInfo, modifier: Modifier, onClick: () -> Unit, onLong: () -> Unit) {
    val s = RoundedCornerShape(18.dp)
    Column(
        modifier.clip(s).border(1.dp, LineC, s).background(Color(0xFF0F1438))
            .pointerInput(p.id) { detectTapGestures(onTap = { onClick() }, onLongPress = { onLong() }) }
    ) {
        Box(Modifier.fillMaxWidth().height(138.dp).background(Color.Black)) {
            val th: Bitmap? = p.thumb
            if (th != null) Image(th.asImageBitmap(), null, Modifier.matchParentSize(), contentScale = ContentScale.Crop)
            Box(
                Modifier.align(Alignment.BottomStart).padding(10.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xCC0A0D24))
                    .padding(horizontal = 10.dp, vertical = 5.dp)
            ) { Text(tcShort(p.dur), color = TxtHi, fontSize = 14.sp) }
        }
        Column(Modifier.padding(12.dp)) {
            Text(p.name, color = TxtHi, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Spacer(Modifier.height(2.dp))
            Text("${p.ratio} • ${p.height}p • ${p.fps}fps • ${"%.0f".format(p.size / 1_048_576f)} MB", color = TxtLo, fontSize = 13.sp, maxLines = 1)
        }
    }
}

@Composable
fun HomeNav(icon: String, label: String, active: Boolean, onClick: () -> Unit) {
    Column(Modifier.tap(onClick = onClick).padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Ico(icon, 26.dp, if (active) GoldC else TxtLo)
        Spacer(Modifier.height(3.dp))
        Text(label, color = if (active) GoldC else TxtLo, fontSize = 13.sp)
    }
}
