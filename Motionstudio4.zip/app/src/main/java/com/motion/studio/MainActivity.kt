package com.motion.studio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = TealC, onPrimary = Ink, background = Ink, onBackground = TxtHi,
                    surface = PanelC, onSurface = TxtHi, surfaceVariant = Navy, outline = LineC
                )
            ) {
                Surface(Modifier.fillMaxSize(), color = Ink) { App() }
            }
        }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    var open by remember { mutableStateOf<Pair<String, Comp>?>(null) }
    // smooth fade between the Home screen and the editor
    Crossfade(targetState = open, animationSpec = tween(260), label = "root") { o ->
        if (o == null) {
            HomeScreen { id, c -> open = id to c }
        } else {
            val st = remember(o.first) { EditorState(ctx, o.first, o.second) }
            DisposableEffect(st) { onDispose { st.release() } }
            EditorScreen(st) { open = null }
        }
    }
}
