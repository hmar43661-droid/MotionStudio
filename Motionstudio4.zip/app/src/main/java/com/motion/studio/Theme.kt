package com.motion.studio

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

// ---- Motion Studio visual identity (deep navy, teal accent, coral playhead, gold headings) ----
val Ink = Color(0xFF060814)
val Navy = Color(0xFF0C1030)
val PanelC = Color(0xFF141A40)
val TealC = Color(0xFF2DE0C2)
val PinkC = Color(0xFFF2677A)
val VioletC = Color(0xFF8B5CF6)
val GoldC = Color(0xFFE6D3B3)
val GoldDim = Color(0xFFB59A6A)
val TxtHi = Color(0xFFEAEEFF)
val TxtLo = Color(0xFF8E98C4)
val LineC = Color(0x26FFFFFF)

fun Modifier.cosmic(): Modifier = this.background(Brush.verticalGradient(listOf(Ink, Navy)))

fun Modifier.glass(radius: Dp = 18.dp): Modifier {
    val s = RoundedCornerShape(radius)
    return this.clip(s)
        .background(Brush.verticalGradient(listOf(Color(0xE61C2252), Color(0xE6121744))))
        .border(1.dp, LineC, s)
}

/** Click with a soft press animation (scale) - used by every button for a responsive feel. */
fun Modifier.tap(enabled: Boolean = true, onClick: () -> Unit): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pressed) 0.94f else 1f, tween(90), label = "tap")
    this.graphicsLayer { scaleX = sc; scaleY = sc }
        .clickable(interactionSource = src, indication = null, enabled = enabled, onClick = onClick)
}

@Composable
fun Stars(modifier: Modifier = Modifier) {
    val pts = remember {
        val r = java.util.Random(11)
        List(70) { Triple(r.nextFloat(), r.nextFloat(), 0.4f + r.nextFloat() * 1.4f) }
    }
    Canvas(modifier) {
        pts.forEach { (x, y, s) ->
            drawCircle(Color.White.copy(alpha = 0.15f + 0.35f * (s / 1.8f)), s * density, Offset(x * size.width, y * size.height))
        }
    }
}

@Composable
fun IcoBtn(kind: String, sz: Dp = 44.dp, color: Color = TxtHi, enabled: Boolean = true, onClick: () -> Unit) {
    Box(Modifier.size(sz).tap(enabled, onClick), contentAlignment = Alignment.Center) {
        Ico(kind, sz * 0.52f, if (enabled) color else TxtLo.copy(alpha = 0.4f))
    }
}

/** Outline icon set drawn with Canvas (no font glyphs, so it looks identical on every phone). */
@Composable
fun Ico(kind: String, sz: Dp = 22.dp, color: Color = TxtHi) {
    Canvas(Modifier.size(sz)) {
        val w = size.width
        val h = size.height
        val sw = w * 0.085f
        val st = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round)
        fun ln(x1: Float, y1: Float, x2: Float, y2: Float) =
            drawLine(color, Offset(w * x1, h * y1), Offset(w * x2, h * y2), sw, StrokeCap.Round)
        fun rr(x: Float, y: Float, rw: Float, rh: Float, r: Float) =
            drawRoundRect(color, Offset(w * x, h * y), Size(w * rw, h * rh), CornerRadius(w * r), style = st)
        fun undoShape() {
            drawArc(color, 200f, 240f, false, Offset(w * .2f, h * .3f), Size(w * .62f, h * .52f), style = st)
            ln(.2f, .46f, .2f, .22f)
            ln(.2f, .46f, .44f, .42f)
        }
        when (kind) {
            "undo" -> undoShape()
            "redo" -> scale(-1f, 1f, Offset(w / 2f, h / 2f)) { undoShape() }
            "prev" -> {
                drawRect(color, Offset(w * .16f, h * .2f), Size(w * .1f, h * .6f))
                drawPath(Path().apply { moveTo(w * .86f, h * .2f); lineTo(w * .34f, h * .5f); lineTo(w * .86f, h * .8f); close() }, color)
            }
            "next" -> {
                drawRect(color, Offset(w * .74f, h * .2f), Size(w * .1f, h * .6f))
                drawPath(Path().apply { moveTo(w * .14f, h * .2f); lineTo(w * .66f, h * .5f); lineTo(w * .14f, h * .8f); close() }, color)
            }
            "play" -> drawPath(Path().apply { moveTo(w * .26f, h * .14f); lineTo(w * .86f, h * .5f); lineTo(w * .26f, h * .86f); close() }, color)
            "pause" -> {
                drawRoundRect(color, Offset(w * .22f, h * .16f), Size(w * .2f, h * .68f), CornerRadius(w * .05f))
                drawRoundRect(color, Offset(w * .58f, h * .16f), Size(w * .2f, h * .68f), CornerRadius(w * .05f))
            }
            "plus" -> { ln(.5f, .16f, .5f, .84f); ln(.16f, .5f, .84f, .5f) }
            "close" -> { ln(.22f, .22f, .78f, .78f); ln(.78f, .22f, .22f, .78f) }
            "dots" -> { for (i in 0..2) drawCircle(color, w * .07f, Offset(w * .5f, h * (.22f + .28f * i))) }
            "spark" -> {
                drawPath(Path().apply {
                    moveTo(w * .42f, h * .1f); lineTo(w * .52f, h * .38f); lineTo(w * .8f, h * .48f)
                    lineTo(w * .52f, h * .58f); lineTo(w * .42f, h * .86f); lineTo(w * .32f, h * .58f)
                    lineTo(w * .04f, h * .48f); lineTo(w * .32f, h * .38f); close()
                }, color, style = st)
                ln(.82f, .12f, .82f, .3f); ln(.73f, .21f, .91f, .21f)
            }
            "sliders" -> {
                ln(.12f, .25f, .88f, .25f); ln(.12f, .5f, .88f, .5f); ln(.12f, .75f, .88f, .75f)
                drawCircle(color, w * .09f, Offset(w * .35f, h * .25f)); drawCircle(color, w * .09f, Offset(w * .65f, h * .5f))
                drawCircle(color, w * .09f, Offset(w * .4f, h * .75f))
            }
            "layers" -> {
                drawPath(Path().apply { moveTo(w * .5f, h * .14f); lineTo(w * .9f, h * .36f); lineTo(w * .5f, h * .58f); lineTo(w * .1f, h * .36f); close() }, color, style = st)
                ln(.1f, .54f, .5f, .76f); ln(.5f, .76f, .9f, .54f); ln(.1f, .72f, .5f, .94f); ln(.5f, .94f, .9f, .72f)
            }
            "export" -> {
                ln(.5f, .62f, .5f, .12f); ln(.3f, .3f, .5f, .1f); ln(.7f, .3f, .5f, .1f)
                ln(.16f, .56f, .16f, .88f); ln(.16f, .88f, .84f, .88f); ln(.84f, .88f, .84f, .56f)
            }
            "media" -> {
                rr(.1f, .16f, .8f, .68f, .1f)
                drawCircle(color, w * .07f, Offset(w * .32f, h * .36f))
                ln(.14f, .76f, .42f, .52f); ln(.42f, .52f, .6f, .68f); ln(.6f, .68f, .72f, .58f); ln(.72f, .58f, .86f, .72f)
            }
            "video" -> {
                rr(.08f, .22f, .62f, .56f, .08f)
                drawPath(Path().apply { moveTo(w * .74f, h * .42f); lineTo(w * .94f, h * .3f); lineTo(w * .94f, h * .7f); lineTo(w * .74f, h * .58f); close() }, color, style = st)
            }
            "shape" -> {
                drawPath(Path().apply { moveTo(w * .3f, h * .1f); lineTo(w * .52f, h * .5f); lineTo(w * .08f, h * .5f); close() }, color, style = st)
                drawCircle(color, w * .2f, Offset(w * .68f, h * .66f), style = st)
            }
            "element" -> {
                drawCircle(color, w * .16f, Offset(w * .5f, h * .5f), style = st)
                for (i in 0..7) {
                    val a = Math.toRadians(i * 45.0)
                    val c = Math.cos(a).toFloat()
                    val s = Math.sin(a).toFloat()
                    ln(.5f + .26f * c, .5f + .26f * s, .5f + .4f * c, .5f + .4f * s)
                }
            }
            "text" -> { ln(.2f, .24f, .8f, .24f); ln(.5f, .24f, .5f, .84f); ln(.38f, .84f, .62f, .84f) }
            "home" -> {
                ln(.1f, .5f, .5f, .14f); ln(.5f, .14f, .9f, .5f)
                ln(.22f, .44f, .22f, .86f); ln(.22f, .86f, .78f, .86f); ln(.78f, .86f, .78f, .44f)
            }
            "folder" -> {
                ln(.1f, .24f, .4f, .24f); ln(.4f, .24f, .5f, .34f); ln(.5f, .34f, .9f, .34f)
                ln(.9f, .34f, .9f, .8f); ln(.9f, .8f, .1f, .8f); ln(.1f, .8f, .1f, .24f)
            }
            "eye" -> { drawOval(color, Offset(w * .08f, h * .26f), Size(w * .84f, h * .48f), style = st); drawCircle(color, w * .13f, Offset(w * .5f, h * .5f)) }
            "eyeoff" -> {
                drawOval(color, Offset(w * .08f, h * .26f), Size(w * .84f, h * .48f), style = st)
                ln(.14f, .86f, .86f, .14f)
            }
            "trash" -> {
                ln(.16f, .26f, .84f, .26f); ln(.38f, .26f, .38f, .14f); ln(.38f, .14f, .62f, .14f); ln(.62f, .14f, .62f, .26f)
                ln(.24f, .26f, .3f, .88f); ln(.3f, .88f, .7f, .88f); ln(.7f, .88f, .76f, .26f)
            }
            "copy" -> { rr(.3f, .3f, .56f, .58f, .06f); rr(.14f, .12f, .56f, .58f, .06f) }
            "paste" -> { rr(.2f, .2f, .6f, .72f, .06f); rr(.36f, .08f, .28f, .2f, .05f) }
            "replace" -> {
                ln(.16f, .36f, .84f, .36f); ln(.66f, .2f, .84f, .36f); ln(.66f, .52f, .84f, .36f)
                ln(.84f, .66f, .16f, .66f); ln(.34f, .5f, .16f, .66f); ln(.34f, .82f, .16f, .66f)
            }
            "up" -> { ln(.5f, .84f, .5f, .2f); ln(.26f, .44f, .5f, .2f); ln(.74f, .44f, .5f, .2f) }
            "down" -> { ln(.5f, .16f, .5f, .8f); ln(.26f, .56f, .5f, .8f); ln(.74f, .56f, .5f, .8f) }
            "chevL" -> { ln(.64f, .16f, .34f, .5f); ln(.34f, .5f, .64f, .84f) }
            "chevR" -> { ln(.36f, .16f, .66f, .5f); ln(.66f, .5f, .36f, .84f) }
            "chevD" -> { ln(.16f, .36f, .5f, .66f); ln(.5f, .66f, .84f, .36f) }
            "flag" -> {
                ln(.22f, .12f, .22f, .9f)
                drawPath(Path().apply { moveTo(w * .22f, h * .16f); lineTo(w * .82f, h * .16f); lineTo(w * .66f, h * .38f); lineTo(w * .82f, h * .6f); lineTo(w * .22f, h * .6f); close() }, color)
            }
            "watch" -> {
                val r = w * .34f
                val c = Offset(w / 2f, h * .58f)
                drawCircle(color, r, c, style = st)
                drawRect(color, Offset(w * .4f, h * .06f), Size(w * .2f, h * .1f))
                ln(.5f, .58f, .5f, .38f); ln(.5f, .58f, .64f, .58f)
            }
            "check" -> { ln(.2f, .52f, .42f, .74f); ln(.42f, .74f, .82f, .26f) }
        }
    }
}
