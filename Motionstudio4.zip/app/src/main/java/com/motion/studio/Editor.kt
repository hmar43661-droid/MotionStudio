package com.motion.studio

import android.graphics.Bitmap
import android.graphics.Paint
import android.graphics.RectF
import android.view.SurfaceView
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.matchParentSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.abs

// ===================== small shared controls =====================

@Composable
fun ValueField(v: Float, fmt: String, step: Float, name: String, onHint: (String) -> Unit, onStart: () -> Unit, onChange: (Float) -> Unit) {
    var edit by remember { mutableStateOf(false) }
    val cur by rememberUpdatedState(v)
    val onS by rememberUpdatedState(onStart)
    val onC by rememberUpdatedState(onChange)
    val onH by rememberUpdatedState(onHint)
    Box(
        Modifier.padding(horizontal = 3.dp).clip(RoundedCornerShape(9.dp)).background(Color(0xFF1B2150))
            .pointerInput(step) {
                var acc = 0f
                detectHorizontalDragGestures(onDragStart = { acc = cur; onS() }) { change, dx ->
                    change.consume()
                    acc += dx * step
                    onC(acc)
                    onH("$name: ${fmt.format(acc)}")
                }
            }
            .tap { edit = true }.padding(horizontal = 10.dp, vertical = 6.dp)
    ) { Text(fmt.format(v), color = TealC, fontSize = 14.sp) }
    if (edit) {
        var txt by remember { mutableStateOf(fmt.format(v)) }
        AlertDialog(
            onDismissRequest = { edit = false },
            containerColor = Color(0xFF1B2150),
            confirmButton = {
                TextButton(onClick = { onStart(); txt.toFloatOrNull()?.let { onChange(it) }; edit = false }) { Text("OK", color = TealC) }
            },
            dismissButton = { TextButton(onClick = { edit = false }) { Text("Cancel", color = TxtLo) } },
            title = { Text(name, color = TxtHi) },
            text = {
                OutlinedTextField(
                    value = txt, onValueChange = { txt = it }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
            }
        )
    }
}

@Composable
fun TRow(
    label: String, names: List<String>, vals: List<Float>, fmts: List<String>, steps: List<Float>, animated: Boolean,
    mid: (@Composable () -> Unit)?, onHint: (String) -> Unit, onStart: () -> Unit, onChange: (Int, Float) -> Unit,
    onWatch: () -> Unit, onEase: () -> Unit, trailing: (@Composable () -> Unit)? = null
) {
    Row(Modifier.fillMaxWidth().heightIn(min = 44.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(38.dp).tap(onClick = onWatch), contentAlignment = Alignment.Center) { Ico("watch", 22.dp, if (animated) TealC else TxtLo) }
        Box(Modifier.size(32.dp).tap(onClick = onEase), contentAlignment = Alignment.Center) { Ico("element", 17.dp, TxtLo) }
        Text(label, Modifier.weight(1f), color = TxtHi, fontSize = 15.sp, maxLines = 1)
        vals.forEachIndexed { i, v ->
            if (i == 1 && mid != null) mid()
            ValueField(v, fmts[i], steps[i], names[i], onHint, onStart) { nv -> onChange(i, nv) }
        }
        trailing?.invoke()
    }
}

@Composable
fun SettingRow(label: String, value: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().tap(onClick = onClick).padding(horizontal = 8.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), color = TxtHi, fontSize = 15.sp)
        Text(value, color = TealC, fontSize = 15.sp, maxLines = 1)
        Spacer(Modifier.width(6.dp))
        Ico("chevR", 14.dp, TxtLo)
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(text, color = GoldC, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 8.dp, top = 8.dp, bottom = 2.dp))
}

// ===================== editor screen =====================

@Composable
fun EditorScreen(st: EditorState, onClose: () -> Unit) {
    val scope = rememberCoroutineScope()
    st.scopeRef = scope
    val sig = st.playlistSig()
    LaunchedEffect(sig) {
        val clips = st.videoClips()
        if (clips.isEmpty()) {
            st.player.clearMediaItems()
            return@LaunchedEffect
        }
        val items = clips.map { c ->
            MediaItem.Builder().setUri(c.uri!!).setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs((c.srcIn * 1000f).toLong())
                    .setEndPositionMs((c.srcOut * 1000f).toLong())
                    .build()
            ).build()
        }
        st.player.setMediaItems(items, false)
        st.player.prepare()
        st.player.playWhenReady = false
        st.seekPlayer(st.t)
    }
    LaunchedEffect(Unit) { st.loadMissingThumbs() }
    LaunchedEffect(Unit) {
        while (true) {
            delay(10_000)
            withContext(Dispatchers.IO) {
                try { Store.save(st.ctx, st.id, st.comp, false) } catch (e: Exception) { }
            }
        }
    }
    LaunchedEffect(st.hint) {
        if (st.hint.isNotEmpty()) { delay(900); st.hint = "" }
    }
    LaunchedEffect(st.status) {
        if (st.status.isNotEmpty() && !st.exporting) { delay(2600); st.status = "" }
    }
    LaunchedEffect(st.playing) {
        if (!st.playing) {
            st.player.pause()
            st.t = st.tDraw
            return@LaunchedEffect
        }
        val clips = st.videoClips()
        if (clips.isNotEmpty() && st.player.mediaItemCount == clips.size) {
            st.seekPlayer(st.tDraw)
            st.player.play()
            while (true) {
                withFrameNanos { }
                val idx = st.player.currentMediaItemIndex.coerceIn(0, clips.size - 1)
                val nt = minOf(clips[idx].inT + st.player.currentPosition / 1000f, st.comp.dur)
                st.tDraw = nt
                if (abs(nt - st.t) > 0.08f) st.t = nt
                if (st.player.playbackState == Player.STATE_ENDED || nt >= st.comp.dur - 0.03f) {
                    st.playing = false
                    break
                }
            }
        } else {
            var last = withFrameNanos { it }
            while (true) {
                val now = withFrameNanos { it }
                st.tDraw = st.tDraw + (now - last) / 1e9f
                last = now
                if (abs(st.tDraw - st.t) > 0.08f) st.t = st.tDraw
                if (st.tDraw >= st.comp.dur) {
                    st.tDraw = st.comp.dur
                    st.playing = false
                    break
                }
            }
        }
    }
    val replacePick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) st.replaceMedia(u) }
    BackHandler {
        if (st.dialog != "") {
            st.dialog = ""
        } else if (st.menuOpen) {
            st.menuOpen = false
        } else if (st.panel == "fxpick") {
            st.panel = "fx"
        } else if (st.panel != "none") {
            st.panel = "none"
        } else {
            st.persist()
            onClose()
        }
    }
    Column(Modifier.fillMaxSize().cosmic()) {
        TopBar(st, onClose) { replacePick.launch(arrayOf(if (st.sel()?.kind == Kind.VIDEO) "video/*" else "image/*")) }
        PreviewArea(st, Modifier.weight(st.previewWeight))
        Box(
            Modifier.fillMaxWidth().height(16.dp).pointerInput(Unit) {
                detectVerticalDragGestures { change, dy ->
                    change.consume()
                    st.previewWeight = (st.previewWeight + dy / 500f).coerceIn(0.6f, 2.6f)
                }
            },
            contentAlignment = Alignment.Center
        ) { Box(Modifier.width(44.dp).height(4.dp).background(LineC, RoundedCornerShape(2.dp))) }
        Transport(st)
        TimelineView(st)
        BottomPanel(st, scope)
        BottomNav(st, scope)
    }
    Dialogs(st)
}

@Composable
fun TopBar(st: EditorState, onClose: () -> Unit, onReplace: () -> Unit) {
    val sel = st.sel()
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(38.dp).tap { st.persist(); onClose() }, contentAlignment = Alignment.Center) { Ico("chevL", 22.dp) }
        Text("M", style = TextStyle(brush = Brush.linearGradient(listOf(TealC, VioletC)), fontSize = 28.sp, fontWeight = FontWeight.ExtraBold))
        Spacer(Modifier.width(8.dp))
        Text(st.comp.name, Modifier.weight(1f), color = TxtHi, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        Box {
            Box(
                Modifier.size(38.dp).clip(CircleShape).border(1.dp, TealC.copy(alpha = 0.6f), CircleShape).background(Color(0x33122A40))
                    .tap { st.menuOpen = !st.menuOpen },
                contentAlignment = Alignment.Center
            ) { Ico("dots", 20.dp, TealC) }
            DropdownMenu(expanded = st.menuOpen, onDismissRequest = { st.menuOpen = false }, modifier = Modifier.background(Color(0xFF1B2150))) {
                @Composable
                fun item(icon: String, label: String, enabled: Boolean = true, action: () -> Unit) {
                    DropdownMenuItem(
                        text = { Text(label, color = if (enabled) TxtHi else TxtLo.copy(alpha = 0.5f)) },
                        leadingIcon = { Ico(icon, 20.dp, if (enabled) TealC else TxtLo.copy(alpha = 0.5f)) },
                        enabled = enabled,
                        onClick = { st.menuOpen = false; action() }
                    )
                }
                item("sliders", "Project settings") { st.panel = "settings" }
                item("text", "Rename project") { st.nameEdit = st.comp.name; st.dialog = "projname" }
                item("export", "Export MP4", !st.exporting) { st.exportNow(st.scopeRef) }
                HorizontalDivider(color = LineC)
                item("copy", "Duplicate layer", sel != null) { st.duplicateSelected() }
                item("copy", "Copy layer (including style)", sel != null) { st.copySelected() }
                item("paste", "Paste layer", st.clipboard != null) { st.pasteLayer() }
                item("paste", "Paste style", st.clipboard != null && sel != null) { st.pasteStyle() }
                item("replace", "Replace media", sel != null && (sel.kind == Kind.IMAGE || sel.kind == Kind.VIDEO)) { onReplace() }
                item("up", "Move layer up", sel != null) { st.moveSelected(true) }
                item("down", "Move layer down", sel != null) { st.moveSelected(false) }
                item("trash", "Delete layer", sel != null) { st.deleteSelected() }
            }
        }
    }
}

@Composable
fun PreviewArea(st: EditorState, modifier: Modifier) {
    val comp = st.comp
    val pr = comp.previewRes / 100f
    val pw = maxOf(2, (comp.cw * pr).toInt())
    val ph = maxOf(2, (comp.ch * pr).toInt())
    val buf = remember(pw, ph) { Bitmap.createBitmap(pw, ph, Bitmap.Config.ARGB_8888) }
    val bp = remember { Paint() }
    BoxWithConstraints(modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp), contentAlignment = Alignment.Center) {
        val ar = comp.cw.toFloat() / comp.ch
        val w = minOf(maxWidth, maxHeight * ar)
        val h = w / ar
        Box(Modifier.size(w, h).clip(RoundedCornerShape(12.dp)).background(Color.Black).border(1.dp, LineC, RoundedCornerShape(12.dp))) {
            val clips = st.videoClips()
            if (clips.isNotEmpty()) {
                val cur = clips.lastOrNull { st.t >= it.inT } ?: clips.first()
                val va = if (cur.vw > 0 && cur.vh > 0) cur.vw.toFloat() / cur.vh else ar
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    val vw = minOf(w, h * va)
                    AndroidView(
                        factory = { c -> SurfaceView(c).also { st.player.setVideoSurfaceView(it) } },
                        modifier = Modifier.size(vw, vw / va)
                    )
                }
            }
            Canvas(
                Modifier.fillMaxSize().pointerInput(st.selId) {
                    detectDragGestures(onDragStart = { st.snap() }) { change, drag ->
                        val l = st.sel()
                        if (l != null && l.kind != Kind.VIDEO) {
                            change.consume()
                            st.setP(l.px, l.px.at(st.t) + drag.x / size.width)
                            st.setP(l.py, l.py.at(st.t) + drag.y / size.height)
                        }
                    }
                }
            ) {
                if (Engine.ok) {
                    val only = if (comp.renderMode == "Selected Layer" && st.selId >= 0) st.selId else -1
                    st.renderer.render(comp, st.tDraw, buf, only)
                    bp.isFilterBitmap = pr >= 0.99f
                    drawIntoCanvas { cv ->
                        val nc = cv.nativeCanvas
                        nc.drawBitmap(buf, null, RectF(0f, 0f, size.width, size.height), bp)
                        val s = st.sel()
                        if (s != null && s.kind != Kind.VIDEO) {
                            nc.save()
                            val k = size.width / comp.cw
                            nc.scale(k, k)
                            drawSelection(nc, comp, s, st.tDraw)
                            nc.restore()
                        }
                    }
                }
            }
            if (st.hint.isNotEmpty()) {
                Box(
                    Modifier.align(Alignment.TopCenter).padding(top = 8.dp).clip(RoundedCornerShape(50))
                        .background(Brush.horizontalGradient(listOf(VioletC, TealC))).padding(horizontal = 14.dp, vertical = 5.dp)
                ) { Text(st.hint, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium) }
            }
            if (st.status.isNotEmpty()) {
                Column(
                    Modifier.align(Alignment.BottomCenter).padding(8.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xDD0A0D24)).padding(10.dp)
                ) {
                    Text(st.status, color = TxtHi, fontSize = 13.sp)
                    if (st.exporting) {
                        LinearProgressIndicator(progress = { st.prog.coerceIn(0f, 1f) }, color = TealC, trackColor = Color(0xFF26305F), modifier = Modifier.padding(top = 6.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun Transport(st: EditorState) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp).glass(16.dp).padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically
    ) {
        IcoBtn("undo") { st.undo() }
        IcoBtn("redo") { st.redo() }
        IcoBtn("prev") { st.jumpPrev() }
        Box(Modifier.size(44.dp).clip(CircleShape).background(Color.White).tap { st.togglePlay() }, contentAlignment = Alignment.Center) {
            Ico(if (st.playing) "pause" else "play", 22.dp, Ink)
        }
        IcoBtn("next") { st.jumpNext() }
    }
}

// ===================== bottom panels =====================

@Composable
fun BottomPanel(st: EditorState, scope: CoroutineScope) {
    AnimatedVisibility(
        visible = st.panel != "none",
        enter = fadeIn(tween(180)) + expandVertically(tween(180)),
        exit = fadeOut(tween(120)) + shrinkVertically(tween(150))
    ) {
        Box(Modifier.fillMaxWidth().height(268.dp).padding(horizontal = 10.dp, vertical = 6.dp).glass(20.dp)) {
            AnimatedContent(
                targetState = st.panel,
                transitionSpec = { fadeIn(tween(160)) togetherWith fadeOut(tween(110)) },
                label = "panel"
            ) { p ->
                when (p) {
                    "add" -> AddPanel(st, scope)
                    "props" -> PropsPanel(st)
                    "fx" -> FxPanel(st)
                    "fxpick" -> FxPickPanel(st)
                    "layers" -> LayersPanel(st)
                    "settings" -> SettingsPanel(st)
                    else -> Box(Modifier.height(1.dp)) {}
                }
            }
        }
    }
}

@Composable
fun TabItem(icon: String, label: String, selected: Boolean, onClick: () -> Unit) {
    Column(Modifier.tap(onClick = onClick).padding(horizontal = 14.dp, vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Ico(icon, 24.dp, if (selected) TealC else TxtLo)
        Text(label, color = if (selected) TealC else TxtLo, fontSize = 12.sp)
        Box(Modifier.padding(top = 3.dp).width(34.dp).height(2.dp).background(if (selected) TealC else Color.Transparent))
    }
}

@Composable
fun AddPanel(st: EditorState, scope: CoroutineScope) {
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris -> if (uris.isNotEmpty()) st.importMedia(uris, scope) }
    Row(Modifier.fillMaxSize()) {
        Column(Modifier.weight(1f).fillMaxHeight()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp)) {
                TabItem("media", "Media", st.addTab == "media") { st.addTab = "media" }
                TabItem("shape", "Shape", st.addTab == "shape") { st.addTab = "shape" }
                TabItem("element", "Element", st.addTab == "element") { st.addTab = "element" }
            }
            Box(Modifier.fillMaxWidth().height(1.dp).background(LineC))
            Box(Modifier.weight(1f).padding(8.dp)) {
                when (st.addTab) {
                    "media" -> LazyVerticalGrid(
                        columns = GridCells.Fixed(3), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        item {
                            Box(
                                Modifier.aspectRatio(1f).clip(RoundedCornerShape(12.dp)).border(1.dp, TealC.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                                    .background(Color(0x22122A40)).tap { importer.launch(arrayOf("video/*", "image/*")) },
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Ico("plus", 26.dp, TealC)
                                    Text("Import", color = TealC, fontSize = 12.sp)
                                }
                            }
                        }
                        items(st.comp.media) { m ->
                            Box(Modifier.aspectRatio(1f).clip(RoundedCornerShape(12.dp)).background(PanelC).tap { st.addMedia(m) }) {
                                val th = m.thumb
                                if (th != null) Image(th.asImageBitmap(), null, Modifier.matchParentSize(), contentScale = ContentScale.Crop)
                                if (m.kind == "video") {
                                    Text(
                                        clockText(m.dur), color = Color.White, fontSize = 11.sp,
                                        modifier = Modifier.align(Alignment.BottomEnd).padding(4.dp).background(Color(0xAA000000), RoundedCornerShape(6.dp)).padding(horizontal = 5.dp, vertical = 1.dp)
                                    )
                                }
                            }
                        }
                    }
                    "shape" -> LazyVerticalGrid(
                        columns = GridCells.Fixed(3), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(listOf("circle", "square", "rounded", "rectangle", "triangle", "diamond")) { name ->
                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.tap { st.addShape(name) }) {
                                Box(Modifier.aspectRatio(1.35f).fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color(0x22FFFFFF)), contentAlignment = Alignment.Center) {
                                    ShapeGlyph(name)
                                }
                                Text(name.replaceFirstChar { it.uppercase() }, color = TxtHi, fontSize = 12.sp)
                            }
                        }
                    }
                    else -> LazyVerticalGrid(columns = GridCells.Fixed(3), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        item {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.tap { st.addLayer(Kind.FILL) }) {
                                Box(Modifier.aspectRatio(1.35f).fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color(0x22FFFFFF)), contentAlignment = Alignment.Center) {
                                    Canvas(Modifier.size(54.dp, 32.dp)) {
                                        drawRoundRect(GoldC, style = Stroke(3f), cornerRadius = CornerRadius(6f))
                                        drawRoundRect(Brush.verticalGradient(listOf(Color(0x558B5CF6), Color(0x112A2060))), cornerRadius = CornerRadius(6f))
                                    }
                                }
                                Text("Solid", color = TxtHi, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
        Box(Modifier.width(1.dp).fillMaxHeight().background(LineC))
        Column(Modifier.width(72.dp).fillMaxHeight().padding(top = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Column(Modifier.tap { st.addLayer(Kind.TEXT) }.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Ico("text", 26.dp, TxtHi)
                Text("Text", color = TxtLo, fontSize = 12.sp)
            }
        }
    }
}

private fun clockText(sec: Float): String {
    val s = sec.toInt()
    return "%d:%02d".format(s / 60, s % 60)
}

@Composable
fun ShapeGlyph(name: String) {
    Canvas(Modifier.size(46.dp)) {
        val w = size.width
        val h = size.height
        val st = Stroke(width = 3.5f)
        val g = Brush.linearGradient(listOf(GoldC, GoldDim))
        when (name) {
            "circle" -> drawCircle(g, w * 0.42f, Offset(w / 2f, h / 2f), style = st)
            "square" -> drawRect(g, Offset(w * .12f, h * .12f), Size(w * .76f, h * .76f), style = st)
            "rounded" -> drawRoundRect(g, Offset(w * .12f, h * .12f), Size(w * .76f, h * .76f), CornerRadius(w * .2f), style = st)
            "rectangle" -> drawRect(g, Offset(w * .02f, h * .24f), Size(w * .96f, h * .52f), style = st)
            "triangle" -> drawPath(Path().apply { moveTo(w * .5f, h * .1f); lineTo(w * .92f, h * .88f); lineTo(w * .08f, h * .88f); close() }, g, style = st)
            else -> drawPath(Path().apply { moveTo(w * .5f, h * .06f); lineTo(w * .94f, h * .5f); lineTo(w * .5f, h * .94f); lineTo(w * .06f, h * .5f); close() }, g, style = st)
        }
    }
}

@Composable
fun PropsPanel(st: EditorState) {
    val l = st.sel()
    val t = st.t
    if (l == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Select a layer or clip in the timeline to edit it.", color = TxtLo, fontSize = 14.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(24.dp))
        }
        return
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 6.dp)) {
        if (l.kind == Kind.VIDEO) {
            SectionTitle("Video clip • ${l.name}")
            SettingRow("Start (source)", "%.2f s".format(l.srcIn)) { st.dialog = "srcin" }
            SettingRow("End (source)", "%.2f s".format(l.srcOut)) { st.dialog = "srcout" }
            SettingRow("Length", "%.2f s".format(l.srcOut - l.srcIn)) { }
            Text("Drag the teal handles on the clip to trim. Transform and effects for video clips are not supported yet.", color = TxtLo, fontSize = 12.sp, modifier = Modifier.padding(8.dp))
            return@Column
        }
        SectionTitle("Transform • ${l.name}")
        val hint = { s: String -> st.hint = s }
        TRow("Position", listOf("Position X", "Position Y"), listOf(l.px.at(t), l.py.at(t)), listOf("%.2f", "%.2f"), listOf(0.002f, 0.002f),
            l.px.keys.isNotEmpty() || l.py.keys.isNotEmpty(), null, hint, { st.snap() },
            { i, v -> st.setP(if (i == 0) l.px else l.py, v) }, { st.toggleAnim(l.px, l.py) }, { st.toggleEase(l.px, l.py) })
        TRow("Scale", listOf("Scale X", "Scale Y"), listOf(l.sx.at(t), l.sy.at(t)), listOf("%.2f", "%.2f"), listOf(0.005f, 0.005f),
            l.sx.keys.isNotEmpty() || l.sy.keys.isNotEmpty(),
            { Box(Modifier.size(28.dp).tap { l.linkScale = !l.linkScale }, contentAlignment = Alignment.Center) { Ico("replace", 15.dp, if (l.linkScale) TealC else TxtLo) } },
            hint, { st.snap() },
            { i, v -> if (l.linkScale) { st.setP(l.sx, v); st.setP(l.sy, v) } else st.setP(if (i == 0) l.sx else l.sy, v) },
            { st.toggleAnim(l.sx, l.sy) }, { st.toggleEase(l.sx, l.sy) })
        TRow("Pivot", listOf("Pivot X", "Pivot Y"), listOf(l.pvx.at(t), l.pvy.at(t)), listOf("%.2f", "%.2f"), listOf(0.002f, 0.002f),
            l.pvx.keys.isNotEmpty() || l.pvy.keys.isNotEmpty(), null, hint, { st.snap() },
            { i, v -> st.setP(if (i == 0) l.pvx else l.pvy, v) }, { st.toggleAnim(l.pvx, l.pvy) }, { st.toggleEase(l.pvx, l.pvy) })
        TRow("Rotation", listOf("Turns", "Degrees"), listOf(l.rrev.at(t), l.rdeg.at(t)), listOf("%.0f", "%.0f"), listOf(0.05f, 0.5f),
            l.rrev.keys.isNotEmpty() || l.rdeg.keys.isNotEmpty(),
            { Text("x", color = TxtLo, fontSize = 14.sp) }, hint, { st.snap() },
            { i, v -> st.setP(if (i == 0) l.rrev else l.rdeg, v) }, { st.toggleAnim(l.rrev, l.rdeg) }, { st.toggleEase(l.rrev, l.rdeg) })
        TRow("Opacity", listOf("Opacity"), listOf(l.op.at(t)), listOf("%.2f"), listOf(0.003f), l.op.keys.isNotEmpty(), null, hint, { st.snap() },
            { _, v -> st.setP(l.op, v.coerceIn(0f, 1f)) }, { st.toggleAnim(l.op) }, { st.toggleEase(l.op) })
        Row(Modifier.fillMaxWidth().tap { st.more = !st.more }.padding(vertical = 10.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            Text(if (st.more) "Less" else "More", color = TxtLo, fontSize = 14.sp)
            Spacer(Modifier.width(6.dp))
            Ico(if (st.more) "up" else "down", 14.dp, TxtLo)
        }
        if (st.more) {
            SettingRow("Start", "%.2f s".format(l.inT)) { st.dialog = "start" }
            SettingRow("End", "%.2f s".format(l.outT)) { st.dialog = "end" }
            if (l.kind == Kind.TEXT) {
                SettingRow("Text", l.text) { st.nameEdit = l.text; st.dialog = "text" }
                SettingRow("Font size", "%.0f".format(l.h)) { st.dialog = "fsize" }
            }
            if (l.kind == Kind.RECT || l.kind == Kind.ELLIPSE) {
                SettingRow("Width", "%.0f".format(l.w)) { st.dialog = "w" }
                SettingRow("Height", "%.0f".format(l.h)) { st.dialog = "h" }
            }
            if (l.kind != Kind.IMAGE) {
                Row(Modifier.padding(8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    listOf(0xFFFFFFFF.toInt(), 0xFF2DE0C2.toInt(), 0xFF8B5CF6.toInt(), 0xFFF2677A.toInt(), 0xFFFACC15.toInt(), 0xFF3B82F6.toInt()).forEach { c ->
                        Box(Modifier.size(30.dp).clip(CircleShape).background(Color(c)).border(1.dp, LineC, CircleShape).tap { st.snap(); l.color = c })
                    }
                }
            }
        }
    }
}

@Composable
fun FxPanel(st: EditorState) {
    val l = st.sel()
    val t = st.t
    if (l == null || l.kind == Kind.VIDEO) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(
                if (l == null) "Select a layer to add effects." else "Effects apply to image, text, shape and solid layers.",
                color = TxtLo, fontSize = 14.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(24.dp)
            )
        }
        return
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 6.dp)) {
        SectionTitle("Effects • ${l.name}")
        l.effects.toList().forEach { e ->
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(e.def.label, Modifier.weight(1f), color = TealC, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Box(Modifier.size(34.dp).tap { st.snap(); l.effects.remove(e) }, contentAlignment = Alignment.Center) { Ico("trash", 18.dp, TxtLo) }
            }
            e.def.params.forEachIndexed { i, prm ->
                val p = e.params[i]
                TRow(prm.name, listOf(prm.name), listOf(p.at(t)), listOf(prm.fmt), listOf((prm.max - prm.min) / 300f), p.keys.isNotEmpty(), null,
                    { s -> st.hint = s }, { st.snap() }, { _, v -> st.setP(p, v.coerceIn(prm.min, prm.max)) }, { st.toggleAnim(p) }, { st.toggleEase(p) })
            }
        }
        Row(
            Modifier.padding(top = 10.dp).clip(RoundedCornerShape(50)).border(1.dp, TealC.copy(alpha = 0.7f), RoundedCornerShape(50))
                .background(Color(0x22122A40)).tap { st.panel = "fxpick" }.padding(horizontal = 18.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Ico("plus", 16.dp, TealC)
            Spacer(Modifier.width(8.dp))
            Text("Add effect", color = TealC, fontSize = 14.sp)
        }
    }
}

@Composable
fun FxPickPanel(st: EditorState) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(38.dp).tap { st.panel = "fx" }, contentAlignment = Alignment.Center) { Ico("chevL", 20.dp, TxtHi) }
            Text("Add effect", color = TxtHi, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FX_CATS.forEach { c ->
                val on = st.fxCat == c
                Text(
                    c, color = if (on) Ink else TxtHi, fontSize = 13.sp,
                    modifier = Modifier.clip(RoundedCornerShape(50)).background(if (on) TealC else Color(0x33FFFFFF)).tap { st.fxCat = c }.padding(horizontal = 14.dp, vertical = 6.dp)
                )
            }
        }
        Box(Modifier.weight(1f).padding(8.dp)) {
            LazyVerticalGrid(columns = GridCells.Fixed(3), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(FX_DEFS.filter { it.cat == st.fxCat }) { d ->
                    val bmp = remember(d.type) { fxThumb(d) }
                    Box(Modifier.aspectRatio(1f).clip(RoundedCornerShape(12.dp)).background(PanelC).tap { st.addEffect(d) }) {
                        Image(bmp.asImageBitmap(), null, Modifier.matchParentSize(), contentScale = ContentScale.Crop)
                        Text(
                            d.label, color = Color.White, fontSize = 11.sp, maxLines = 1, textAlign = TextAlign.Center,
                            modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(Color(0xAA000000)).padding(vertical = 3.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun LayersPanel(st: EditorState) {
    val layers = st.comp.layers.toList().reversed()
    if (layers.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("No layers yet. Use Add.", color = TxtLo, fontSize = 14.sp) }
        return
    }
    LazyColumn(Modifier.fillMaxSize().padding(6.dp)) {
        items(layers) { l ->
            val on = st.selId == l.id
            Row(
                Modifier.fillMaxWidth().padding(vertical = 2.dp).clip(RoundedCornerShape(12.dp))
                    .background(if (on) Color(0x332DE0C2) else Color(0x14FFFFFF)).tap { st.selId = l.id }.padding(horizontal = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(38.dp).tap { st.snap(); l.visible = !l.visible }, contentAlignment = Alignment.Center) {
                    Ico(if (l.visible) "eye" else "eyeoff", 20.dp, if (l.visible) TealC else TxtLo)
                }
                Text(l.name.ifEmpty { l.kind.name }, Modifier.weight(1f), color = TxtHi, fontSize = 15.sp, maxLines = 1)
                Text(l.kind.name.lowercase(), color = TxtLo, fontSize = 11.sp)
                Box(Modifier.size(38.dp).tap { st.nameEdit = l.name; st.selId = l.id; st.dialog = "layername" }, contentAlignment = Alignment.Center) { Ico("text", 18.dp, TxtLo) }
            }
        }
    }
}

@Composable
fun SettingsPanel(st: EditorState) {
    val c = st.comp
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(8.dp)) {
        SectionTitle("Project settings")
        SettingRow("Ratio", c.ratio) { st.dialog = "ratio" }
        SettingRow("FPS", "%.1f".format(c.fps.toFloat())) { st.dialog = "fps" }
        SettingRow("Preview resolution", "${c.previewRes}%") { st.dialog = "res" }
        SettingRow("Preview render mode", c.renderMode) { st.dialog = "mode" }
        Text("Export size: ${c.cw}×${c.ch}", color = TxtLo, fontSize = 12.sp, modifier = Modifier.padding(8.dp))
    }
}

// ===================== bottom navigation =====================

@Composable
fun NavItem(icon: String, label: String, active: Boolean, accent: Boolean = false, onClick: () -> Unit) {
    Column(Modifier.tap(onClick = onClick).padding(horizontal = 6.dp, vertical = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        if (accent) {
            Box(
                Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(Brush.linearGradient(listOf(TealC, Color(0xFF22C55E)))),
                contentAlignment = Alignment.Center
            ) { Ico(if (active) "close" else "plus", 22.dp, Ink) }
        } else {
            Box(Modifier.size(38.dp), contentAlignment = Alignment.Center) { Ico(icon, 24.dp, if (active) TealC else TxtLo) }
        }
        Text(label, color = if (active || accent) TealC else TxtLo, fontSize = 12.sp)
    }
}

@Composable
fun BottomNav(st: EditorState, scope: CoroutineScope) {
    Row(
        Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Color(0xFF0E1238), Color(0xFF080B22)))).padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceAround, verticalAlignment = Alignment.CenterVertically
    ) {
        NavItem("plus", "Add", st.panel == "add", accent = true) { st.togglePanel("add") }
        NavItem("spark", "Effects", st.panel == "fx" || st.panel == "fxpick") { st.togglePanel("fx") }
        NavItem("sliders", "Properties", st.panel == "props") { st.togglePanel("props") }
        NavItem("layers", "Layers", st.panel == "layers") { st.togglePanel("layers") }
        NavItem("export", "Export", st.exporting) { st.exportNow(scope) }
    }
}

// ===================== dialogs =====================

@Composable
fun Dialogs(st: EditorState) {
    val comp = st.comp
    val sel = st.sel()
    val choice: List<String> = when (st.dialog) {
        "ratio" -> listOf("16:9", "9:16", "1:1", "4:3", "21:9")
        "fps" -> listOf("24", "25", "30", "50", "60")
        "res" -> listOf("100", "75", "50", "25", "10")
        "mode" -> listOf("All Layers", "Selected Layer")
        else -> emptyList()
    }
    if (choice.isNotEmpty()) {
        AlertDialog(
            onDismissRequest = { st.dialog = "" }, containerColor = Color(0xFF1B2150), confirmButton = {},
            title = { Text(when (st.dialog) { "ratio" -> "Ratio"; "fps" -> "FPS"; "res" -> "Preview resolution (%)"; else -> "Preview render mode" }, color = TxtHi) },
            text = {
                Column {
                    choice.forEach { o ->
                        Text(
                            o, color = TxtHi, fontSize = 18.sp,
                            modifier = Modifier.fillMaxWidth().tap {
                                when (st.dialog) {
                                    "ratio" -> st.setRatio(o)
                                    "fps" -> comp.fps = o.toInt()
                                    "res" -> comp.previewRes = o.toInt()
                                    "mode" -> comp.renderMode = o
                                }
                                st.dialog = ""
                            }.padding(14.dp)
                        )
                    }
                }
            }
        )
    }
    if (st.dialog == "projname" || st.dialog == "layername" || st.dialog == "text") {
        AlertDialog(
            onDismissRequest = { st.dialog = "" }, containerColor = Color(0xFF1B2150),
            confirmButton = {
                TextButton(onClick = {
                    st.snap()
                    when (st.dialog) {
                        "projname" -> comp.name = st.nameEdit
                        "layername" -> sel?.name = st.nameEdit
                        "text" -> sel?.text = st.nameEdit
                    }
                    st.dialog = ""
                }) { Text("OK", color = TealC) }
            },
            dismissButton = { TextButton(onClick = { st.dialog = "" }) { Text("Cancel", color = TxtLo) } },
            text = { OutlinedTextField(value = st.nameEdit, onValueChange = { st.nameEdit = it }, singleLine = true) }
        )
    }
    val numKeys = listOf("start", "end", "fsize", "w", "h", "srcin", "srcout")
    if (st.dialog in numKeys && sel != null) {
        var v by remember(st.dialog) {
            mutableStateOf(
                when (st.dialog) {
                    "start" -> sel.inT.toString()
                    "end" -> sel.outT.toString()
                    "fsize" -> sel.h.toString()
                    "w" -> sel.w.toString()
                    "h" -> sel.h.toString()
                    "srcin" -> sel.srcIn.toString()
                    else -> sel.srcOut.toString()
                }
            )
        }
        AlertDialog(
            onDismissRequest = { st.dialog = "" }, containerColor = Color(0xFF1B2150),
            confirmButton = {
                TextButton(onClick = {
                    val n = v.toFloatOrNull()
                    if (n != null) {
                        st.snap()
                        when (st.dialog) {
                            "start" -> sel.inT = n.coerceIn(0f, sel.outT - 0.1f)
                            "end" -> sel.outT = n.coerceIn(sel.inT + 0.1f, maxOf(comp.dur, sel.inT + 0.1f))
                            "fsize", "h" -> sel.h = n.coerceAtLeast(1f)
                            "w" -> sel.w = n.coerceAtLeast(1f)
                            "srcin" -> { sel.srcIn = n.coerceIn(0f, sel.srcOut - 0.2f); relayoutVideo(comp) }
                            "srcout" -> { sel.srcOut = n.coerceIn(sel.srcIn + 0.2f, maxOf(sel.srcDur, sel.srcIn + 0.2f)); relayoutVideo(comp) }
                        }
                    }
                    st.dialog = ""
                }) { Text("OK", color = TealC) }
            },
            dismissButton = { TextButton(onClick = { st.dialog = "" }) { Text("Cancel", color = TxtLo) } },
            text = { OutlinedTextField(value = v, onValueChange = { v = it }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)) }
        )
    }
}
