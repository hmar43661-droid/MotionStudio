#pragma once
#include "../jni.h"
struct AndroidBitmapInfo { uint32_t width, height, stride; int32_t format; uint32_t flags; };
enum { ANDROID_BITMAP_RESULT_SUCCESS = 0 };
enum { ANDROID_BITMAP_FORMAT_RGBA_8888 = 1 };
struct FakeBitmap : _jobject { int w = 0, h = 0, locks = 0; std::vector<uint8_t> d; };
int AndroidBitmap_getInfo(JNIEnv*, jobject b, AndroidBitmapInfo* info);
int AndroidBitmap_lockPixels(JNIEnv*, jobject b, void** addr);
int AndroidBitmap_unlockPixels(JNIEnv*, jobject b);
