#pragma once
#include <cstdint>
#include <vector>
typedef int32_t jint; typedef int64_t jlong; typedef float jfloat; typedef uint8_t jboolean; typedef jint jsize;
struct _jobject { virtual ~_jobject() {} };
typedef _jobject* jobject; typedef _jobject* jclass;
struct _jarray : _jobject {};
typedef _jarray* jarray;
struct _jfloatArray : _jarray { std::vector<float> v; };
typedef _jfloatArray* jfloatArray;
struct _jobjectArray : _jarray { std::vector<jobject> v; };
typedef _jobjectArray* jobjectArray;
#define JNIEXPORT
#define JNICALL
#define JNI_ABORT 2
struct JNIEnv {
    jfloat* GetFloatArrayElements(jfloatArray a, jboolean*) { return a->v.data(); }
    void ReleaseFloatArrayElements(jfloatArray, jfloat*, jint) {}
    jsize GetArrayLength(jarray a) {
        if (auto f = dynamic_cast<_jfloatArray*>(a)) return (jsize)f->v.size();
        if (auto o = dynamic_cast<_jobjectArray*>(a)) return (jsize)o->v.size();
        return 0;
    }
    jobject GetObjectArrayElement(jobjectArray a, jsize i) { return a->v[i]; }
    void DeleteLocalRef(jobject) {}
};
