import struct, sys
def prop(base, smooth=True, keys=()):
    o=[float(base), 1.0 if smooth else 0.0, float(len(keys))]
    for t,v in keys: o += [float(t), float(v)]
    return o
def layer(kind, visible, inT, outT, bw, bh, color, blend, props, fx):
    o=[kind, 1.0 if visible else 0.0, inT, outT, bw, bh, *color, blend]
    for p in props: o += p
    o.append(float(len(fx)))
    for fid, params in fx:
        o += [float(fid), float(len(params))]
        for p in params: o += p
    return o
def transform(px=.5,py=.5,sx=1,sy=1,pvx=.5,pvy=.5,rrev=0,rdeg=0,op=1, pxkeys=()):
    return [prop(px,True,pxkeys),prop(py),prop(sx),prop(sy),prop(pvx),prop(pvy),prop(rrev),prop(rdeg),prop(op)]
blob=[3.0]
blob += layer(0,True,0,10,100,100,(1,1,1,1),0,transform(),[])                           # video placeholder (kind 0 -> skipped)
blob += layer(1,True,0,10,40,40,(1,1,1,1),0,transform(pxkeys=[(0,.25),(1,.75)]),[(0,[prop(.2)]),(10,[prop(6)])])  # texture + brightness + gauss
blob += layer(2,True,0,10,30,30,(1,0,0,1),0,transform(px=.8,py=.2,op=.5),[(25,[prop(0),prop(.5),prop(.5),prop(.5),prop(.5),prop(.1),prop(0)])])  # red fill + mask
open(sys.argv[1],"wb").write(struct.pack("<%df"%len(blob),*blob))
print(len(blob),"floats")
